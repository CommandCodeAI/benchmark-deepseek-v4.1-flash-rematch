data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126368805162}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126368920055}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" new fails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126368920110}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1. **C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126368920156}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9 purity fail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126368976392}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**: live counts flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126368976447}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126368976584}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16 vs ref "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126368976662}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1057. Interesting —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369114236}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369114287}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369114329}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369114368}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369369248}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369369296}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369369335}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P3 sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369369388}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations Home"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369418120}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369418186}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10, speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369418237}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369418355}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", interval min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369490800}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") but counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369490874}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369490933}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 16 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369491000}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"coll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369576513}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apsed) vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369576590}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reference"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369576639}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flat "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369576683}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1057. Why?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369632116}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Live world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369632185}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369632254}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369632317}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369681475}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369681562}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ggled OFF"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369681641}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369681698}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — P3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369757956}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fresh page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369758022}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369758071}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369758178}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed End"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369826995}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", interval Home, generations Home"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369827053}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369827098}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369827153}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369876952}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Object.assign({}, w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369877015}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".config)` and run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369877079}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369877137}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10. Live world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369936532}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finished at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369936578}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 10 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369936729}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"config.g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369938487}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enerations=10), so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369987128}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" batches of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369987180}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369987204}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126369987372}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370038740}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370038794}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 3,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370038927}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6,9 → live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370039005}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370116045}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370116156}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ref same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370116206}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370116248}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370187965}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370188053}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s wildly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370188205}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differ →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370188264}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370238709}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370238753}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism violated by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370238818}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370238886}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" path? Or live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370296486}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world config differs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370296585}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from expected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370296636}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (e.g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370296674}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370364351}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370364438}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370364562}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ations` 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370364639}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but interval?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370475483}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370475570}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370475649}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370475715}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes?)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370530835}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370530963}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm ref counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370531063}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 105"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370531139}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 flora suggests no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370581894}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophes ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370581956}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370581999}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370582039}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"); live "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370661282}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16 flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370661347}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suggests multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370661442}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" droughts."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370661485}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So ref likely didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370724803}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t get events because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370725186}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370725249}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless stops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370725288}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370798409}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370798453}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inished? create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370798498}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World(config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370798539}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") where"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370861495}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config includes `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370861556}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"finished`? Object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370861596}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".assign({"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370861632}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"}, w.config) — config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370940455}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370940521}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finished. Events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370940584}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scheduled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126370940639}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371040523}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".interval="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371040567}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3, catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371040670}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes=true. Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371040711}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371124908}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371124975}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no events? Maybe ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371125047}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config.c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371125082}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371174497}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371174547}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371174601}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ggled false? P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371174644}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371225507}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t touch to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371225575}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ggles. Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371225617}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWait ref counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371225662}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371290374}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1057 at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371290447}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10 without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371290508}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371290561}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes? Even"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371349015}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371349081}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371349132}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371349186}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens might have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371430935}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371430987}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3,6,9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371431027}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → could reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371431070}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371526086}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371526143}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371526184}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extreme;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371526241}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371605849}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371605910}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371605966}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371606021}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371665980}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371666027}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371666109}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371666187}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Home"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371806778}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371806837}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371806881}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" BEFORE run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371807002}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reaches gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371866813}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371866863}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371866901}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371866943}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371917202}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371917258}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1: gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371917312}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371917384}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10; then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371984005}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371984069}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finishes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371984114}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126371984157}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Ref:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372038285}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" createWorld"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372038352}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(config)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372038400}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372038442}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372108684}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 → runHeadless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372108750}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(ref, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372108836}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10):"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372108898}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372241158}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless targets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372241209}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372241274}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10 and stops when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372241320}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finished. Should have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372287137}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same schedule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372287190}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nDifference:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372287323}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372287385}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" went"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372358730}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" through *in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372358779}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cremental* run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372358814}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372358848}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372499077}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" through runGeneration ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372499125}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runHeadless)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372499162}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372499197}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372558709}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372558791}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" path should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372558863}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be equivalent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372558922}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372612885}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" designed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372612954}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372613009}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", but maybe catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372613040}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scheduling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372659503}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372659542}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world.t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372659582}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick` increments and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372659618}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372723728}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" application differs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372723791}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Actually counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372723847}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wildly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372723885}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" different (16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372896685}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs 1057"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372896761}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372896817}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372896853}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372954871}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" experienced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372954960}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophic collapse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372955033}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126372955101}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373020137}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no events because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373020226}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373020316}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less(world,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373020384}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens)` when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373068004}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373068093}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" created with config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373068168}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" containing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373068244}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `generations:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373134954}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10`? Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373135026}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWait P3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373135091}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373135154}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373193173}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Home"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373193239}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373193300}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3. But my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373193364}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" P3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373245059}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373245121}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" setting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373245191}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keys: for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373245257}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" [['"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373325691}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"speed','End"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373325752}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'],['interval','Home'],"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373325797}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"['generations','Home']"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373325846}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"] — sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373415896}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373415947}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373416183}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373416245}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373503505}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373503581}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0. Live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373503636}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373503671}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373562679}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373562727}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373562769}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" P3 F"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373562793}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373614805}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" summary:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373614873}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373614985}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" census"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373615045}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Flora 16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373669052}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" peak"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373669127}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373669195}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",085 −98"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373669240}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% ..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373755003}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12 catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373755065}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373755161}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373755203}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12 catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373822971}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes in 40-gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373823022}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373823077}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373823121}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373890274}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373890317}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" P3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373890358}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" used gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373890403}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373949197}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373949274}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" F1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373949401}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meta says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126373949464}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374008080}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 generations?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374008632}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374008683}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374008735}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview4 P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374078813}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 F1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374078887}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374078946}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" log. Earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374078991}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374160168}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" F1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374160234}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meta: \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374160281}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Seed 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374160319}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 · 40 generations ·"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374232871}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1,200 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374232955}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" · 12 catastrophes\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374233018}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374233136}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374281862}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t shorten"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374281918}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374281974}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10! Because `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374282050}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374398147}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ations` dial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374398207}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Home"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374398247}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374398281}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=10, but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374463198}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374463256}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374463301}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374463373}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40? In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374528711}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374528787}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" F"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374528845}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374528899}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meta says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374576966}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 generations. Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374577033}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because changing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374577158}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374577206}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374625423}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374625468}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end study;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374625504}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374625547}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374707710}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1, setting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374707778}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374707832}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374707883}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374770428}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374770491}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374770549}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generations=10 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374770596}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374826525}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end at 10,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374826601}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374826724}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40. But meta"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374826790}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says 40 generations."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374962449}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374962551}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374962607}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Home didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126374962648}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t apply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375070399}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Or my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375070447}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375070481}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375070517}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375218829}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ast? P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375218875}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 fresh page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375218928}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375219034}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" marks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375279137}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fresh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375279180}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375279319}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375279361}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375331885}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Home →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375331929}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375331967}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375332002}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375388711}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → Home"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375388757}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375388826}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375388893}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" input"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375440409}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375440459}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ste"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375440517}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pper, keydown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375440574}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handler?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375490517}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Home not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375490575}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handled in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375490648}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stepper key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375490720}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"down (only arrows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375541542}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375541602}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/enter/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375541639}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"escape) → Home"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375541688}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375594957}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nothing!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375595013}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375595072}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stayed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375595136}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40. My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375657829}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375658224}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375658265}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fast.g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375658326}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ensMin` recorded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375718480}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assignment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375718553}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375718616}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375718659}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verification"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375814331}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375814402}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375814457}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375814520}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8× ~5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375864267}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s, events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375864345}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375864425}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375864475}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375916148}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events, flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375916214}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" collapse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375916250}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 16."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375916285}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" OK.\n\nSo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375969616}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" C9 ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375969669}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375969715}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126375969763}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".config.g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376039935}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enerations` = 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376040022}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376040102}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376040175}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376093323}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less 40."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376093399}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Live gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376093463}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376093536}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376205070}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events. Ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376205146}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376205207}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1057 flora →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376205266}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ref had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376254640}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fewer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376254704}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events? Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376254769}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ref created"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376254810}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with Object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376332690}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".assign({}, w.config):"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376332776}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config includes `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376332841}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376332869}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ations:40`,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376386135}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and `w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376386185}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".config` may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376386250}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have been"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376386307}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376457609}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mutated with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376457684}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runtime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376457768}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fields?** It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376457803}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376549826}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376549882}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376549924}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376550083}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World` cl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376641496}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"amps/over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376641546}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rides?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376641583}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376641658}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376710833}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differ drastically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376710926}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe purity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376710988}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376711031}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376779435}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376779487}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376779525}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376779563}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376826463}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cast**"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376826523}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376826566}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" point? P3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376826616}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376879558}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376879603}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376879640}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376879823}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376936360}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376936411}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376936446}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126376936493}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". No rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377066281}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ast. Live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377066377}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377066449}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377066523}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.\n\nKey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377126742}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suspicion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377126836}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": my ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377126919}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377126977}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377182515}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less(ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377182578}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 40)` stopped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377182655}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377182716}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because `run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377317575}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless` semantics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377317684}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": target absolute"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377317767}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377317833}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377391549}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377391596}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377391635}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377391677}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377448621}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts 105"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377448706}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 flora suggests events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377448748}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rare —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377448806}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe ref had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377514742}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377514794}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes:false`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377514919}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? config.cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377514977}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377578301}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377578529}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377578570}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWait: live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377578596}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377632791}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377632851}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377632902}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=40;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377632939}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ref gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377678218}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=40 (assert"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377678312}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" passed)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377678411}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377678462}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s differ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377779924}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377779997}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377780039}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377780128}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377833869}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed normalized"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377833922}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377833974}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377834030}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377906956}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" difference be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377907009}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that boot's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377907056}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377907119}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377977923}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377977984}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `runTick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377978046}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126377978102}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378028368}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378028426}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378028475}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378028523}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boundaries vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378105124}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378105179}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation` path? If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378105226}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378105282}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick-based"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378170491}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378170557}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scheduling differs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378170606}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378170672}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-based run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378298604}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless (e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378298648}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g., run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378298683}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378298754}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" internally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378365650}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" does runGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378365696}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378365735}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fires events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378365771}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378437387}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation boundaries but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378437468}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378437510}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378437571}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378520458}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differently),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378520515}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378520558}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" diverg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378520603}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"es: run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378571454}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378571523}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378571656}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378571699}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30 then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378621094}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378621147}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378621190}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378621265}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378694771}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runTick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378694829}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fires"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378694886}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events mid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378694975}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-generation?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378792141}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Actually event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378792187}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scheduling by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378792235}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378792340}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378871777}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be same."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378871854}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378871990}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378872059}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" RNG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378934691}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378934738}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378934772}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may differ:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126378934806}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379010650}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less may run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379010702}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379010752}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 ticks via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379010791}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runTick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379064585}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379064629}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379064667}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less calls run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379064701}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379112967}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" does"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379113037}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" its own"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379113118}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" single"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379113212}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-shot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379187570}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379187720}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"not tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379187799}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379187868}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), and playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379264283}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379264352}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379264458}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 times, engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379264524}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379322164}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379322423}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paths that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379322463}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" produce different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379322502}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" results!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379493979}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That would be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379494026}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a REAL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379494093}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" determinism/p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379494139}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"urity bug: the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379556931}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379556981}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379557010}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379557064}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379621933}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick path) differs from head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379622010}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379622121}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"generation path)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379622195}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Brief says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379686709}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379686766}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379686805}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"advances one full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379686845}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation\","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379740638}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379740710}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379740765}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-forward; likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379740835}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379830470}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379830519}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runGeneration."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379830562}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379830602}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379882072}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379882118}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" smooth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379882176}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" animation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379882226}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". If run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379937436}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379937546}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≠"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379937627}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126379937975}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380006452}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380006511}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380006552}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380006593}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation, then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380069717}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380069769}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"same generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380069811}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boundaries\" via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380069852}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380125879}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen differ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380125943}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380126128}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380126197}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s expected?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380253562}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380253615}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380253662}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380253717}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/controls must not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380317586}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" alter simulation; it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380317703}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't say tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380317783}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380317876}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equivalence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380381849}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". However"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380381897}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380381949}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380382899}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380461788}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380461852}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" comes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380461902}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from the live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380461962}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380505869}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world, so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380505921}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" internal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380505964}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consistency is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380506006}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" what matters;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380561618}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380561693}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380561747}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380561792}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" built"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380608714}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from live world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380608776}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history. My C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380608823}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9 comparison"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380608865}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assumes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380670973}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equivalence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380671046}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" between tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380671097}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380671163}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back and runGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380735378}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380735426}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380735487}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be invalid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380735530}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380799036}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380799130}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380799452}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine source"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380799541}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": runGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380873252}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" implementation &"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380873301}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runTick."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380873522}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380873609}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runGeneration uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380956594}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" internal tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380956670}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop, they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380956809}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126380956855}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" match. Let me inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381010149}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381010223}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". **H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381010279}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-1024 fail**:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381010330}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" horizontal scroll "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381088484}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5px at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381088546}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1024 (scrollW"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381088595}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1029) and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381088649}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vertical scroll huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381141545}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381141621}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381141675}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1314)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381141761}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381229922}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024. Brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381229979}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says degrade"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381230022}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 1024 width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381230073}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; vertical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381316116}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381316160}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024 likely acceptable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381316209}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381316253}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arrow ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381365056}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stack"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381365135}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Horizontal "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381365212}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5px overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381365339}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is a minor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381434348}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue (c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381434421}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aused by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381434477}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381434515}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381506395}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-width or padding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381506454}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381506508}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as MIN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381506569}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"OR finding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381568150}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381568216}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5px horizontal overflow at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381568273}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1024 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381568313}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381686280}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381686370}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"bar"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381686443}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":");"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381686515}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381739009}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381739169}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381739249}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381739311}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-x hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381795632}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or padding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381795731}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" twe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381795799}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ak. Also vertical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381795859}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stacking"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381854596}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expected at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381854683}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381854751}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381854836}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381906536}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation/run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381906613}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick equivalence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381906679}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381906737}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_3fikdu7ku9tnjhrvcog2ftv1","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381911870}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381911943}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381912100}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381912186}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381930089}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381930148}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381930189}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381930243}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381949459}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381949544}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381949610}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381949669}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381966349}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381966429}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381966515}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381966570}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381981513}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381981659}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381981732}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381981778}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381998558}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381998609}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381998699}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381998776}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126381999836}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382000101}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382000174}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382000252}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382017683}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382017772}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382017845}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382017901}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382045024}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382045101}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382045149}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382045218}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382054551}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382054632}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382054683}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382054729}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382067031}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382067096}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382067165}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382067225}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382085044}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382085108}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382085155}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382085203}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382118173}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382118248}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382118314}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382118397}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382119040}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382119093}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382119135}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382119201}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382134633}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382134804}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382134849}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382134896}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382176895}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382176969}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382177043}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382177085}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382180300}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382180379}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382180453}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382180517}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382188199}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" step"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382188276}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382188344}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382188393}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382207788}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382207853}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382207895}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382207964}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382208535}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382208602}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382208754}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382208822}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382229640}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382229719}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382229772}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382229839}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382240847}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382240917}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382241092}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382241158}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382258894}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382258951}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382259002}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382259074}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382260090}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382260146}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382260194}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382260244}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382279477}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cut"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382279532}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382279576}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382279631}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382296978}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382297070}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382297115}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382297163}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382355135}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382355210}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382355391}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382355440}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382355483}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382355536}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382355599}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382355688}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382356595}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382356641}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382356745}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382356787}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382360247}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382360344}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382360427}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382360480}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382375908}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382375977}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376050}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376160}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376247}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376297}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376356}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376464}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376539}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376584}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376635}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376713}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376793}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376842}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376890}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382376931}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382417562}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382417633}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382417702}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382417731}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cut"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382419923}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382420112}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382420182}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382420233}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382433867}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382434031}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382434115}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382434202}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382451584}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382451653}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382451691}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382451743}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382465810}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382465863}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382465921}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382465994}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382478767}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382478831}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382478886}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382478926}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382491056}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382491112}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382491156}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382491217}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382532141}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382532198}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382532257}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382532314}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382554305}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" equivalence"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382554382}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382554451}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23944,"ts_us":1793126382554508}}

data: {"id":"c612af07ee61653acab83376f448be07","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":329466,"completion_tokens":1859,"total_tokens":331325,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":328576,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1652,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":23944,"ts_us":1793126382623523}}

data: [DONE]

