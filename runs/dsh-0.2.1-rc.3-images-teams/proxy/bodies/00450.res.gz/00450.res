data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126502910669}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"All"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126502995842}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126502995894}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at both sizes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126502997694}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- backing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503122377}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = round"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503122449}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(css rect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503122504}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503122560}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- no page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503188741}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll (scrollH =="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503188824}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" viewport, body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503188880}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503188949}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n- meta includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503242377}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503242482}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503242586}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels populated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503242630}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- no console"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503299345}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" errors.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503299401}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me look at the final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503299455}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshots to confirm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503299532}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visuals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503372408}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503372459}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"the final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503372498}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503372593}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-1440)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503438495}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503438543}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test harness one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503438663}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gen/empty"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503438713}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly after fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503531668}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Canvas changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503531837}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (styles px"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503531934}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). And maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503532058}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dpr2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503592743}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final visual."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503592810}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then message"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503592942}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503592992}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mark task-2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503655992}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" complete.\n\nAlso the screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503656041}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots in shots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503656092}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/ folder:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503656204}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final-record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503716454}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503716516}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.png etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503716554}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Should also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503716608}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503787683}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up intermediate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503787759}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshots?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503787821}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not required"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503787918}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503836925}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'re evidence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503836997}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Keep a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503837040}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tidy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503837075}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503893653}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe remove"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503893731}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503893866}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" obsolete ones"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503893910}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The task"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503968812}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" allows shots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503968988}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/chart-*. My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503969200}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest files"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126503969268}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" named final-record-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504046942}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*.png and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504047021}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504047089}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*.png. Keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504047160}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me view final "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124104}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1440 screenshot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124226}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_0vr1b3f4gpq8zg28x69runfd","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124330}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124438}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124549}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124640}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124689}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124768}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124835}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504124948}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125046}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125104}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125246}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125301}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125354}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125422}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125536}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125616}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125677}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504125860}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504129582}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504129756}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504129834}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504129900}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504148242}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504148305}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504148349}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504148405}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504173301}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504173420}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504173486}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504173586}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504173732}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504173845}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504173899}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504174075}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504194148}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504194242}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504194393}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504194473}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504197978}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504198098}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504198170}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504198228}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504198478}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504198638}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504198702}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504198838}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504220031}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504220095}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504220145}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504220276}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504292651}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504292720}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504292879}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504292961}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504293527}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504293585}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504293627}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504293744}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504321734}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504321811}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12627,"ts_us":1793126504321891}}

data: {"id":"4474cd15c1f48b4b959d5a15d47a7c92","object":"chat.completion.chunk","created":1793126502,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":277064,"completion_tokens":266,"total_tokens":277330,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":275328,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":177,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":12627,"ts_us":1793126504328799}}

data: [DONE]

