data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123262746628}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123262822698}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123262822799}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me syntax check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123262822855}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and do a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123262904495}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quick smoke run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123262904544}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of the CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123262904624}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P driver against the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123262904733}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current stub deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263005515}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able to validate harness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263005558}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263005608}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263005654}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is stub, most"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263055778}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263055836}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fail fast but C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263055887}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263055941}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fail after "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263118769}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"15s... Let me first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263118816}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263118902}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263118956}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P connectivity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263210810}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263210898}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263211102}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script, then run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263211172}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263283706}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite in background maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263283773}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Actually important"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263283829}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to validate the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263283871}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probe injection"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263358635}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works. Let me write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263358691}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a quick smoke test script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263358735}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" manually (not in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263358824}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verify? it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263439501}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s fine in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263439543}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263439661}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tmp). Use node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263439711}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263490478}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"e importing c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263490549}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"dp/pro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263490582}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"be."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263490625}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_7ecrqk9xsu5ef3tazomxpb8l","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263490750}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263490910}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263490966}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263491014}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263491119}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263491167}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263491562}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263491619}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263534016}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263534076}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263534130}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263534244}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263534621}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263534707}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263534843}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263534896}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263537888}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263537984}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263538072}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263538118}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263545610}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263545657}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263545758}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263545839}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263566827}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263566911}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263566979}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263567032}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263581140}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263581410}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263581515}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263581605}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263632110}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263632179}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263632283}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263632389}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263632492}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263632590}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263632683}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263632762}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263639804}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263639895}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263640018}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263640113}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263656880}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263657227}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263657292}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263657362}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263663937}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263664050}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263664121}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263664312}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263664356}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263664461}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263664501}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263664604}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717045}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717095}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717155}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717229}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717369}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717402}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717488}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717570}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263717676}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263718180}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263718232}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263718285}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263765054}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263765139}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263765246}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263765322}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263774157}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263774248}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263774324}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263774501}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263774619}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263774875}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" launch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263774984}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263775053}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263776525}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263776649}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263776808}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263776895}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263777009}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263777131}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263777264}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263777306}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263782347}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263782417}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263782484}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263782558}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263796163}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263796210}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263796280}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263796367}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263796916}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263796984}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263797137}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263797234}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263815697}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263815744}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263815813}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263815896}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263833627}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263833679}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263833794}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263833844}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263834733}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263834928}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263834975}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263835071}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263849917}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263849984}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263850039}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263850120}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263885745}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263885798}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263885848}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263885998}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263886742}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263886788}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263886870}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263886996}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263887751}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263887885}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263887993}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263888050}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263898005}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263898072}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263898133}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263898181}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263899417}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263899501}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263899565}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263899614}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263932294}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" inject"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263932334}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263932378}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"be"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263932416}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263947167}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263947215}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Until"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263947321}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263947361}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263947672}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263947711}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263947834}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263947877}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263966840}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263966933}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263967037}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263967128}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263978760}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263978836}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263978883}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263978946}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263981038}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263981086}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263981228}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263981269}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263994483}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263994578}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263994697}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123263994749}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264010240}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264010312}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264010385}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264010491}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264011053}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264011214}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264011259}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264011318}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264023950}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264024011}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264024057}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264024161}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264044217}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264044272}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264044312}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264044362}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264044742}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264044816}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264044924}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264044964}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264055733}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264055838}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264055911}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264056827}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264077097}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264077164}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264077220}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"be"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264077306}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264077627}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264077788}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264077831}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264077869}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264111196}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snapshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264111308}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Del"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264111382}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264111444}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"able"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264111662}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264111771}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264111828}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264111981}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264127518}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264127567}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264127627}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264127705}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264144338}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264144373}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264144495}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264144546}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264160105}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264160174}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264160233}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264160322}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264160418}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264160463}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264160537}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264160594}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264174546}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264174614}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264174677}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264174735}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264193769}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264193825}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264193869}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264193952}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264194239}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264194373}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264194460}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264194575}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264217531}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264217577}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264217688}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264217777}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264236316}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264236516}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264236584}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264236696}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264236870}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264237004}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264237131}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264237209}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264253670}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264253877}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264253926}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264253971}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264269695}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"works"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264269774}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264269863}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264269967}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264270048}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264270093}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264270178}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264270243}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264306751}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264306796}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snapshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264306842}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Del"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264306961}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264307101}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"able"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264307164}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264307294}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"label"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264307362}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264332245}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264332347}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264332503}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264332645}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264332735}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264332860}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264332973}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264333093}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264358765}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264358967}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264359131}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264359206}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264383902}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264384000}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264384103}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264384222}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264384370}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264384535}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264384592}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264384742}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264394658}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264394726}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264394775}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264394895}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264407921}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264407977}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" launch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264408098}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264408154}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264421263}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264421313}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264421353}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264421422}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264422198}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264422268}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264422428}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264422489}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264440951}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264441023}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264441091}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264441165}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264460349}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264460404}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264460533}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264460582}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264474277}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Page"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264474325}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264474380}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264474477}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264497825}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264497905}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"avigate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264497961}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264498121}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264498548}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264498714}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264498908}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264498984}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" inject"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264513760}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264513816}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"be"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264513862}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264513917}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264536295}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264536353}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264536420}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264536486}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264553254}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264553414}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264553485}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264553578}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264565367}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264565428}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264565527}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"State"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264565671}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264566815}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264566959}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264567030}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264567098}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264584656}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264584715}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264584829}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264584931}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264604872}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264604970}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264605031}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IFY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264605099}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264605410}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264605452}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"State"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264605613}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264605667}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264627773}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264627823}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264627862}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264627899}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264641242}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264641300}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264641425}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264641482}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264657010}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264657077}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264657161}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264657207}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264673954}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264674006}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264674075}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264674153}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264674579}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264674702}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ex"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264674753}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ceptions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264674861}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264749831}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264749889}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264749982}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264750145}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264762052}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264762116}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264762262}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"req"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264762335}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264773268}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264773347}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"requests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264773475}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264773521}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264775149}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264775278}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264775323}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264775486}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264782043}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"requests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264782102}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264782209}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264782274}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264783041}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264783095}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264783140}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"requests"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264783248}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264789249}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264789323}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264789553}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264789628}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264805406}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264805508}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264805595}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264805684}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264836278}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"overflow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264836349}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264836439}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264836534}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264851730}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264852015}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264852117}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264852200}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264852634}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264852680}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264852718}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264852786}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264863962}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IFY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264864116}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264864220}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"overflow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264864288}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Scan"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264890036}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264890162}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264890244}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"items"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264890351}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264903155}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264903224}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264903285}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264903387}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264956746}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264956839}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264956915}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264956989}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264957303}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264957510}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264957725}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264957810}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264958575}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264958659}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264958843}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264958928}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264960216}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264960297}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264960506}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264960588}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IFY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264961009}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".mark"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264961212}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264961382}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264961567}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264965655}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264965909}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264965998}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264966175}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264990776}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264990874}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"shot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264990937}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264991012}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264991218}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264991452}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264991530}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123264991682}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265019857}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265020116}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265020187}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265020366}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265034246}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265034352}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265034545}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265034647}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265034964}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".close"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265035059}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265035257}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265035460}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265056497}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265056668}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265056846}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265057010}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265095747}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265096159}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265096203}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265096287}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265096367}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265096492}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265096659}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265096819}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265096957}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265097097}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265097201}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265097298}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265109565}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265109677}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265109806}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265109934}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265120109}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265120213}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265120290}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265120347}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265137400}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265137475}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265137584}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265137727}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265158027}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265158093}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265158610}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" driver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265158729}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265186474}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" probe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265186536}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265186608}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1956,"ts_us":1793123265186665}}

data: {"id":"5cc7a10c36ad515d6c35550c14d7f025","object":"chat.completion.chunk","created":1793123262,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":98500,"completion_tokens":649,"total_tokens":99149,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":78976,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":106,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1956,"ts_us":1793123265235880}}

data: [DONE]

