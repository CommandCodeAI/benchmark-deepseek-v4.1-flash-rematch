data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228354577}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228389325}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228389604}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug in script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228389697}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228455654}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll metrics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228455738}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" afterward. View screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228456005}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228456271}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_a8iq0i4kg3plcm21tss2cjkp","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228516476}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228516585}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228516672}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228516924}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228517007}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228517371}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228517469}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228517564}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228521905}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228522095}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228522371}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228522465}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228523070}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228523343}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228523431}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228523762}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228542730}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228542820}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228542897}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228543052}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228553178}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228553283}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228553365}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228553503}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228571720}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228571831}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228571923}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228572097}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228573419}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228573504}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228573583}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228573872}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228759896}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228759977}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228761528}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228761584}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228761632}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228761679}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228761724}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228761764}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228761829}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228762095}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228762161}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228762215}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228762267}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228949748}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228949799}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228949842}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228949891}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228949926}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228949969}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228950013}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228950350}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228950416}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228950456}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228950510}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124228950553}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124229138105}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124229138164}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124229138200}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20508,"ts_us":1793124229138249}}

data: {"id":"55f757d9e02827f8a49ce3662cf0f73d","object":"chat.completion.chunk","created":1793124228,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":244453,"completion_tokens":103,"total_tokens":244556,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":241792,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":14,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":20508,"ts_us":1793124229138320}}

data: [DONE]

