data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021234917}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_92gw4h272k3h9mvxqnxlfyq9","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021307394}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021307472}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021307531}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021307587}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021307643}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021307706}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021307791}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021330185}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021330261}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021330341}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021330388}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021340909}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021341000}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021341095}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021341139}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021353557}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021353611}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021353959}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021354030}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021354101}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021354225}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021354271}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021354315}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021369894}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021369964}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021370030}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021370080}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021393009}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021393085}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021393206}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021393267}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021393624}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021393686}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021393772}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021393814}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021408645}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021408713}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021411137}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021411207}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021422079}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021422154}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021422216}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021422276}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021437476}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021437524}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021437568}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021437615}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021438104}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021438218}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021438261}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021438309}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021459232}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021459288}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021459361}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021459418}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021474962}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021475015}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021475059}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021475105}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":18588,"ts_us":1793124021576549}}

data: {"id":"8ba910e5436937501268dcabed6f51cd","object":"chat.completion.chunk","created":1793124021,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":190419,"completion_tokens":88,"total_tokens":190507,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":189824,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":18588,"ts_us":1793124021576651}}

data: [DONE]

