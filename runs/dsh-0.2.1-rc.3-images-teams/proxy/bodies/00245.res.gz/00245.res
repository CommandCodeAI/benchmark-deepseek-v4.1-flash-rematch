data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386563335}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386626649}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386626714}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386627942}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 match page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386706200}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386706254}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 hash differs: node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386706297}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386707796}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fda9d56"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386765088}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs page 374865"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386765176}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"97, counts same."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386765272}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So divergence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386765317}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appears at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386848202}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 5 *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386848253}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"in hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386848298}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"* only,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386848651}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but counts same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386912820}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386912895}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be subtle differences in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386913022}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" agent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124386913408}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387030165}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or PR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387030210}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NG state. Page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387030249}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387030321}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387057921}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387058116}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387058178}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash. This suggests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387058339}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state divergence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387125189}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387125237}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 5 due to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387125365}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" something external"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387125413}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modifying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387209699}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387209752}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state. What external"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387209790}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387209877}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The renderer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387310389}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387310470}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls reading"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387310527}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Maybe the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387311128}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **renderer sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387341939}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" properties"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387342016}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on agents**? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387342073}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387343173}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" WeakMap only. Controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387442023}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387442072}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387442250}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWait, hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387442299}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387498125}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387498193}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" agent genes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387498248}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387498384}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"energies/positions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387563192}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; maybe one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387563242}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run's simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387563287}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" got"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387563395}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interrupted by `step"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387686366}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387686449}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387686492}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nDifference appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387686581}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387701171}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5; first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387701294}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4 hashes match"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387701347}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". What happens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387701587}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen 5? Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387759421}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387759495}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen 8,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387759550}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so no. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387759614}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387821720}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at some point"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387821792}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls `ctx"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387821844}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".setParam('speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387822788}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"', ...)` with a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387892760}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" value?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387892832}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No effect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387892908}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on state hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387893030}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387958524}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes config?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387958594}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No, hashWorld"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387958727}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't include config,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124387958793}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only state. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388026366}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388026417}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388026474}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"nextEvent etc."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388026542}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Speed not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388091517}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" included. So not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388091565}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388091607}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er draws and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388091668}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutates plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388152700}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388152735}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out arrays? It iter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388152817}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ates but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388153163}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no mutation.\n\nCould the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388245126}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388245206}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388245254}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388245348}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388338167}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` or `update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388338216}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388338273}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ensus` mutate?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388338315}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No.\n\nWait: page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388370758}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388370886}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script ran"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388370942}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `W"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388370988}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".runGeneration(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388432686}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")` "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388432765}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 times."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388432825}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388432919}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that, page was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388500874}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388500969}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with auto="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388501000}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 but **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388501217}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"the frame loop may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388573368}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still have advanced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388573427}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388573488}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?** We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388573524}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388647251}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=0 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388647325}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388647400}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".paused=true, loop doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388647558}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t run. Before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388726980}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388727056}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388727162}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mounted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388727239}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388790279}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nH"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388790335}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm hash difference"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388790384}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388790694}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 with identical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388851476}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388851551}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" subtle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388851611}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numeric differences. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388851717}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could stem"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388915560}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from **different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388915619}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" JS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388916038}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engines**"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388916084}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388985387}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V8 node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388985446}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs Chrome) with floating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388985508}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" point operations? Both V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124388985587}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8 versions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389052163}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differ ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389052211}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Node 24 vs Chrome version"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389052237}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389052421}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389118720}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Math.log"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389118771}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`, `Math"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389118905}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".sin`, `Math.sqrt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389119008}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`, `Math.exp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389213493}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` may produce slightly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389213577}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" different results across versions."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389213649}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Genome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389213776}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389253151}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses `Math.sqrt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389253211}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(-2*Math"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389253319}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".log(u))`,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389253386}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `Math.sin`, `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389352021}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Math.cos`. Tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389352066}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" floating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389352104}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differences could alter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389352140}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" positions/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389398502}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"energies at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389398569}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389398627}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1e-16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389399382}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" level, changing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389487300}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash after rounding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389487398}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389487549}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.001 occasionally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389487597}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389538507}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389538628}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remain same until later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389538693}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389538750}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" divergence accumulates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389609271}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389609315}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389609432}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same browser/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389609632}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"process still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389658293}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" holds, but cross"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389658354}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-engine bit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389658465}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-ex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389658505}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actness isn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389722400}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t guaranteed. The requirement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389722447}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"same seed always"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389722490}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduces same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389722531}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run\" likely means in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389791518}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389791578}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same app/browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389791625}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; cross-b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389792399}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowser minor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389870998}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differences acceptable?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389871047}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389871119}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ideally make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389871158}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine bit-re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389931845}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"producible by avoiding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389931897}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" transcendental"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389931933}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" functions for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124389931969}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390016663}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" randomness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390016712}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? But deterministic expectations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390016752}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390016938}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390092022}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same-engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390092095}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node test pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390092157}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390092480}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390155103}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node mismatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390155158}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390155206}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390155276}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" divergence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390260693}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eventually due to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390260738}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chaotic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390260905}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390260950}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That's okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390316145}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390316206}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" principle, but if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390316259}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the user repl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390316430}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ays in the same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390409836}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser, deterministic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390409885}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (same JS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390409924}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine). Two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390409966}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" different browsers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390461971}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may diver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390462019}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ge; requirement could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390462059}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be interpreted strictly."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390462250}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" To be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390525593}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" safe, reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390525678}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sensitivity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390525780}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to transcendental"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390525835}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" functions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390584583}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The `g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390584706}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"auss()`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390584787}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses Math.log"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390584862}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/sqrt/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390669104}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"in/cos; these"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390669195}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are specified"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390669335}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390669377}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" implementation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390735738}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390735829}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"approximated,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390735902}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so cross"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390735998}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390804521}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differences. Also `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390804575}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Math.cos/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390804678}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"in` for movement."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390804716}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could use an"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390874036}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" integer-based"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390874124}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PRNG and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390874176}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rational"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390874283}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" approximations for g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390972435}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aussian? Overkill."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390972484}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Most web"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390972543}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" demos don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124390972596}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t guarantee cross-engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391011877}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bit-ex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391011939}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391011985}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391012123}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier tested"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391077026}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same engine;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391077096}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391077157}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reload"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391077205}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same Chrome will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391154382}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" match. I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391154428}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391154464}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replay same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391154839}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391206474}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser yields identical;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391206541}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391206697}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391206730}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391277478}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" across"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391277560}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391277618}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in same browser."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391277696}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Likely yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391377693}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBut the final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391377746}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391377789}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" difference ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391377873}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"447"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391416631}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391416708}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 84) is huge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391416774}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due to chaos"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391417155}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391475062}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the deliverable,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391475116}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391475243}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" showcase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391475300}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391652654}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 185"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391652713}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9 was chosen based"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391652747}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on node;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391653289}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391678124}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome produces "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391678189}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"84/215"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391678328}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/20. That's less attractive (sp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391678382}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arse flora at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391713196}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end). Hmm. We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391713262}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could pick default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391713360}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" based on *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391713416}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Chrome* behavior"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391775108}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391775172}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not node, since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391775232}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" users"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391775327}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391844617}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391844690}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Or aim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391844760}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391844818}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run that is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391922428}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" robust across both."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391922502}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391924907}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed choice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124391924948}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392066355}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be validated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392066402}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in Chrome. Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392066440}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859 at page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392066480}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ending"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392143483}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": 84 flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392143543}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 215 herb,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392143613}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20 carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392143665}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — sparse plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392143710}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392143780}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392143849}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392143893}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ideal dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392195187}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392195237}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392195273}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still dramatic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392196375}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392256510}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ends with predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392256555}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392256741}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392256783}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392330625}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will show final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392330696}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392330749}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"84/215/20."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392330809}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392438209}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s inspect lead-record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392438261}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-01.png."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392438372}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_u2133d5hbzt8m817ps4uoxwi","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392438429}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392479308}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392479394}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392479463}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392479539}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392479822}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392480199}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392480270}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392480338}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392480403}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392480473}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392480522}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392481216}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392481271}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392481340}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392481413}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392481447}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392492452}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392492536}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392492611}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392492663}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392493701}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392493772}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392493834}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392493957}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392512380}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392512465}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392512548}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392512627}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392532846}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392532925}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392532986}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392533045}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392533712}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392533787}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392533838}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392533943}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392545506}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392545562}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392545621}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392546120}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392559678}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392559743}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392559801}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392559891}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392560536}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392560662}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392560739}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392561004}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392576978}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392577049}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392577106}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392577490}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392589669}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392589748}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392590002}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"01"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392590049}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392665690}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392665768}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20503,"ts_us":1793124392665829}}

data: {"id":"3586fb44eda13c70dab3696bd7b908d8","object":"chat.completion.chunk","created":1793124386,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":254186,"completion_tokens":984,"total_tokens":255170,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":253568,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":896,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":20503,"ts_us":1793124392671216}}

data: [DONE]

