data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124834971578}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"API"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835059771}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is `window.__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835059820}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIVARIUM__.actions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835059861}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".conclude()`. Run again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835141702}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835141835}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xg1tyzk1lf7mbv49care4k92","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835141926}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142044}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142101}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142210}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142354}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142424}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142594}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142670}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142784}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142834}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142875}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142919}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142971}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835142998}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835149070}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835149135}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835149265}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835149406}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835150139}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835150221}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835150308}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835150380}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835163666}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835163760}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835163852}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835163924}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835180820}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835180904}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835181017}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835181128}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835223348}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835223397}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835223446}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835223495}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835225808}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835225854}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835225899}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835225938}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835239082}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835239134}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835239177}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835239294}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835241211}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835241394}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835241571}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835242153}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835251715}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835251767}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835251882}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835251994}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835265784}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835265953}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835266025}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835266127}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835266731}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835266809}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835266935}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835267035}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835283627}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835283694}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835283726}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835283817}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835317230}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835317400}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835317498}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835317612}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835317732}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835317853}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835317972}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835318101}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835318196}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835318245}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835318359}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835318465}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835341995}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835342041}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835342081}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835342168}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835353567}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835353617}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835353722}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835353767}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835371547}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835371595}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835371711}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835371757}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835389553}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835389626}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835389752}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835389854}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835401310}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835401379}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835401566}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835401615}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835402378}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835402495}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835402552}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835402607}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835459830}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835459887}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835460405}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835460495}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835479919}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"150"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835479996}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835480092}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835480187}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835480283}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835480394}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835480494}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835480598}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835484535}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835484642}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835484734}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835484833}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835486125}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"actions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835486202}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".con"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835486256}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"clude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835486287}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835496278}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835496321}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"con"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835496411}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cluding"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835496494}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835515353}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835515400}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835515449}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835515497}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835528156}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"360"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835528196}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835528245}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835528290}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835548499}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835548546}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835548629}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835548683}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835569025}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835569114}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835569204}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835569294}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835612994}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835613215}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835613264}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835613321}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835619491}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835619542}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Con"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835619673}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"clude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835619718}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835630472}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" screenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835630565}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835630659}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835630701}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835636369}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835636416}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835636514}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835636609}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835709921}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8989,"ts_us":1793124835710009}}

data: {"id":"1f49a14d86ab18a519759da2d6508ebd","object":"chat.completion.chunk","created":1793124834,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":222633,"completion_tokens":209,"total_tokens":222842,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":222208,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":18,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":8989,"ts_us":1793124835710142}}

data: [DONE]

