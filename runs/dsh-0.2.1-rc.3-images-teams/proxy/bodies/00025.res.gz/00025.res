data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723207987}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723208337}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me claim task-1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723208390}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_y3wcc37piaz80ohkioqunv1e","type":"function","function":{"name":"team_task_update"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723208439}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723208558}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723208643}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723208711}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723222336}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723222463}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723222878}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723222962}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723258724}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723258804}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723258898}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723259076}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723259249}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723266998}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"expected"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723267069}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723267134}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723321575}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723321683}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723321749}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723321957}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723322354}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723329915}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"action"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723329984}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723330039}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723359263}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723359406}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"claim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723359461}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723360151}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1323,"ts_us":1793122723390448}}

data: {"id":"3f49b04e9dbaa1a9a5af108c297a8d7b","object":"chat.completion.chunk","created":1793122723,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":24318,"completion_tokens":83,"total_tokens":24401,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":22272,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":7,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1323,"ts_us":1793122723390672}}

data: [DONE]

