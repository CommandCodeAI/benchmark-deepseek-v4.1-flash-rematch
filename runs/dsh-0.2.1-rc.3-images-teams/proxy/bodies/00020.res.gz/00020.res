data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715032056}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715108324}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715108373}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" look at the source files"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715108410}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176334}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_5vktyc7q9hjs2c0acw338dsy","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176390}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176437}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176482}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176532}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176718}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176766}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176821}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176861}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715176911}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715177000}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715177040}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715235352}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715235407}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715235442}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715235489}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715235883}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715235963}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715236070}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715236170}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715272375}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715272445}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715272484}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715272526}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715273045}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715273169}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715273310}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715273389}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715292599}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715292644}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"short"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715292699}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715292748}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715293210}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715293277}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715293335}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715293386}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eline"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715297241}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715297328}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715297368}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715297436}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715344093}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715344176}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715344228}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715344272}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715347595}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715347684}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"List"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715347879}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" source"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715347939}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715357467}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715357518}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" directories"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715357563}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715357608}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715386756}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715386832}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715386896}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715386956}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_eofwm8ivxkj4dlwtb0se6krv","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715426698}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715426754}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715426791}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715426842}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715440257}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715440307}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715440356}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715440450}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715459904}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715459982}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715460049}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715460116}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715473843}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715473894}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715473934}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715473972}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715488434}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715488525}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715488598}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715488656}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715509305}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715509377}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715509504}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715509576}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715537450}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715537524}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715537587}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715537660}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715537962}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715538025}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715538084}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715538186}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715548375}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715548453}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715548516}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715548565}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715567871}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715567935}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715567989}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715568041}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715569064}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715569135}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715569170}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715569217}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715585916}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715585965}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715586039}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715586117}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715601926}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715601976}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715602015}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715603998}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715620254}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715620315}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715620362}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1152,"ts_us":1793122715620424}}

data: {"id":"85ac8ff9eefd0ed5b0b4ac94bd92cabf","object":"chat.completion.chunk","created":1793122714,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":14495,"completion_tokens":172,"total_tokens":14667,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":7808,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":9,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1152,"ts_us":1793122715664561}}

data: [DONE]

