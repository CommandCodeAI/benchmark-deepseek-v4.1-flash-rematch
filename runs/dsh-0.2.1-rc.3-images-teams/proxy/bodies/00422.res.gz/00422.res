data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134806506}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_phccxoqvwuhvhck20e9fz0rn","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134899186}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134899257}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134899328}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134904101}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134904210}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134904378}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134904471}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134917575}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134917668}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134917723}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134918059}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134919594}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134919837}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134919981}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134920050}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134932864}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134933108}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134933254}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134933317}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134946266}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134946318}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134946375}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134946421}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134946491}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134946546}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134946648}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134946724}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134977343}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134977424}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134977476}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134977675}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134987813}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134987896}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134987992}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134988140}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134989040}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134989272}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134989336}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126134989458}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135011444}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135011495}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135011686}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135011777}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135024586}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135024671}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135024744}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135024988}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135025036}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135025274}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135025345}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135025694}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135051723}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135051780}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135051885}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-density"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135051936}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135066921}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135066973}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135067169}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135067370}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42704,"ts_us":1793126135145970}}

data: {"id":"ab85759de32bd473ca162dd8f4dcd177","object":"chat.completion.chunk","created":1793126134,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":325768,"completion_tokens":88,"total_tokens":325856,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":324608,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":42704,"ts_us":1793126135146099}}

data: [DONE]

