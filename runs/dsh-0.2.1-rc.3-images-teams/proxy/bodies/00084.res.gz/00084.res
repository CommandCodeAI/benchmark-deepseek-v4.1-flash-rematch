data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316390610}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316482148}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" findings about"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316482221}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine implementation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316482272}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316546698}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" API exposes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316546763}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `sn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316546820}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apshot` instead of `get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316546868}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Snapshot`, `getActive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316677365}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events` instead of `active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316677465}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events`, no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316677577}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `stepGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316677672}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316732069}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Missing from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316732142}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contract: `get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316732274}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Snapshot`, `active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316732404}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events` field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316791476}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", `stepGeneration`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316791532}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The brief contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316791625}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316791668}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explicit; these"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316846313}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316846387}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deviations. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316846593}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316846663}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316959908}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"snapshot`/`get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316959964}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ActiveEvents`; chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316960018}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123316960081}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might use world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317021651}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".activeEvents?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317021709}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Contract says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317021769}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world.active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317021823}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events. If dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317073278}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expects `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317073319}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world.activeEvents`, it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317073471}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317073515}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317125564}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317125640}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Lead should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317125688}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317125736}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aliases to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317217920}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" satisfy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317217967}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contract ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317218024}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cheap:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317218125}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" getSnapshot ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317290186}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" snapshot, stepGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317290234}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = runGeneration, world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317290351}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".activeEvents get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317290395}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ter or maintain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317342735}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" array)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317342799}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Notify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317342946}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317342986}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317410714}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317410770}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less stops at config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317410846}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generations. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317410907}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s correct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317472188}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" behavior arguably"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317472499}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (world finishes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317472555}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). My tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317472631}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317539151}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generations >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317539247}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens.\n- history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317539294}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317539404}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317617108}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317617159}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → length gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317617211}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+1; first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317617273}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317676923}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0. Good.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317676972}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317677007}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317677070}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317797881}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317797926}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317797963}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keeps one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317797998}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history gen-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317853199}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 entry. Accept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317853243}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able.\n- extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317853279}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317854301}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" null when count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317903955}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 (e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317904019}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g., carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317904069}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317904105}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317980627}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" null)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317980673}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Accept if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317980707}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123317980756}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.\n- active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318039155}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events undefined"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318039202}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318039240}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318040832}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318111102}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318111146}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318111182}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"active via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318111283}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318174632}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ActiveEvents."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318174727}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Contract deviation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318174830}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318174975}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"major"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318243511}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318243736}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318243786}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reads world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318243825}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".activeEvents). I need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318336438}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to check dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318336495}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318336534}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- events gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318336587}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiples"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318394860}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of interval exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318394926}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318394983}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- benchmark ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318395037}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318455673}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Sec ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318455770}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1200 (f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318455838}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aster than real time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318455888}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n- run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318514465}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318514508}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 gens took"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318514640}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 862ms in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318514699}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318582915}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318582977}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318583026}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations=40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318583124}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (stopped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318703972}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 40 → "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318704021}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"862ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318704058}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for 40 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318704142}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). With generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318769615}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=100 it's ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318769674}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.5s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318769725}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318769815}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ms 2492"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318834948}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). So speed test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318835016}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318835069}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318835125}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 gens ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318893601}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.5s → fails"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318893645}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318893683}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" <200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318893716}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0ms. Task"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318956319}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says \"head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318956417}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less speed (e.g."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318956523}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 gens under ~1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123318956623}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s)\" — engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319004233}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319004282}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slower:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319004401}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319004459}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319087932}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319088003}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319088059}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319088210}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319191042}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319191090}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319191145}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319191180}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens/s →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319244168}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319244259}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319244464}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for 100 gens;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319244568}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319291178}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.5s is "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319291270}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20x faster than real time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319291336}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so acceptable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319291403}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319343338}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aster than real time\" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319343423}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319343493}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319343556}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1s. I'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319399274}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set threshold:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319399343}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319399395}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" < 5s AND"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319399441}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticksPerSec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319454986}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" > 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319455039}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319455078}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"altime). Report actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319455131}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319535444}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" severity to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319535509}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" MINOR/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319535557}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"MAJOR note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319535599}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319638424}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319638474}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": \"headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319638548}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs faster than real time\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319638610}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319699384}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319699445}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319699494}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319699547}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.5s vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319764089}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319764138}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"50s realtime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319764201}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓. Task"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319764248}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319826907}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"~1s\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319826952}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is indicative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319826991}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319827034}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assert"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319875708}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" < 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319875751}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319875803}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319875850}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actual 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319937683}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5s.\n\n- B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319937759}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319937812}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123319937849}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320010529}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320010578}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320010657}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200 config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320010730}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needed.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320066207}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B11: active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320066252}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320066295}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320066384}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ActiveEvents(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320139999}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") or world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320140063}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320140122}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"weather?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320140166}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320188854}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" signatures"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320188984}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" briefly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320189062}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also snapshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320189131}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" function"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320292385}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". And fire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320292437}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320292498}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe. Let me query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320292558}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine intern"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320355986}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"als for get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320356106}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ActiveEvents/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320356146}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"napshot/getStats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320356221}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outputs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320447224}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320447276}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320447384}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"setParam"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320447455}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` works ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320506303}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320506381}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12 got to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320506438}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" getSnapshot error"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320506473}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320661669}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320661741}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320661782}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"... Actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320661845}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config.m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320721740}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"utation check passed?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320721789}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The failure was at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320721825}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320721862}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".getSnapshot`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320780997}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320781042}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320781078}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param assertions,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320781148}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so setParam works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320842040}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n\nLet me inspect get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320842085}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Stats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320842122}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320842163}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" snapshot, getActiveEvents and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320899114}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weather."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320899189}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320899245}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check world."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320899291}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"weather contents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320971975}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320972027}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320972087}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event. Then update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123320972166}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests accordingly and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321050085}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adapt validator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321050143}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nThen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321050253}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321050344}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests again."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321115229}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_wbruvuv1ve9w4n3zo4u4haut","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321115293}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321115397}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321115495}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321115903}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321115993}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321116110}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321116245}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321116292}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321116442}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321116495}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321116582}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321116683}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321117738}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321117867}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321117954}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321118046}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321118125}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321118187}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321118281}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321118379}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321118455}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321118523}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321118586}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321124847}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321124904}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321124955}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321125458}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321125566}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321125624}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321125725}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321125795}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321251098}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321251147}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321251219}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321251277}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321252099}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321252164}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321252237}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321252303}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321254832}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321254891}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321255046}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321255112}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321256697}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321256774}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321256843}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321256893}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321266240}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321266350}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321266464}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321266579}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321267898}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321267955}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321268066}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321268137}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321271195}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321271246}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321271299}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321271364}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321273859}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321273988}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321274095}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321274189}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321279958}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321280001}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" './"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321280044}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321280090}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321280717}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321280763}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321280867}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321280960}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321290005}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321290055}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321290099}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321290161}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321310140}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321310187}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321310235}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321310274}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321333748}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321333795}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321333857}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321333908}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321352584}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321352660}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321352714}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321352761}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321353326}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321353383}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321353499}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321353583}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321373882}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321373931}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321374099}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321374171}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321382640}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321382715}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321382783}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321382852}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321384007}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321384077}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321384135}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321384182}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321400672}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321400719}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321400760}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321400836}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321424227}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321424289}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321424344}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321424400}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321437667}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321437714}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321437756}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321437896}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321496359}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321496411}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321496453}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321496505}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321497871}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321497925}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321497995}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321498158}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321510853}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321510905}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321510948}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Stats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321510988}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321546620}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321546672}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321546735}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321546788}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Stats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321563169}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321563215}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321563259}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321563320}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321563957}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321564090}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321564137}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321564219}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321582384}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321582456}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321582509}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321582555}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321599289}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321599334}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321599396}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321599447}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321620277}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321620338}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321620385}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321620439}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321620863}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321620912}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321620992}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321621036}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321634829}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321634876}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321636460}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"weather"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321636525}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321720932}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321721036}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321721081}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321721124}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321741151}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"weather"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321741198}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321741238}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321741281}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321741322}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321741361}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321741402}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321741449}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321745486}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321745534}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321745579}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321745618}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321748806}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321748852}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321748915}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321749057}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321749492}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321749537}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321749633}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321749732}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321755960}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321756019}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321756076}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321756125}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321756693}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321756782}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321756833}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321756940}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321765420}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321765476}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321765518}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321765570}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321765916}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321766039}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321766083}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321766177}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321786152}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321786234}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321786309}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321786377}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321793371}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321793450}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321793497}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321793567}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321805815}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321805886}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321805943}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321806049}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321807640}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321807785}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321807974}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321808035}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321837755}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321837811}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321837857}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321837904}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321842625}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321842689}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321842775}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321842841}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321843590}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321843644}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321843797}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321843844}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321877769}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sample"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321877815}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321877856}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321877957}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321878110}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321878250}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321878408}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321878457}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321898617}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321898673}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321898835}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321898916}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"700"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321947572}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321947688}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321947773}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321947847}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321947931}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321948012}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Stats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321948171}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321948331}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321948461}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321948589}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321948650}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321948695}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Stats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321968909}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321968966}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321969041}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321969101}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321969198}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321969303}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321969427}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"700"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321969551}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321984947}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"//"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321984992}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321985093}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" during"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123321985259}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322002261}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322002313}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322002384}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322002444}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322020359}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322020404}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hist"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322020499}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322020585}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322040441}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322040512}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322040637}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322040733}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322053974}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322054020}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322054102}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322054207}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322078336}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322078408}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322078454}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322078525}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322098233}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322098299}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322098348}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322098388}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322116961}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322117009}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322117051}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322117193}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322136392}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322136434}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322136478}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322136544}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322155675}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322155721}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322155773}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322155815}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322156083}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322156205}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322156348}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322156414}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322174074}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322174151}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322174377}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"//"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322174526}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" signature"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322209184}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322209316}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322209409}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Param"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322209597}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322250448}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322250539}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322250618}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322250696}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322281524}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322281600}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322281658}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322281706}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322297478}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322297548}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322297604}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322297637}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322298252}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322298303}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322298343}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322298426}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322314820}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322314876}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322314938}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322315008}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322332489}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Param"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322332568}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322332641}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322332769}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322347089}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322347164}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Param"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322347223}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322347274}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322347498}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322347630}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322347698}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322347809}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322363290}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322363349}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322363467}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322363522}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322375865}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322375937}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322376046}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"//"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322376112}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catastrophe"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322411293}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" effect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322411341}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" compare"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322411426}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322411511}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322440879}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322440940}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322440993}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322441048}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322441399}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322441484}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322441616}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322441660}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322474040}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322474107}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322474160}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322474203}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322493178}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322493225}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322493354}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322493403}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322506108}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322506187}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322506252}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322506327}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322506775}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322506927}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322506979}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322507105}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322521305}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322521374}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322521435}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322521476}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322540021}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322540072}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322540620}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322540670}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322540789}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322540847}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" off"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322540896}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322540932}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322553119}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322553205}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322553280}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322553347}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322572905}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322572983}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322573054}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322573121}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322573325}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322573391}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322573444}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322573495}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322590570}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322590630}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322590671}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322590711}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322609975}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322610048}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322610111}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322610163}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"false"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322610673}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322610776}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322610900}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322610976}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322627254}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322627312}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322627362}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"off"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322627428}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322644884}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322645012}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322645077}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322645117}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322645693}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322645738}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322645781}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322645820}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322678256}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322678329}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322678396}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322678544}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322687736}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322687828}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322687917}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"off"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322688007}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322689613}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322689706}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322689853}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322689986}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322702941}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322703001}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"off"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322703049}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322703109}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322720336}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322720381}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322720454}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322720535}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322740469}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322740534}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322740574}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322740658}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322756493}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322756563}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322756614}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322756721}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"off"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322766233}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322766280}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322766322}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322766423}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322767013}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"off"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322767102}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322767285}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322767326}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322802359}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322802437}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322802505}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322802569}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322822937}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322823041}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322823120}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322823189}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322871143}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322871229}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322871276}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322871341}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snapshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322872331}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322872423}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ats"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322872596}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322872650}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"weather"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322887744}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" APIs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322887803}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322887914}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1503,"ts_us":1793123322887969}}

data: {"id":"defa3085008c2c1b880187ac64673fc9","object":"chat.completion.chunk","created":1793123316,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":104466,"completion_tokens":1209,"total_tokens":105675,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":101888,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":691,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1503,"ts_us":1793123322929985}}

data: [DONE]

