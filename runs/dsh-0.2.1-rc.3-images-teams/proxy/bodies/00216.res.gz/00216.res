data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124137936159}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124137997316}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124137997395}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124137997503}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shorthand"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138037802}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" innerH bug"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138037857}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Screenshot captured"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138037914}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" anyway. Let's view it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138037986}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138124169}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_k8a8b7leehdghx0fqrwhihqp","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138124258}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138125637}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138125703}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138125757}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138125835}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138125894}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138125947}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138148609}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138148692}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138148755}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138148808}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138148862}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138148965}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138149043}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138149131}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138149271}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138149402}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138149573}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138149634}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138168515}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138168659}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138168705}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138170529}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138170652}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138170701}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138170800}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138170873}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138178050}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138178173}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138178322}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138178376}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138191663}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138192502}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138192554}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138192661}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138192766}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138192857}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138192908}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138201207}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138223397}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138224224}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138225789}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138225889}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138225960}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138226050}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138226146}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138226225}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138272250}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138272345}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138272403}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138272489}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138277523}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138277591}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138277641}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138277711}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138277789}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138277862}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"01"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138277999}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138278147}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138321618}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5486,"ts_us":1793124138322353}}

data: {"id":"d1342b96449eb0cbe462531898ef2fac","object":"chat.completion.chunk","created":1793124137,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":236000,"completion_tokens":108,"total_tokens":236108,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":232064,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":19,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":5486,"ts_us":1793124138322469}}

data: [DONE]

