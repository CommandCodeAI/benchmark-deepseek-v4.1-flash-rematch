data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922582560}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"All"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922779410}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" green on latest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922779486}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modules. One"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922779739}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" thing to check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922851934}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": C4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922851979}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `cursor:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922852035}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1` — `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922852084}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"#rule-cursor.get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922905575}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"BoundingClientRect().width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922905643}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` = 1px?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922905698}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Cursor may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922905743}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922976998}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" thin line;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922977057}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922978618}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125922978672}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923027599}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923027643}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check only needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923027688}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923027738}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fine.\n\nE2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923087697}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wash opacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923087745}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.009 at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923087789}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923087826}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923157883}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"just started"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923157922}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"); class"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923157974}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" present."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923158028}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could improve by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923236764}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" settling but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923236810}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923236878}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 evidence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923236943}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923324465}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (class +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923324534}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923324599}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923324642}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ue tint). However for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923440609}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report claim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923440654}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"wash "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923440688}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6-8%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923440723}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" opacity\" let me later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923511444}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capture actual opacity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923511530}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mid-w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923511635}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ash: sleep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923511707}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923571913}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms after detect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923571958}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923571990}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923572032}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Minor.\n\nG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923644587}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-SK"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923644631}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IP rect y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923644665}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=-60 (skip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923644699}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" link"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923708682}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" offscreen before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923708755}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923708808}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923708859}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923775384}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923775449}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923775494}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" passes because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923775540}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923833655}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923833702}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923833745}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923833789}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923897995}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Lead needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923898047}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to reassemble."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923898101}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923898134}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923958304}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n2. Prepare REPORT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923958402}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923958472}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125923958532}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ill.\n3."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924027340}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Capture event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924027431}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924027501}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924029766}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" settled one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924120412}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924120476}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 (should be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924120522}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924120587}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ible now)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924181827}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_5jerh9wg78vn9zol420l0mgr","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924181892}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924181939}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924181990}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182042}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182127}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182171}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182230}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182338}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182411}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182743}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182789}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182868}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182922}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924182981}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183019}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183061}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183137}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183187}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183260}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183327}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183369}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183581}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924183632}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924203213}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924203257}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924203354}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924203435}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924220585}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924220644}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924220686}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924220744}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924234038}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924234235}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924234279}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924234329}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924234387}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924234454}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924234515}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924234666}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924250802}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924250852}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924250906}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924250971}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924267382}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924267449}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924267506}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924267564}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924289439}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924289495}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924289540}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924289625}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924290002}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924290087}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924290136}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924290322}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924325774}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924325827}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924325893}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924325941}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924347205}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924347288}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924347368}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21798,"ts_us":1793125924347414}}

data: {"id":"6ce747c5f12ab376f82a5b33bd9a925c","object":"chat.completion.chunk","created":1793125922,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":321339,"completion_tokens":289,"total_tokens":321628,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":319104,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":198,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":21798,"ts_us":1793125924410708}}

data: [DONE]

