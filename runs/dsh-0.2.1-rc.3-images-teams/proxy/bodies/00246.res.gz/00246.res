data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405231627}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"All"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405316606}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405316675}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405316730}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" without exceptions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405397172}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405397251}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405397305}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me view empty/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405397348}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"onegen/flat/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405461707}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"barren screenshots (maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405461761}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2 at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405461798}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a time)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405461838}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8qgm7uqxmf5i7pqmvixh5pwx","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405461893}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405461953}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405462035}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405462085}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405462160}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405462243}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405462363}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405464418}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405476461}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405476539}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405476612}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405476697}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405493615}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405493689}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405493819}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405493869}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405516887}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405516965}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405517021}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405517063}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405534739}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405534831}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405534906}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405534980}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405535397}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405535463}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405535606}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405535673}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405554263}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405554345}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405554438}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405554518}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405573929}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405574020}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405574083}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405574162}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405574715}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405574788}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405576482}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405576533}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405589441}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405589524}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405589609}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405589657}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405616292}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405616418}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405616503}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405616579}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405627218}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405627325}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405627400}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405627470}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405645739}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405645850}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-one"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405645936}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405646014}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405703497}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405703598}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34864,"ts_us":1793124405703684}}

data: {"id":"99d44d33414a906e0120298fb6a04167","object":"chat.completion.chunk","created":1793124405,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":209753,"completion_tokens":115,"total_tokens":209868,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":208000,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":28,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":34864,"ts_us":1793124405708614}}

data: [DONE]

