data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345849062}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345921218}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345921259}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"static logs ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345921431}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345973704}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" takes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345973752}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345973830}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"70s)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345973899}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_4x9lptzokiw3a3i20fguntdo","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345973948}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345974000}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345974190}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345974243}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345974318}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345974385}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345974480}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345974529}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345989619}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"35"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345989671}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345989701}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125345989747}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346010833}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346010889}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346010926}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346010973}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346025698}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346025754}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346025828}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fficial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346025877}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346027456}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346027501}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346027551}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346027600}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346037292}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346037337}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346037443}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346037492}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346056258}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346056349}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346056419}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346056469}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346069006}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346069051}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346069099}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346069145}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346069401}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346069467}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346069534}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346069603}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346086381}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fficial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346086448}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346086490}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346086561}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346102940}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346103000}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346103051}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346103105}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346115116}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346115183}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346115227}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346115281}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346132722}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346132770}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346132825}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346132882}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346148908}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346148957}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346149016}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346151088}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346232628}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346232720}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20551,"ts_us":1793125346232805}}

data: {"id":"e435f29ca85225b2381615baec4a7329","object":"chat.completion.chunk","created":1793125345,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":303134,"completion_tokens":110,"total_tokens":303244,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":300800,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":12,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":20551,"ts_us":1793125346240663}}

data: [DONE]

