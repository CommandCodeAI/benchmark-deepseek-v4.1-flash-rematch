data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297810804}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Important"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297831551}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297831705}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1859 at 40 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297831852}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ended"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297872701}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297872798}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 84, herb "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297872945}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"215, carn 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297873001}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — but earlier seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297938620}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859 detail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297938869}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" said final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297938913}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 447/212"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297938947}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/47 with generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297999091}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297999417}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Why different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297999454}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Because at speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124297999610}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=8 and using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298100451}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298100559}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298100658}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Wait earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298100710}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed-m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298246416}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"emorable used"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298246541}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298246761}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".createWorld({seed,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298246825}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"generations:40})`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298274891}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298275082}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless; final "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298275258}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"447/212/47."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298275412}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Here the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298351017}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298351166}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" used"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298351334}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query `?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298351400}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed=1859&gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298442967}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=40&speed=8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298443061}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`; config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298443168}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations normalize="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298443211}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298509036}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Should match except"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298509136}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298509304}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differs (speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298509343}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=8 vs default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298607599}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2). Speed only affects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298607713}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298607994}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", not engine sim."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298608042}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298733642}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298733732}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298733878}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World` config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298734014}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes speed; does"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298828225}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed affect simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298828335}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No. Yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298828430}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final differs. H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298828487}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm, maybe because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298870561}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298870636}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298870800}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298870990}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"time ticks differ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298941434}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in R"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298941487}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NG consumption? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298941625}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine should be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124298941751}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deterministic regardless of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299007528}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chunking"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299007581}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299007684}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no rendering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299007724}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" affects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299080979}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299081027}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Our render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299081161}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er doesn't consume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299081402}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine PRNG."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299182130}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But boot's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299182280}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop uses `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299182322}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runTick`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299182480}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299226194}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" call controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299226315}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299226421}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"nderer,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299226481}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no RNG."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299296674}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299296774}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" different? Possibly the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299296917}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page's simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299297158}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299364582}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299364752}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run to gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299364913}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 in one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299364957}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" continuous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299442687}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sequence? It did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299442730}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299442798}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1200 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299442837}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Should be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299498028}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identical to run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299498163}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless.\n\nWait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299498335}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299498421}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed-m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299571479}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"emorable engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299571572}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299571710}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my latest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299571753}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" renderer/default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299637041}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed patches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299637177}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (no engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299637396}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299637434}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes, only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299698070}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299698194}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed?)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299698352}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299698562}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed engine seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299767557}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default only,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299767656}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299767760}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299768155}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299869483}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm.\n\nMaybe `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299869571}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299869767}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299869833}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299918195}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" param: `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299918262}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299918415}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=40`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299918485}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parsed;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299991354}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299991479}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299991658}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eng create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124299991719}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300127412}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" {seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300127577}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":185"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300127857}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9, generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300127959}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":40, speed:8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300157250}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"}. Earlier run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300157408}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300157867}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2. Speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300157950}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300230744}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no effect on simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300230911}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"... except `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300231123}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300231201}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".config.speed` is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300298078}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" included"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300298156}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in hash but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300298229}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300298298}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". No.\n\nMaybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300368270}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300368358}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ran"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300368529}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300368568}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed 8 but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300441185}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300441328}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300441435}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300441702}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" steps at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300505330}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"16/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300505516}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rame; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300505622}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300505937}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300565771}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300565855}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300565959}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/frame; with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300565998}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300640191}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ps fine. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300640280}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300640517}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks were skipped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300640575}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300702608}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"state.acc`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300702721}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exceeded? It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300702852}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300703194}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300773328}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" accumulated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300773429}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300773727}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 16;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300773767}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300836687}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" thrott"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300836775}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"les to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300836905}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" <15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300836954}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fps, dt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300920446}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300920553}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 90ms →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300920682}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 21"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300920986}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6 ticks,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300984530}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300984607}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" steps capped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300984722}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 16 and acc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124300984935}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" leftover;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301045794}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" leftover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301045910}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" accumulates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301046008}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301046126}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301126538}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ips except"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301126590}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301127275}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acc >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301127315}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 reset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301193032}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301193293}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless rendering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301193390}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301193594}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301370432}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lost? Steps cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301370475}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 16/tick and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301370553}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301370620}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301370688}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301370737}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"90; required"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301370781}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 21"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301370909}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6; acc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301454440}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":">10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301547847}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resets, losing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301547936}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301547990}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"11"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301548032}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301548079}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301548115}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame → tick count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301548151}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301548278}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reported"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301548333}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301548415}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm it reached"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301548492}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301635458}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick 1200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301635576}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exactly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301635869}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301635986}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks happened"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301663147}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", unless some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301663252}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chunks repeated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301663332}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301663453}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301729632}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1200 means exactly "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301729711}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301729773}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*30,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301729874}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301794646}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301794765}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301794896}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So sim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301794944}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sequence should be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301858006}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301858110}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301858194}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less.\n\nUnless the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301858333}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301923221}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parsing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301923304}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301923844}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes or other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301923975}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config difference?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301990471}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301990557}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301990670}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124301990787}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm, maybe our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302066631}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302066737}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302066838}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302067002}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world.config.t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302172576}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302172734}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302172943}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation` etc. no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302173010}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me reproduce determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302200621}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302200672}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" between"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302200825}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302200879}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302278468}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Compare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302278689}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302278732}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302278922}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302343745}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 via page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302343791}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302344152}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302344215}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 185"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302421044}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302421309}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302421357}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302421648}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302536445}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302536516}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302536808}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World({"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302536877}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed:1859,gener"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302570800}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ations:40,speed:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302571032}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8}) run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302571103}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302571133}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" print"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302657799}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts. Also maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302658048}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302658175}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" result"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302658235}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302717409}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302717781}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302717847}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ULTS.se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302717974}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed` patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302815069}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed something else"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302815127}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No.\n\nWait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302815360}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", our seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302815438}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302893318}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302893363}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed-m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302893397}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"emorable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302893636}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ran *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302997506}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"before* the render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302997607}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er patch and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302997705}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124302997760}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patch, but engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303075716}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was unchanged"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303075815}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" except"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303075918}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303075961}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Did I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303144899}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change engine after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303145130}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303145168}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-memorable? I changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303145218}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303234054}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed only."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303234278}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303234320}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303234381}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303316739}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So discrepancy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303316902}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is concerning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303317118}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303317159}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" called"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303377746}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `ENG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303377786}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"INE.run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303377991}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303378158}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` at conclude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303451645}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303451726}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No, auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303451817}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-fin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303452057}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ish from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303526275}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" realtime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303526366}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303526649}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303526696}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1200. Maybe the simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303615293}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303615633}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303615769}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"umed by something?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303615853}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No.\n\nMaybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303689031}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the page's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303689131}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303689210}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not use `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303689286}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303764699}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303764768}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303764934}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meta showed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303764988}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303841092}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40/40; yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303841209}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould it be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303841357}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that at speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303841497}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=8, browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303959602}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303959714}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throttling and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303959861}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rAF gaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303960022}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caused `run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303996068}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tick` calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303996209}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303996347}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124303996409}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304042457}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t correspond to the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304042605}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation? Tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304042709}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count equals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304042758}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1200."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304162657}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The R"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304162750}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NG state sequence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304162852}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" depends only on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304162968}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks and seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304212883}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nHmm, maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304212994}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" renderer pointer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304213115}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304213249}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304286674}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304286818}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine.set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304286916}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304287069}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"('"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304347080}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"speed',8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304347165}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") causing no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304347264}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304347466}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304415627}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304415728}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304415847}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed=8;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304416023}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304500341}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304500412}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" normalizes but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304500542}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" does not affect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304500821}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim.\n\nWait:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304563693}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304563771}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"engine.set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304563827}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param` might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304563905}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be called by controls at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304655147}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304655263}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304655381}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier's controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304655431}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initialization might call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304698592}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" setParam for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304698635}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed on mount"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304698681}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304698773}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304769967}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304770017}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes\"/\"tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304770148}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ils\" maybe;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304770382}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304838706}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" effects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304838762}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304838847}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" schedule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304838925}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" depends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304895137}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304895378}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304895605}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304895648}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304979233}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"regrowth?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304979323}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304979515}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might call set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124304979568}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param on mount with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305016403}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305016526}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" own"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305016725}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" defaults"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305016779}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", potentially"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305083410}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reset"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305083508}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ting mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305083613}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/regrowth to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305083917}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305145818}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.06/1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305145955}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".0 same. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305146098}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set catast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305146294}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305267333}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggle? defaults"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305267492}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305267568}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305267619}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm.\n\nBut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305288451}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305288500}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1859"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305288654}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" previously final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305288693}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 447"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305363114}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305363260}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305363393}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 84. Maybe because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305363444}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305419712}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" previous engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305419796}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run occurred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305420015}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" *before*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305420061}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the last render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305492990}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305493033}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305493143}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er doesn't affect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305493262}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine. Did I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305564066}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" accidentally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305564119}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" alter engine dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305564224}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305564407}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replacing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305641846}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305641940}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed: 197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305642018}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7\" strings"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305642238}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305696574}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s inspect engine changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305696623}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": replaced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305696772}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `seed: "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305696842}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1977`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305763976}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in DEFAULTS, maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305764164}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305764241}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in `bench"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305764303}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mark`? Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305841357}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Did I replace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305841410}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"const"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305841512}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed = 197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305841553}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7\" anywhere?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305896289}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no. No dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305896398}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe the page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305896488}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305896555}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" *not*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305962126}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start with seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305962238}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859 config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305962322}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124305962379}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" whole run:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306028697}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" URL parser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306028788}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306029018}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed: num"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306029097}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"('seed')` where"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306090592}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" num returns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306090637}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859; good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306090796}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould the page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306090847}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306154016}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have differing `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306154137}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306154227}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306154293}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rophes`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306216099}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306216213}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's compute engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306216344}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306216587}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less with seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306288339}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1859 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306288434}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306288585}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306288625}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306358671}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306358866}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also test boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306358907}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306359036}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sequence by simulating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306457715}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306457759}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with exact tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306457818}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stepping ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306457874}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runTick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306530812}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") not run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306530900}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless. Maybe `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306530992}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"runHeadless` has a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306531235}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306609347}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it runs `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306609419}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"remaining = ticksPer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306609548}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation - ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306609767}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IntoGen`;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306705013}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306705162}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick including"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306705352}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" endGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306705447}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resets. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306825684}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should be same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306825778}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as per-t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306826029}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick. Test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306826070}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306925739}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_5ogvks8uizx4bqhnc1unojx9","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306925847}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306926069}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306926118}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306938505}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306938557}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306938720}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306938774}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306938879}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306939207}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306939396}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306939563}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306996742}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306996808}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306997057}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306997125}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306997686}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306997983}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306998037}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124306998083}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307008622}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307008756}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307008925}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307008978}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307014842}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307014921}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307015031}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307015070}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307015535}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307015639}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307015748}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307016003}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307039662}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307039715}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307039810}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307039998}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307040690}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307040799}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307040945}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307040993}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307055949}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307056107}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307056257}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307056324}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307075774}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307075852}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307076058}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307076102}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307113176}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307113267}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307113365}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307113459}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307132399}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307132466}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307132644}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307132745}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307148583}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307148633}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307148772}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"det"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307148905}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307169404}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307169460}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307169519}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307169591}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307188781}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307188856}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307189005}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307189058}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307189597}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307189658}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sync"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307189793}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307189868}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307206064}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307206145}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307206248}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307206376}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307220086}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307220167}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307220344}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307220402}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307220898}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307221046}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307221125}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307221286}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307241185}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307241287}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307241476}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307241541}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307257557}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307257628}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307257744}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sync"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307257849}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307278820}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307278870}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307278909}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307278968}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307279027}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307279095}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307279156}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307279199}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307321007}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307321067}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307321178}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"={"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307321262}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307321307}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307321350}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"performance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307321732}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"};"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307321783}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307333596}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".gl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307333647}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"obal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307333803}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"This"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307333848}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307339589}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307339719}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307339790}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307339921}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307339971}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"indow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307340047}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307340508}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307340597}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307355173}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307355306}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307355387}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Context"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307355449}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307372001}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307372054}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307372116}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307372221}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307376029}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Context"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307376178}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307376234}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307376410}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307379491}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307379548}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307379661}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307379702}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307395039}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307395086}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307395239}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307395306}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307437910}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307437993}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307438056}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENG"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307438105}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307438508}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307438606}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307438695}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307438741}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307439553}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307439608}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307439714}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" [\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307439800}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307469217}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307469268}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307469358}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307469435}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307469589}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307469691}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307469869}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307469914}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307481983}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307482031}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307482143}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307482247}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307578733}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307578790}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307578966}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307579042}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307579242}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307579290}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307579511}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307579576}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307586304}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307586362}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307586530}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307586618}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307587158}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307587227}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307587322}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307587416}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307588444}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307588487}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307588592}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307588635}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307590591}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307590729}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307590781}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307590888}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307591756}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307591845}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307592032}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307592098}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307592860}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307593049}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307593138}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307593200}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307603768}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307603854}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307603946}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tra"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307604067}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ils"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307604778}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307604849}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307604920}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307604993}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307612974}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307613065}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307613163}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307613311}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307632158}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307632207}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307632333}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307632385}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307645533}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307645596}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307645643}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307645697}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307647758}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307647828}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307647964}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307648032}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307666317}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307666382}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307666431}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307666527}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307685891}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307685951}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307686067}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307686156}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307686542}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307686628}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307686882}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307686935}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307717066}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307717146}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307717197}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307717292}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307725994}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307726056}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307726122}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307726164}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307739801}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307739910}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307739974}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307740078}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307786143}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307786193}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307786311}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307786349}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307797657}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307797743}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307797800}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307797939}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307825461}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307825520}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307825675}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307825743}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307825830}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307825882}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307825916}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307826241}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307853842}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307853890}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307853943}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307854009}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307854156}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307854281}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307854391}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307854444}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307855081}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307855126}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307855260}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307855302}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307864029}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307864074}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307864215}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307864297}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" guard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307876861}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307876933}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307877010}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307877064}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" while"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307892751}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(!"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307892819}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307892960}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307893009}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307893985}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307894182}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307894256}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" guard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307894321}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307911181}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307911228}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"200"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307911333}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307911375}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"){"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307934771}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307934816}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307934951}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307935009}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307947762}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307947827}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307947956}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307948024}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307948125}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307948267}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307948328}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307948380}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307963373}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307963504}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307963598}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307963690}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307987276}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307987354}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307987630}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307987719}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307991525}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307991600}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307991769}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307991865}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307992141}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307992225}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307992506}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124307992596}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308009680}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308009799}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308009878}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308009953}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308026522}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308026628}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308026740}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"det"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308026845}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308059162}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308059254}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308059533}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308059649}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308060520}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308060612}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308060707}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308060830}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308096639}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Compare"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308096713}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308096894}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308096988}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308128644}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308128795}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-level"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308128863}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" determin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308128984}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308174021}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308174095}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20351,"ts_us":1793124308174148}}

data: {"id":"be9f88b98ea153615247235d436f1056","object":"chat.completion.chunk","created":1793124297,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":249214,"completion_tokens":1646,"total_tokens":250860,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":245632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1265,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":20351,"ts_us":1793124308181281}}

data: [DONE]

