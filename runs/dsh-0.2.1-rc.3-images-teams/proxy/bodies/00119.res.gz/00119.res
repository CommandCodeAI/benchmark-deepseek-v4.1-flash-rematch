data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562063479}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562177315}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562177359}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file states"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562177395}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562236904}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562236970}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562237027}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test again (f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562237082}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aster now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562296937}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562296997}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562297043}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" takes ~70"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562297112}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562341621}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe reduce long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562341691}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run sizes: 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562341724}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562341775}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562424391}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562424445}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562424538}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×120 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562424616}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B13 are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562488949}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" heavy."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562489036}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562489104}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562489158}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562554295}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562554389}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"70s is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562554469}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptable but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562554538}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frequent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562654974}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562655042}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"uns costly. Optim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562655097}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ize: B10 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562655150}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens at interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562722303}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 = 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562722370}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562722424}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≈ 7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562722468}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8s; B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562778482}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"13 120×9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562778533}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 108"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562778603}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 gens ≈ 42s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562778673}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562866860}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562866938}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"13 to seeds ["},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562866999}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1,2]"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562867058}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" × comb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562925493}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"os 3 ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562925545}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 720"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562925601}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens ≈ 28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562925652}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562990406}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Still long."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562990485}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562990561}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123562990625}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563070230}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563070301}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 80"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563070353}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563070413}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563138429}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (ext"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563138476}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563138554}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563138630}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563227337}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563227391}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563227445}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563227483}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563281528}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is mostly 3."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563281575}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563281610}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per 100 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563281641}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563345613}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563345696}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s 39ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563345755}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen. 108"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563345811}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 gens = 42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563452492}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563452544}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563452588}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563452624}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563521383}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563521447}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8s; B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563521495}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563521555}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563578074}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3.9;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563578134}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B2 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563578183}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×2 = 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563578219}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".1; B7 "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563628843}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563628913}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563628970}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6; B9 "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563629022}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"120 = 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563693862}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".7; B11 ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563693923}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 = 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563693979}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6; B12 several"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563694034}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563789044}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s = ~3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563789115}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563789350}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563789401}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563847036}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563847097}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".7; cross"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563847153}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-process"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563847221}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563915623}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563915666}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 = 3. Total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563915795}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~70s consistent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563915846}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nOptim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563985436}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ization: reduce B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563985498}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"13 to 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563985660}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens for two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123563985719}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" comb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564059225}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"os +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564059274}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 seeds?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564059319}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Ext"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564059364}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inction risk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564120932}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" testing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564120991}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564121046}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564121107}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564182436}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564182507}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564182548}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564182606}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564251468}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564251519}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564251559}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564251618}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564358938}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564359011}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564359083}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564359161}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564422728}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" combos → ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564422795}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564422827}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564422878}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B10 to 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564491553}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens (39"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564491608}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events at interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564491671}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3, still all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564491735}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 types over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564550058}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564550308}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564550346}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" With"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564550386}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564665122}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7, earlier "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564665178}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 gens had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564665246}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564665272}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564738140}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 types"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564738207}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564738255}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564738301}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564789167}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564789216}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564789267}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564789341}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564848655}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564848704}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564848749}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564848784}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564905315}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). B8 benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564905359}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100 → keep but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564905406}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564905457}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3.7s."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564988535}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564988610}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~45s."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564988678}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Accept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123564988744}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565050763}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nActually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565050882}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565050950}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565051009}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parallel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565107557}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ize?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565107632}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565107711}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" necessary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565107785}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565162603}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me check current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565162679}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" files:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565162737}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe Lead assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565162793}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232349}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_3u2wpkzg8z5zk9ryv54qdhk1","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232442}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232514}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232566}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232646}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232724}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232781}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232869}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565232967}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233045}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233248}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233305}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233359}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233406}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233473}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233566}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233618}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233675}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233734}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565233778}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565242484}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565242540}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565242588}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565242708}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565253762}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565253843}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565253911}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565254014}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565254088}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565254189}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565254266}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565254354}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565317537}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565317630}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565317672}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565317735}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565391179}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565391233}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565391310}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565391390}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565407752}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565407839}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565407902}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565408047}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565414470}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565414566}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565414636}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565414718}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565415004}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565415093}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565415160}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565415221}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565424266}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565424332}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565424382}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565424430}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565425613}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565425706}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565425794}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565425876}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565481377}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565481497}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565481568}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565481626}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565495232}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565495308}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565495377}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565495437}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565495730}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565495780}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565495843}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565495892}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565514601}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565514699}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565514770}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565514843}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565545172}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565545258}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565545334}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565545390}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565546329}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565546585}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565546651}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565546734}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565552776}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565552834}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565552885}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565552933}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565596172}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565596251}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565596333}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565596409}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565645171}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565645217}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565645263}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565645308}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565651777}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565651872}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565651947}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565652013}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assembly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565661382}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" progress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565661458}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565661578}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2755,"ts_us":1793123565661659}}

data: {"id":"e793d87083577d1a963df1158ecad747","object":"chat.completion.chunk","created":1793123561,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":165677,"completion_tokens":553,"total_tokens":166230,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":161024,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":415,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2755,"ts_us":1793123565691360}}

data: [DONE]

