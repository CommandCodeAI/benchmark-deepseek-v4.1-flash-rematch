data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126363930229}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126363987283}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rest of canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126363987366}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" audit for charts."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126363987459}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Output truncated "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364055617}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 lines; get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364055722}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364055814}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364056038}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_fnfeezit93sef2sbf32ynhv7","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364091458}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364092407}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364092454}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364092534}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364114169}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364114922}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364114977}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364117810}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364133373}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364134183}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364134309}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364134387}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364153364}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364154343}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364154385}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364154534}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364158813}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364158933}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364159110}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364159263}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364170690}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364171559}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364171622}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364171667}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364185447}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364185532}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364187001}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364187087}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364187174}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364187258}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364187332}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364187429}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364220376}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364220520}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364222293}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364222376}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364239531}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364240222}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364240308}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364240360}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364283257}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364284118}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364284189}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364284291}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364288693}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364288760}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364288905}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364288959}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364319568}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364319689}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364320946}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364321032}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364323516}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364323736}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364323813}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364323934}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364336150}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364336928}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364337098}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364337168}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364350757}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364351308}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364351428}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364351469}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364368677}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364369451}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364369497}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364369596}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364372635}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364372788}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364372866}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364372943}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364415709}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364416201}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364416333}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364416380}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364449833}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364449903}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364450563}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364450613}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364452523}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364452578}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364452638}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364452732}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364460782}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364461433}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364461530}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364461594}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364503167}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364503841}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364503904}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364504001}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364506544}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364506742}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364506818}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364506939}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364528825}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364528906}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364528981}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364529800}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364549730}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364550199}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364550399}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364550553}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364552973}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364553092}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364553139}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364553224}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364574015}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364574535}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364574585}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364574722}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364593050}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364593170}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364593953}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364594010}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364595395}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364595533}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364595590}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364595673}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364616427}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364616819}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364616872}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364616957}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364629796}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364630246}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364630357}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"700"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364630406}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364668069}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364668122}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364668734}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364668778}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364683978}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364684035}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364684130}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364685116}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364685227}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364685293}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364685383}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364685472}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364700884}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"an"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364700989}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364701652}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364701729}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ud"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364722566}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"it"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364723132}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364723241}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"64"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364723359}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364733265}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364733419}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364734187}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364734232}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364735707}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"an"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364735906}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364735968}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364736073}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ud"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364776893}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"it"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364776965}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364777011}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364777830}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364777998}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364778159}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364778285}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364778379}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364831557}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364831610}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364832423}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364832522}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364860044}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364860406}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364860508}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364860585}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364862817}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364862951}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364862996}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364863108}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364866019}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364866188}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364866278}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364866370}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364866496}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364866559}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"an"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364871868}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364871936}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364872067}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ud"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364872185}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"it"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364872290}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364872364}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364875664}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364875733}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364875791}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364875880}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364888700}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364889023}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".search"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364889153}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364889252}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364891429}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"SCRIPT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364891558}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364891718}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364891770}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364957060}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364957121}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364957176}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364958135}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364962107}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364962162}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364962716}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364962778}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364998857}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364998915}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364998956}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126364999650}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365016691}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365016928}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365017053}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365017113}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365063923}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365064422}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365064483}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".group"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365064644}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365064686}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365064787}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365064837}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365064915}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365069505}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365069552}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" arr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365069696}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365069760}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365082165}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365082214}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365082813}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365082954}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365100365}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365100694}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365100797}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365100903}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365115798}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-pop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365116264}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365116334}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365117653}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-tra"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365117770}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"its"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365117823}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365117985}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" or"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365118038}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365164293}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365164350}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365164398}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365165328}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" str"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365223149}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365223202}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"):\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365223242}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365224131}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365224254}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365224299}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365224435}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365224489}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365262590}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365262764}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" also"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365262820}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365263653}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" the"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365286803}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rendered"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365286851}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365287656}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" screens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365287718}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365290250}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365290509}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365290555}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365290653}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365315450}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365315831}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365315908}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365316029}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365318055}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365318105}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365318212}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365318254}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365387766}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Complete"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365388178}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" canvas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365388272}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" backing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365388323}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" audit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365623620}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365623905}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8996,"ts_us":1793126365623998}}

data: {"id":"4c620a12aaadeb8e2a661ad75cdcede1","object":"chat.completion.chunk","created":1793126363,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":333881,"completion_tokens":335,"total_tokens":334216,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":332416,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":17,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":8996,"ts_us":1793126365631214}}

data: [DONE]

