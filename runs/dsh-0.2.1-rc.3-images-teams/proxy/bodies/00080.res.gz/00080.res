data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276006905}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276149471}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" landed ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276149562}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"41KB)!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276149616}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me run engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276227983}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests now."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228057}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_q1pbu52v4nwozvlvo3np0rbh","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228115}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228192}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228261}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228328}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228510}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228583}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228648}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228695}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228834}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228880}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228944}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276228998}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276229069}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276229135}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276245068}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276245114}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276245192}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276245306}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276245371}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276245434}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276245497}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276245538}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276252925}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276252976}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276253025}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276253070}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276278896}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276278946}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276278987}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279082}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279317}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279385}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279436}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279503}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279577}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279658}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279730}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276279787}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276309471}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276309559}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276309620}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276309677}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276313684}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276313948}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276314025}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276314081}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276314776}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276314844}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276314886}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276314928}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276333346}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276333392}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276333467}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276333543}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276347319}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276347380}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276347429}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276347495}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276365034}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276365141}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276365222}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276365265}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276365805}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276365890}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276365957}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276366033}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276400416}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276400483}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276400536}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276400599}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276412436}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276412554}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276412625}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276412692}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276430654}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276430703}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" against"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276430749}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276430791}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276491720}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276491797}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1945,"ts_us":1793123276491870}}

data: {"id":"b6c29357506b47c0a4f7173922bb50e7","object":"chat.completion.chunk","created":1793123275,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":100369,"completion_tokens":129,"total_tokens":100498,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":99584,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":13,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1945,"ts_us":1793123276497114}}

data: [DONE]

