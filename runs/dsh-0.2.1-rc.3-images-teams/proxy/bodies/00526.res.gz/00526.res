data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740551215}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740613009}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740613042}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740613261}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and essentially same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740718705}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740718808}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740718852}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check the record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740719687}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740797440}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740797499}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event quickly."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740797683}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_lsawqpl28vpjbohzrxcqp9aa","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740797789}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740797850}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740797903}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740797972}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798019}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798081}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798120}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798169}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798302}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798389}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798449}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798497}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798550}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740798621}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740800031}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740800081}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740800124}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740831995}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740832064}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740832224}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740832263}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740861839}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740861889}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740861963}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740862428}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740863370}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740863425}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740863479}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740863950}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740866940}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740866992}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740867043}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740867086}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740877835}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740877899}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740877964}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740878036}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740880591}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740880673}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740880742}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740881424}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740887419}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740887503}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740887564}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740887677}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740887833}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740887904}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740887946}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740888005}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740903627}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740903698}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740903759}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740903816}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740922055}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740922125}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740922285}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740922348}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740936258}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740936320}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740936545}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":27978,"ts_us":1793127740936622}}

data: {"id":"5d45e49bed2715a76a496ef72ac3cd3c","object":"chat.completion.chunk","created":1793127740,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":370337,"completion_tokens":111,"total_tokens":370448,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":369024,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":22,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":27978,"ts_us":1793127741000459}}

data: [DONE]

