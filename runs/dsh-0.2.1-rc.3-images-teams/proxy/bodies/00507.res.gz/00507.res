data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264214860}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Official"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264256222}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliverable assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264256333}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", sha f820"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264256916}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"f20a... 313"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264315027}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".7KB."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264315837}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need tell verifier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264315885}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to snapshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264315971}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exact sha"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264382204}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and run final;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264383048}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264383158}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", avoid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264383198}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modifying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264445884}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" files."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264446675}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But we may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264446720}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still want"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264446807}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our own"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264510770}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264511728}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Tell ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264511779}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264511862}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264580685}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264581810}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cdp script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264581947}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264582051}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264666699}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 1440/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264667504}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280 as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264667633}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" requested"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264667672}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264706097}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" own checks."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264707034}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264707143}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264707199}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" path `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264766894}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"shots/atelier-cdp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264767681}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mjs`; it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264767813}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might rely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264767853}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264839178}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" path or URL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264840019}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" arg. Run on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264840148}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264840222}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" URL; encode"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264921652}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" space"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264922488}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with `%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264922611}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20`. Also run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264922763}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verifier? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264976067}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verifier do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264976921}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" complete.\n\nBefore not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264977044}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifying, note that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127264977123}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot edit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265046965}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265047969}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier's preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265048067}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265048154}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265128150}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview hash differs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265128917}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265129076}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue.\n\nSend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265129149}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verifier message with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265193019}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sha and path"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265193973}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", say no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265194025}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" writes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265194121}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from here"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265282378}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265283223}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265283265}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265283347}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue. Then run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265330884}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265331832}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and final tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265331931}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso assemb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265332011}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ler output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265387675}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 313"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265388571}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".7KB vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265388612}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265388755}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier said"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265494275}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 313,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265495120}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"098B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265495161}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" old; fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265495258}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's notify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265536268}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265537169}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_p0c3j8xbic1auu8dnm8wqu5m","type":"function","function":{"name":"send_message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265537242}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265537370}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265537445}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265537499}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265544811}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265544861}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265556885}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265557747}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INAL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265557820}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" DEL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265557922}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IVER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265592626}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ABLE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265593686}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265593863}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265593944}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"BL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265594127}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ED"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265600238}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" —"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265600316}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" snapshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265600492}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265625641}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" exact"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265626588}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" build"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265626772}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265626825}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265670529}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265671458}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265671584}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265671673}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265671784}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265671905}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265671982}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sha"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265680943}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265681049}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265681176}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265681225}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"820"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265687455}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265695506}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265696575}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265696712}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"872"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265696789}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"901"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265714507}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265715362}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"92"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265715409}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265715508}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265728962}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265729028}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265729077}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265729136}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"39"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265732009}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ccc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265732241}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265732457}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265732521}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265745237}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ae"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265746217}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"88"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265746325}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265746416}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265763058}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265764120}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"121"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265764221}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265764350}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265782378}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265782605}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"82"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265782703}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265784757}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"084"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265784909}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265785040}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265785103}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"311"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265785175}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"47"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265803897}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265804937}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265804994}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265805103}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265830958}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265831827}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265831880}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265831988}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265841136}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"313"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265841810}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265841918}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265841968}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" KB"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265855841}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265856507}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265856554}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265856638}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265859668}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"049"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265859797}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" lines"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265859901}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265860008}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265877321}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265877395}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265877566}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265877649}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265886402}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265887017}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265887081}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265887183}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265900968}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265901076}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"23"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265901147}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265902282}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"54"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265916015}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265916330}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"08"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265916447}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265916545}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"050"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265918997}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265919108}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265919179}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265919292}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" is"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265936403}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" frozen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265936551}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265937239}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265937281}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265960234}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265960433}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265960542}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265961239}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265998637}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265999130}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Z"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265999196}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127265999332}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" messages"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266005140}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" received"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266005596}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266005669}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266005782}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266023927}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266024299}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266024356}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ask"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266024473}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266042962}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266043093}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" complete"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266043625}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266043727}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266080487}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" made"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266080823}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" two"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266081026}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266081114}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-owned"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266110698}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" boot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266111157}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266111270}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266111396}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" edits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266124611}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266124668}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" the"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266124714}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266124772}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266141506}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" you"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266141576}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tested"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266142120}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266142209}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266159255}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266159620}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266159703}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266159829}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266174994}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266175316}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266175448}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"anner"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266175494}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266194686}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266194982}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" has"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266195120}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266195188}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"role"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266213291}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266213704}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266213841}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266215146}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266246881}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266246980}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266247020}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266247887}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pol"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266248703}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266248815}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266248864}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266250965}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266251016}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atomic"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266251081}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266252952}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266252999}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266266997}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266267413}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266267532}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"was"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266267625}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" already"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266301269}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" asked"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266301318}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266301368}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266302017}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266320802}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266320863}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" robust"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266320906}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" banner"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266321647}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hide"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266371908}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" timer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266372012}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" so"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266372700}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rapid"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266372750}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266409172}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266409661}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" can"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266409716}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266411044}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hide"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266421663}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266422112}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" newly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266422206}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" announced"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266422290}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" banner"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266434046}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266434158}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266434227}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266435034}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266470257}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266470405}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266470854}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" broken"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266470939}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" figure"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266486553}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aria"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266486965}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-lab"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266487009}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elled"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266487119}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"by"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266504970}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" (`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266505281}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266505386}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266505438}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266544397}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266544481}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"caption"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266545029}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266545126}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266577564}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" All"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266578018}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" frozen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266578157}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" module"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266578201}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" has"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266608653}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266608717}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verified"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266608782}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266609597}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266625385}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266625481}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266625536}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"77"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266626403}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266638848}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266639258}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266639403}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"861"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266639458}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"…"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266658142}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266658541}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266658593}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266658693}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266679638}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266679956}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ab"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266680069}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"11"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266680122}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266682133}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266682248}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"…"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266682305}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266682437}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266692014}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266692444}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266692519}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"599"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266694550}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266711416}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266711886}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266711954}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266712142}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"…"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266728815}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266729280}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266729414}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266729452}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266745613}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"313"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266745723}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"778"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266746322}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266746412}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"…"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266804642}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266805173}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266805334}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266805456}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266805505}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266807914}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"574"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266807981}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266808108}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266808158}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"…"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266808199}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266808333}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" render"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266808383}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266812511}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266812612}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266812707}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266814501}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266830347}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266830702}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"…"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266830750}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266830842}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" boot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266858056}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266858349}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266858401}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266858491}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266860568}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266860687}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"850"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266860791}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"…"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266860918}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266893148}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266893218}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266893799}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"721"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266893922}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266910007}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266910271}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266910362}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"…."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266910408}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266927022}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"102"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266927348}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266927455}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" horizontal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266927553}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clip"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266984079}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266984210}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266984291}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266985072}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" included"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266994439}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266994781}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Please"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266994838}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127266994920}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" your"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267013130}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" FIN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267013519}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267013617}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267013764}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267079117}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-minute"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267079300}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" matrix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267079429}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267079483}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" against"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267087171}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" this"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267087575}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sha"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267087639}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267087758}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267103149}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267103659}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267103703}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267103809}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267105714}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267105853}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267105904}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267105991}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267113202}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" matrix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267113318}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267113373}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" screens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267114307}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267136085}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267136193}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267136251}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" publish"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267137112}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267168199}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267168511}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267168612}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PORT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267168808}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267210064}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267210416}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" then"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267210513}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" message"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267210645}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" me"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267227705}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267228111}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" PASS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267228349}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267228446}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FAIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267239737}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" summary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267240104}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267240313}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" remaining"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267240403}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" risks"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267270753}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267270930}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267271043}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" will"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267271201}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" not"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267285136}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" touch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267285236}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267285729}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267285777}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267306396}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267306880}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267306981}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267307107}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267324346}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" unless"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267324848}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" you"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267324999}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267325050}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267332969}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" blocker"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267333433}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267333562}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267333597}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" you"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267351604}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" do"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267351758}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267351810}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" I"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267352714}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'ll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267387670}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267388002}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267388106}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267388168}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"emble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267450453}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267450957}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267451002}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267451097}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sha"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267468546}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267468710}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267468770}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267469712}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267470541}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267470650}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267470813}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267470879}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267473155}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267473238}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ifier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267473354}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267473460}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267521260}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_25cdr8npz42qauwsurd2l35e","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267521323}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267521962}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267522021}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267535071}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267535507}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267535555}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267535670}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267537606}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267537693}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267537749}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267537795}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267552764}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267553252}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267553379}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267553449}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267593476}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267594009}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267594149}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267594227}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267622491}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267623013}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267623059}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267623150}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267632592}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267632648}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267633217}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267633261}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267633450}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267633577}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267633647}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267636700}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267654724}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267655342}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267655403}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267655470}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267674559}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267674610}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267674657}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267675450}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267696067}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267696469}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267696559}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267696604}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267709355}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267709809}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267709864}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267709992}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267720854}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267721200}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267721236}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267722471}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267741717}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267741831}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267742241}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267742287}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267753425}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267753890}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267753935}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267754030}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267755984}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267756090}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267756209}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267756256}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267768977}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267769388}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267769489}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267769602}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267783661}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267784107}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267784275}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267784328}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267786183}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267786288}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267786399}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267786447}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267798571}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267798672}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267799083}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267799130}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267817142}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267817546}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267817632}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267817701}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267830105}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267830272}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267830795}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267830869}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267831030}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267831136}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267831207}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267831331}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267849960}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267850107}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267850152}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267851107}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267868942}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267869450}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267869572}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267869668}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267871362}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267871517}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267871594}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267871721}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267884293}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267884643}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267884695}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267884802}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267905367}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267905445}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"201"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267905495}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267906369}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267906504}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267906678}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267906740}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267909073}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267920395}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267920781}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267920891}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267920984}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267941419}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267941854}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267941927}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267942051}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267944080}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267944202}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267944342}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267944392}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267956303}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267956398}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267956896}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267956946}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267972272}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267972365}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"===="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267972422}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267973102}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267973196}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267973235}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267974905}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267974964}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"===="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267988102}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267988474}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267988539}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127267988694}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268006755}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268006905}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268007353}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268007406}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268008526}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268008692}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268008785}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268008935}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268022813}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268023197}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268023246}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268023342}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268040553}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268040894}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268040988}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268041030}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268042622}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268042707}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268042754}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268042850}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268056817}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268057092}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268057182}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268057264}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268075368}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268075727}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268075774}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268075856}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268077458}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268077558}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268077680}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268077723}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268099244}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268099701}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268099766}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268100613}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268107902}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268108006}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268108520}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268108618}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268108708}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268108804}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268108881}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268111098}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268129772}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268130039}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268130130}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268131203}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268179055}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268179382}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268179578}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268179635}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268181166}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268181287}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"%"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268181414}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"201"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268181488}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268181593}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268181669}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268185200}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268185258}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268185331}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268185466}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268185514}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268185682}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268185774}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268189229}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268189327}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268189375}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268199296}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268199426}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268199776}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268199897}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268217566}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268217625}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268217791}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268218333}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268229634}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268229707}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268229766}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268230433}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268245258}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268245623}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268245682}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268245801}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" designer"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268283145}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268283483}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" frozen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268283553}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268284568}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" layout"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268324929}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268325162}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" on"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268325219}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268326268}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" deliver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268366331}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"able"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268366391}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268366447}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10275,"ts_us":1793127268367051}}

data: {"id":"4f1fa490e50aa49a20c9c316b66cef31","object":"chat.completion.chunk","created":1793127264,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":350385,"completion_tokens":901,"total_tokens":351286,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":347520,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":203,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":10275,"ts_us":1793127268434981}}

data: [DONE]

