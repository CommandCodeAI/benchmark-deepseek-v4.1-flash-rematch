data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005185060}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005249980}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tail shows only WOR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005250033}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ST 3; need full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005250770}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output with table;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005279127}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" console.table [Object] hides"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005279177}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nested."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005279218}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's view /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005279252}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tmp/seed-search.out top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005410264}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005410315}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_908jgzn9go66ay4rjzzxhcb7","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005410363}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005411709}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005411785}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005411859}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005411922}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005411971}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005412015}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005412047}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005412104}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005412160}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005412251}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005412348}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005412399}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005412473}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005432688}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005432772}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005432833}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005432900}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005432952}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005432995}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-search"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005433039}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005433105}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005433782}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005433852}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005433925}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005433987}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005434042}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005434093}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005434148}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"View"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005434189}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" top"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005434236}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005434286}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" search"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005434336}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005434388}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005621953}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":20453,"ts_us":1793124005622014}}

data: {"id":"8739c54fb2e568296631d30deef43939","object":"chat.completion.chunk","created":1793124005,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":226393,"completion_tokens":105,"total_tokens":226498,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":225920,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":34,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":20453,"ts_us":1793124005622084}}

data: [DONE]

