data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295606453}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295680372}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" results. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295680486}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to investigate the real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295680570}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine to distinguish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295776399}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real defects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295776484}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs harness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295777252}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over-strictness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295777318}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n\n1. `history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295846566}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" length"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295846628}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 41"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295846736}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" < 100` after run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295846784}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295904518}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",100):"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295904575}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295904619}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 41 entries"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295904656}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? So"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295955235}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295955322}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295955416}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capped at 41"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123295955499}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296015650}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296015722}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history at generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296015779}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+1 = default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296015839}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296086172}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1=41 regardless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296086243}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296086312}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" length?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296086359}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296156586}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be a serious"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296156652}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bug: run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296156715}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296156779}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296215405}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100) with default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296215470}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations 40 stops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296215510}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 40?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296215563}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296272795}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296272875}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296272944}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100 gens in "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296273012}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"862ms\" — maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296348493}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296348563}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" respects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296348646}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config.g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296348763}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enerations (40)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296467969}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and stops!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296468032}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296468070}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generation presumably"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296468141}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296519211}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296519286}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296519356}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296519433}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less(w,100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296569405}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") may run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296569481}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296569553}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".finished ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296569590}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296626894}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations 40)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296626966}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Since create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296627017}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296627062}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default generations="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296710957}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40, runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296711049}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less to 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296711096}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stops at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296711135}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 because finished"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296812510}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296812582}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296812621}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296812667}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 gens hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296870187}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296870274}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296870335}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me check engine code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296870398}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to understand."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296922328}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296922379}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296922433}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296922486}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7,100) returned generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296976891}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":100 in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296976938}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296976975}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output (hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123296977139}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" included"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297052019}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). So benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297052082}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" creates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297052123}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" its own"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297054478}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config with generations "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297122292}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100 maybe. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297122346}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me inspect engine API"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297122389}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297123570}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Headless semantics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297198665}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n2. B13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297198761}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297200719}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297200766}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297260906}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arniv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297260953}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora.speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297260998}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mean=null when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297261039}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297310723}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct — engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297310776}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probably records"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297310818}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" null for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297310858}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" empty species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297361945}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297362060}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" defensible:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297362134}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297362204}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" organisms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297421086}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → mean undefined"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297421189}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297421282}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297421359}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needs to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297537887}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handle; brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297537964}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says traits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297538041}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297538481}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 taxa × 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297646579}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" genes present"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297646633}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297646693}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be null for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297646730}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297698865}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297698914}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" validator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297698954}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297698996}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too strict."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297756365}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297756418}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297756527}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" whether null"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297756570}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is documented"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297819179}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297819232}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297819306}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handle gaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297819374}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I'll adapt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297874302}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": allow null/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297874361}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"undefined"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297874465}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if species count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297874533}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is 0 in that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297934393}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation; report as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297934454}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297934482}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123297934538}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contract says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298048806}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `{ speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298048849}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":{mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298048884}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",sd,min,max},"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298048920}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ...}`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298110480}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all present"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298110527}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298110592}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" null for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298110664}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298192998}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptable/necessary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298193053}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I'll modify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298193090}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" validator to accept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298193127}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" null only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298276827}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298276886}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"[sp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298276939}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"]===0.\n\n3."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298277001}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B11"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298449861}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": active"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298449949}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events undefined →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298449993}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298450034}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" name it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298649739}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differently or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298649786}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not implement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298649837}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Insp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298649892}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298718523}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n4. B15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298718586}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": resetWorld"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298718666}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keeps "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298718749}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 history entry ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298837758}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298837808}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298837848}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" entry?) while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298837909}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298968467}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cleared"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298968538}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298968597}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It says history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123298968634}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not cleared: expected 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299027692}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299027753}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" got 1. Actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299027804}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resetWorld might push an"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299027860}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial gen-0 history entry"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299074335}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reason"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299074400}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able. Adjust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299074456}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to <="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299074491}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 and counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299145527}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initialized"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299145577}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n5. B9:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299145649}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 13 events at interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299145733}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 over 60 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299207716}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Expected 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299207792}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe catastrophic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299207832}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299207895}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" semantics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299254479}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299254551}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (e.g., each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299254610}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event type"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299254668}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299329706}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown, or interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299329755}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counted in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299329796}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299329847}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"events per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299448682}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" X"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299448732}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299448776}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" with duration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299448819}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" blocking"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299511572}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Also "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299511632}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299511913}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe stopped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299511961}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299621284}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299621338}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generations=40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299621376}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! Because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299621411}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" createWorld default generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299689785}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299689843}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299689884}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less(w,60) may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299689954}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stop at 40 → events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299753409}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≈ 13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299753458}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299753501}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299753553}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 gens is right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299820163}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299820222}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/3 ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299820260}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 13)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299820315}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" So the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299875901}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue is my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299875972}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299876009}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299876060}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299938218}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens than config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299938291}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".generations, engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299938340}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299938400}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-finishes at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299992247}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40. Need to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299992287}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pass generations matching"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299992331}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123299992376}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in config for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300122462}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" long runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300122523}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That explains B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300122575}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6 history "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300122625}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"41, B9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300198380}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300198443}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", B10 ran"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300198493}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300198546}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200 gens\" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300244962}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actually "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300245013}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40? B10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300245062}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" got 13 events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300245115}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300298299}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 → yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300298346}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300298398}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 40 gens. And"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300298445}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300342614}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300342665}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100 gens in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300342715}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 862ms\" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300342769}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stopped at 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300410292}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300410464}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300410513}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300411143}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300475581}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300475691}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Let me verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300475820}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300475870}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300542161}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script.\n\nSo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300542232}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300542269}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300542317}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": set config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300609445}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300609548}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enerations >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300609637}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300609685}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300664109}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300664159}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300664204}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300664246}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6 validate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300727990}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history length"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300728036}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exactly gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300728072}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300728148}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300797496}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300797546}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" behavior directly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300797581}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300797678}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a quick inspection"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300873471}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300873522}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_7738pf0z1738uex73ih5rz76","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300873595}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300873745}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300873851}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300873928}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300873993}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874047}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874106}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874170}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874310}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874382}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874449}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874513}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874626}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874672}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874773}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874840}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874894}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300874928}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300881397}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300881467}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300881536}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300881577}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300895380}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300895444}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300895483}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300895525}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300912857}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300912922}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300912973}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300913025}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300931447}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300931500}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300931552}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300931605}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300957498}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300957619}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300957698}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300957786}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300989989}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300990044}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300990092}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123300990160}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301005528}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301005578}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301005627}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301005676}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301006902}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301006950}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301006998}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301007057}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301022306}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301022386}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301022443}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301022498}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301038153}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301038217}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301038275}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301038334}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301054957}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301055026}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301055082}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301055178}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301055671}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301055720}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301055760}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" './"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301055803}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301072371}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301072444}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301072525}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301072567}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301088803}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301088883}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301088959}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301089020}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301114165}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301114283}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301114382}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301115463}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301133789}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301133884}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301133942}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301134031}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"From"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301151358}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301151488}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301151609}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301151705}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301152579}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301152687}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301152771}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301152853}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301165956}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301166057}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301166150}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"API"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301166231}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301183590}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301183708}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301183793}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301183878}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301218201}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301218375}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301218492}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301218739}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301255748}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301255846}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301255922}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301256003}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301256565}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301256690}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301256803}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301256999}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301273921}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301274000}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301274169}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301274245}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301279985}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301280061}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301280221}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301280303}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301333067}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301333120}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301333176}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301333235}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301338442}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301338523}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301338588}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301338645}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301347612}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301347668}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301347718}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301347770}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301348359}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301348416}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301348515}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301348627}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301387494}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301387668}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301387754}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301387805}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301419059}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301419138}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301419198}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301419253}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301428235}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301428287}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301428337}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" init"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301428462}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301466301}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301466363}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301466497}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301466552}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301485308}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301485411}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301485498}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301485550}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301513265}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301513317}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301513442}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301513547}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301513665}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301513715}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301513830}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301513947}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301539772}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301539823}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301539894}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301539965}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301557357}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301557453}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301557560}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301557618}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301558018}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301558265}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301558312}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301558355}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301571662}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301571750}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301571828}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301571877}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301589716}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301589768}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"):"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301589804}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301589853}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301613966}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301614069}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301614177}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301614256}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301634940}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301635000}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"finished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301635048}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301635134}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301635381}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301635680}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301635745}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301635804}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301695843}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301695912}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301695978}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301696022}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301700485}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301700560}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301700636}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301700704}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301700988}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301701039}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301701106}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301701162}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301702140}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301702195}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301702240}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301702288}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301712414}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301712472}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301712510}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301712616}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301713151}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301713207}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301713265}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301713318}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301728924}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301728987}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301729035}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301729104}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301740665}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301740745}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301740793}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301740856}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301774056}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301774151}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301774216}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301774297}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301774748}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301774801}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301774853}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301774904}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301787750}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301787849}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301787928}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301788005}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"first"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301820869}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301820953}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301821007}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301821051}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301821533}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301821597}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301821696}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301821801}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301843863}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301843931}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301844013}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301844063}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301859072}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301859156}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301859236}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301859288}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301860123}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301860174}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301860299}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301860345}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301880635}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301880714}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301880783}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301880845}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301896345}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301896413}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301896473}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301896562}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301897037}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301897099}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301897148}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301897212}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301914137}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301914226}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301914276}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301914330}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301937527}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301937590}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301937633}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301937692}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301977694}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301977756}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301977822}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123301977858}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302011983}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302012301}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302012345}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302012423}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"):"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302012644}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302012690}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302012799}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302012842}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302024390}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302024433}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302024487}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302024535}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302041727}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302041814}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302042009}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302042065}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302045228}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302045276}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302045439}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302045476}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302059919}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302059973}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302060013}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302060055}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302071848}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302071924}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302072015}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302072095}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302072569}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302072648}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302072697}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302072771}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302113440}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302113496}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302113537}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302113591}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302128149}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Array"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302128212}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".is"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302128260}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Array"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302128316}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302164799}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302164855}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302164921}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302164988}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302233458}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302233509}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302233546}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"array"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302233596}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302249553}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302249618}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302249664}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302249738}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302250804}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302250865}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302250930}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302251025}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" typeof"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302251922}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302251974}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302252024}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302252118}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302268255}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302268324}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302268369}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302268417}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302275309}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"world"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302275362}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302275407}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302275494}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302293767}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302293852}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302293927}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302293975}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302316314}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302316394}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302316527}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302316593}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302353773}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302353830}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302353900}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sample"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302353960}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hist"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302472220}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302472281}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302472324}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302472369}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302472882}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302472930}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302472990}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302473045}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302501936}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302501987}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302502028}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302502090}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302518580}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302518665}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302518748}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302518816}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tra"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302519793}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"its"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302519845}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302519896}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302519946}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302532680}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302532779}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302532847}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302532896}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302533417}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302533473}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302533522}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302533640}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302534620}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302534688}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302534756}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tra"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302534804}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"its"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302535308}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302535394}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302535459}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302535535}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302566097}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302566159}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302566203}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302566244}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302589106}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302589159}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302589204}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302589253}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302589565}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302589644}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302589795}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302589852}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302621203}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302621258}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302621343}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302621437}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302629091}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302629166}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302629284}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302629351}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302661315}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302661407}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302661484}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302661542}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302685408}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302685493}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302685554}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302685605}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302722874}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302722941}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302722988}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302723041}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302723320}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".reset"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302723381}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302723425}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302723473}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302742242}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302742411}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302742465}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302742517}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302790579}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302790652}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"400"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302790687}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302790744}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302790882}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302790946}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302791003}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302791047}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"reset"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302830943}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302830999}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302831049}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302831113}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302832253}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302832317}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302832427}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302832471}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302849863}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302849947}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302850020}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302850061}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302870331}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302870419}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302870460}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302870533}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302871073}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302871123}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302871177}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302871225}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302891060}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302891144}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302891223}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302891271}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302950506}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302950576}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302950623}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302950678}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302951273}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302951324}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302951367}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302952051}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302952108}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302952155}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302952201}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302952250}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302952876}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302952943}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302953036}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302953078}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302953430}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302953492}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302953541}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302953583}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302959101}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302959179}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302959231}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302959311}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302975125}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302975182}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302975223}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302975272}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302998602}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302998677}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302998745}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123302998806}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303014474}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303014524}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303014585}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303014639}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303039170}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303039223}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303039269}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303039312}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303053869}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303053952}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303054006}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303054053}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303070977}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303071028}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303071072}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303071136}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303071482}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303071540}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303071587}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303071638}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303084677}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303084760}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303084805}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303084857}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303099606}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303099723}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303099787}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303099856}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"int"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303135266}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303135353}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303135496}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303135552}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303151188}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303151246}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303151278}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303151326}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303172712}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303172808}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303172886}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303172976}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303182450}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303182532}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303182622}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303182703}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303182946}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303183032}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303183100}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303183142}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303201622}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303201694}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303201753}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303201867}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303220408}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303220472}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303220542}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303220614}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303233112}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303233183}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303233227}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303233282}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303246037}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303246103}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303246212}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303246252}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303265275}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303265354}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303265420}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303265467}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303265855}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303265900}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303265943}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303266023}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303282881}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303282935}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303282975}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303283047}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303297949}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303298022}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303298089}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303298164}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303298234}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303298303}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303298383}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303298471}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303316146}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303316235}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303316290}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303316403}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303333768}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303333831}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303333884}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303333945}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303334387}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303334440}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303334502}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303334559}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303350581}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"int"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303350635}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303350698}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303350781}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303392739}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303392794}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303392872}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303392927}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303392978}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303393096}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303393172}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303393252}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303393319}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303393417}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303393483}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303393530}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303415162}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303415472}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303415524}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303415611}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303415656}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303415698}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303415757}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303415810}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303437270}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303437370}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303437496}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303437591}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303438671}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303438787}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303439014}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303439079}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303439685}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303439762}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303439820}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303439862}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303472285}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303472341}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303472392}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303472455}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303473051}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303473131}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mark"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303473194}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303473256}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303488335}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303488389}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303488433}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303488519}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303503268}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303503321}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303503369}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303503421}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303525155}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303525234}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303525348}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303525429}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303585348}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303585396}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303585436}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303585490}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303586306}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303586357}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303586393}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303586440}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303603823}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303603876}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303603939}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303604009}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303666937}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303666990}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303667032}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303667126}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303667557}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303667606}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303667653}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303667695}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303668156}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303668199}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303668280}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303668360}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303672741}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303672819}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303673016}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303673078}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303722696}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303722783}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303722850}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303722914}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303723436}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303723509}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303723576}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303723653}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303730365}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303730415}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303730470}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303730523}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303750267}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303750320}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303750360}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303750399}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303767507}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303767573}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303767605}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303767655}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303768129}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303768201}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303768251}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303768298}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303788195}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303788293}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303788352}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303788395}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303814378}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303814494}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303814589}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303814643}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".active"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303815232}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303815328}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303815400}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303815480}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303838180}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303838279}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303838370}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303838450}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303860044}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303860126}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303860188}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303860243}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Object"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303879141}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".keys"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303879207}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303879263}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303879336}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303880158}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"filter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303880208}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303880306}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303880419}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303913930}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303914018}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303914098}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303914170}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303914432}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303914511}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303914556}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303914640}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303949634}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303949747}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303949838}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303949925}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303968248}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303968346}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303968431}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303968609}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303989513}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" behavior"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303989604}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303989676}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" detail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123303989746}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123304070153}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2288,"ts_us":1793123304070267}}

data: {"id":"553a7b220f679a2a047f1705ca31cfc4","object":"chat.completion.chunk","created":1793123295,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":101958,"completion_tokens":1524,"total_tokens":103482,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":100352,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":733,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2288,"ts_us":1793123304070402}}

data: [DONE]

