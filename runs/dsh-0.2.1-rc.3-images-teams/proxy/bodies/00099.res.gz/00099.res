data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428156162}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Who"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428205007}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"a: now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428205071}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no ext"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428206627}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inctions at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428284801}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all across "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428284894}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12 seeds! Populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428284987}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428285031}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428353363}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"iv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428353599}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"orea"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428353671}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428353894}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428424518}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 308"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428424593}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428424671}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428424732}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-287"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428487855}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), predators "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428487932}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"37"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428487997}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428488079}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"64, flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428560342}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mostly at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428560423}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428560463}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ear cap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428560545}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1800 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428621109}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428621165}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 373"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428621215}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–968"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428621492}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428681515}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428681586}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" never"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428681635}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" go"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428681687}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428747235}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428747301}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivores abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428747349}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428750342}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecosystem is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428822138}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428822200}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-friendly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428822254}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428823284}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428870849}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428870913}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ab"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428870961}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"undant;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428871050}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora often"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428963560}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428963621}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"179"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428963679}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8) — visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123428963811}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429075287}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429075337}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429075384}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plateau"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429075558}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429105455}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", reducing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429105509}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429105571}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drama"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429105629}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429178398}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" system"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429178458}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429178660}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable and all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429178696}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species alive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429245867}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; however"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429245940}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429245995}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429246127}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429305771}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–300 may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429305848}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be too dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429306012}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429306074}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429371154}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429371230}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rings"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429371388}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" everywhere"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429371446}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429469068}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429469140}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429469226}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20–80"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429469269}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429512606}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429512669}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429512733}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dip things"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429512898}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429579825}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429579876}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429580041}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429580079}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recovery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429652487}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429652558}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show bo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429652617}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oms;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429652666}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429732020}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429732104}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drops."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429732238}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429732286}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429791402}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429791471}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429791533}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429791570}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429853589}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429853683}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429853819}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429853925}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429923996}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429924063}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20 → "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429924124}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"80)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429924163}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429990718}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429990804}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but visually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429990864}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123429991161}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"250 prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430072887}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430072946}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"160×90"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430073012}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might be busy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430073074}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430146333}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430146432}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px). Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430146485}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430146525}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430217081}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430217172}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430217245}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430217317}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430363131}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to balance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430363232}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430363309}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430363487}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~80"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430378940}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430379059}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430379125}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430379193}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s an oscillation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430413353}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430413422}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430413482}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430413604}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430489547}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nThe handling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430489621}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430489677}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430490069}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cooldown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430544615}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430544694}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430544771}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430544842}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430619080}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430619190}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430619254}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430619305}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430690724}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"graz"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430690801}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed. Should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430690893}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430691248}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to intermediate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430778528}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" between"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430778596}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" previous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430778726}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430779488}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430835746}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"razing/c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430835820}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rashes) and now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430835873}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430836845}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430905044}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/l"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430905105}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ush). Increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430905150}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430905204}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430971565}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"atCo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430971615}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430971656}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123430971771}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431032580}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431032635}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduces"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431032684}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing further"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431032730}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". De"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431107011}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"crease from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431107091}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4 to 2 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431107149}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"more grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431107203}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") to create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431182499}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431182555}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431182768}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increase herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431182819}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431245855}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431245918}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431245965}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431246020}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431320416}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431320485}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" want final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431320529}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431320984}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431366831}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 600"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431367001}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–1200, herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431367066}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 120–220"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431367694}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431434462}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431434541}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–50, with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431434576}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431434625}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431498553}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431498612}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431498705}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431499466}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431563031}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431563151}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–300;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431563222}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431563260}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431631779}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431631838}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"240 and consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431631897}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431631940}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bit more ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431736055}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eatCd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431736101}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431736139}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") so flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431736317}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431831354}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at cap."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431831399}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431831443}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maxFl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431831483}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431857745}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 (cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431857899}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431858245}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431858321}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0) so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431896514}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431896566}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431896611}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431896733}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed; charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431989159}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431989323}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431989419}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aus at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123431989467}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap though."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432050746}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Better increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432050797}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432050901}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432051628}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432130631}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432130695}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432130766}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432130825}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nTry herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432201433}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EatCo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432201509}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown 3 and herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432201587}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"SoftCap "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432201675}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"280; check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432261764}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432261826}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432261882}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432262667}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432337146}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432337202}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"84; soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432337246}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432337281}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" affects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432402968}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432403014}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probability above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432403087}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432403201}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 250"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432471718}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432471845}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"280 crowd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432471977}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432472025}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.107"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432542495}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432542548}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432542615}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" continue"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432542674}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432613048}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432613181}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cap (e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432613256}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g., 240"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432613328}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and stronger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432684241}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exponent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432684326}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to limit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432684400}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432686023}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432761147}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432761249}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432761327}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" supports"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432761405}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432833691}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" won't die"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432833825}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; soft"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432833979}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432834075}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only slows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432898522}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births; natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432898595}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deaths"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432898654}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432898700}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432969263}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nVisual density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432969332}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" considerations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432969459}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": 280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123432969510}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433052602}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in 160"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433052646}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×90 =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433052698}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433052743}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433132945}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 51"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433133005}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cells; average spacing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433133081}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 7 cells"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433133175}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433193870}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px at 940"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433193932}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px wide;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433193986}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433194033}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too busy actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433293931}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433293999}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433294054}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1800/14400"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433294106}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433337316}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5% → each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433337377}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cell "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433337527}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433337585}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9px,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433406761}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 180"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433407010}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 glyph"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433407067}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s; dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433407176}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433476857}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moss."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433476926}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Predators "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433476984}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"50 sparse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433477110}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433535385}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay visually."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433535442}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433535537}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433535727}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433603686}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap plateau"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433603754}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433603890}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433603944}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433680092}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433680139}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flat at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433680185}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1800"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433680268}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for stretches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433759328}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433759465}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433759513}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Flora "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433759588}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433828994}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 to show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433829041}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433829075}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433829118}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flat. Better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433894982}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433895145}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth/se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433895189}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eding so equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433895224}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433979130}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1200,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433979182}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433979232}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Easi"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123433979283}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"est: reduce `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434027842}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434027909}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Sprout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434027952}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` from "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434028124}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3.1 to e.g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434091453}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434091500}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8 (less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434091545}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434091589}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434161722}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rain), keeping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434161781}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434161846}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434161917}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore-equ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434227269}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434227381}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434227430}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434227469}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434305580}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434305640}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434305702}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown, flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434305934}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may settle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434365222}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434365307}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap. Currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434365361}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434365417}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434426603}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 111"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434426693}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434426776}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434426843}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1798;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434486489}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" some at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434486558}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap. Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434486624}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sprout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434487118}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434552324}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2.0 and seeding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434552426}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434552494}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434552563}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434624553}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434624613}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434624712}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evolution"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434624759}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": traits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434677064}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434677113}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drifting."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434677178}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Diversity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434677320}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434751550}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434751631}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434751818}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434751901}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434818263}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434818317}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" traits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434818475}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" close"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434818648}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to bounds?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434887457}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434887543}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434887615}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434887683}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434960006}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434960086}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EatCo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434960157}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown 3 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123434960230}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"slightly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435036417}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more grazing)\n- herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435036515}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"SoftCap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435036582}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 260"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435036642}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435111767}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Sprout 2.3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435111838}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- floraSeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435111897}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Chance 0.003"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435111949}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435181253}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435181304}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (less"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435181346}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435181403}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")\n- maxFl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435262329}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora 160"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435262500}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0\n- herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435262545}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435262730}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Chance 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435310886}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"05\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435310958}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carnBirthCh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435311010}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ance 0.03"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435311066}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435399067}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"SoftCap 50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435399134}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435399194}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435399242}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cooldown 16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435461643}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\nTest across"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435461698}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12 seeds."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435461998}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We need not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435462061}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435558916}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"optimize; choose"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435558984}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435559030}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435559081}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" among"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435597080}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435597133}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But quality"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435597226}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435597274}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" want"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435673339}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435673392}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435673428}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cause visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435673462}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dips and recover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435734856}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ies; currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435734909}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435734945}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435735099}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435794110}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 26"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435794164}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435794222}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435794311}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso performance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435860749}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": bench"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435860802}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435860857}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s/100 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435860941}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435941230}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435941487}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5s/40 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435941524}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123435941696}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" optimize before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436004931}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shipping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436005002}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436005066}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436005117}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-time 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436078819}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"× (60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436078873}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/s) with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436078911}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300 herbs +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436079011}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436144753}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators + "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436144804}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1500 plants:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436144949}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per tick?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436144996}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436207414}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436207484}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".7s/300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436207531}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 ticks = 1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436207598}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"23ms/tick; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436276800}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436276857}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436276908}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rame ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436276954}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2× at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436343142}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60fps?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436343188}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2×="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436343223}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60 ticks/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436343264}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436420710}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 tick/frame) fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436420762}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436420799}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8× "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436420832}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"480 ticks/s ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436477700}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 ticks/frame ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436477747}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436477792}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436477831}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rendering; likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436541210}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay. Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436541284}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436541334}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436541677}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5s;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436607548}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436607626}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436607672}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" <1s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436608502}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436695932}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens not met"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436696009}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could optimize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436696070}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nearestPlant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436696127}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scanning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436761661}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with spatial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436761714}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" index"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436761758}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436761816}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436889835}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plantGrid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436889898}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436889960}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scanning radius"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436890026}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 11"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436913974}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436914029}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436914161}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436914206}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436988770}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436988836}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") is ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436988907}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"121–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123436989239}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"225"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437069838}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cells per prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437069915}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per tick ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437069955}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437070045}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437151213}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"67k;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437151257}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437151319}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nearestFa"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437151382}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"una prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437221781}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437221832}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" O"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437221875}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437221923}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k) and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437279656}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437279725}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"prey "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437279782}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"15k."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437279837}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437336717}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".23"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437336785}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms/tick is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437336834}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437336914}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437418427}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens 3000"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437418498}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks = 3."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437418551}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7s. To improve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437418599}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437493812}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4x, reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437493882}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437493929}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scan"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437493978}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" radius by using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437541445}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437541527}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" average"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437541591}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437541657}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437598515}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision. Could store"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437598620}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437598695}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437598767}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Or sample"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437686173}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a few"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437686240}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" random"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437686296}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437686339}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437740136}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Simpler optimization"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437740196}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": build"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437740244}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437740293}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant cell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437808066}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437808115}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437808157}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Nearest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437808199}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437881045}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can be optimized"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437881120}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" using expanding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437881304}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437881372}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" search and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437945300}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437945408}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exit; average"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437945490}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" case"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123437945569}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438025899}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly. Current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438025990}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scans full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438026163}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" square (11"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438026320}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×11) every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438085052}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438085140}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" even if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438085201}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nearest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438085326}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adjacent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438147933}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Implement ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438148014}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" search:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438148079}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scan"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438148150}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rings r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438207147}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=0,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438207247}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1,2... max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438207350}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438207423}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; stop when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438277561}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" found"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438277641}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438277716}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438277824}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" r and ring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438351057}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438351106}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 has no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438351184}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closer ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438354246}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"since Euclidean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438431494}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438431549}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stop when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438431592}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438431745}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ring distance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438495781}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" > best distance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438495828}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). This can cut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438496019}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a lot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438496095}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Similarly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438577555}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nearest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438577609}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Fa"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438577652}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"una can use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438577758}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spatial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438663236}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash for prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438663287}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438663373}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later if needed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438663417}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBut browser render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438731431}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438731510}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438731562}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438731666}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438796677}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438796765}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rame at 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438796891}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"× ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438796966}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438859292}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438859373}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rame? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438859429}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s define speed 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438859532}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"× = 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438943362}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/s = 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438943418}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick/frame at 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438943498}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fps), so ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123438943573}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.2ms/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439001683}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick, fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439001742}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At 8×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439001878}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 ticks/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439001935}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rame=10ms +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439059801}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439059906}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439059973}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ms → 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439060031}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fps borderline but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439176975}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay. We can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439177040}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439177084}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439177143}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parameters."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439204205}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1551obx7pee0y4proxnayd8j","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439204269}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439204360}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439204410}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439204844}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439204928}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439204973}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439205063}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439225348}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439225402}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439225657}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439225712}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439239487}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439239546}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439239597}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439239649}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439251615}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439251679}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439251864}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439251924}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439252443}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439252774}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439252853}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439256018}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439270842}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439270909}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439270961}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439271028}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439293139}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439293195}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439293238}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439293280}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439312589}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439312683}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439312730}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439312913}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439313171}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439313430}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439313479}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439313757}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439334537}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439334604}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439334740}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439334787}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439346837}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439346904}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439346956}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439347099}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439347192}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439347250}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439347295}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439347348}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439365583}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439365669}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439366880}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439366951}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439378850}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439379035}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439379127}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439379188}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439379557}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439379658}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439379758}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439379820}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439406897}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439410529}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439410692}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439410749}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439412486}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439412533}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439412634}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439412678}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439427657}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439427768}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439427850}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439427936}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439428332}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439428379}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439428419}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439428557}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439442918}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439442967}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439443007}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439443216}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439458908}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439458957}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439459774}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439459814}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439477100}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439477250}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439477327}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439477770}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439478364}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439478518}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439478567}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439478829}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439495981}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439496032}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439496134}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439496387}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439514295}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439514348}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439514465}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439514517}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439528840}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439528908}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439528975}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439529043}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439545603}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"340"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439545713}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439545807}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439546141}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439546468}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439546523}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439546657}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439546718}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439561328}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"270"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439561384}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439561528}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439561592}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439745700}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439745750}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439745801}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439746191}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439760521}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439760607}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439760684}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439760767}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439760831}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"06"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439760893}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439760944}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439760981}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439945116}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439945180}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439945228}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439945286}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439945353}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439945410}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439945478}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439945537}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"052"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439959548}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439959645}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439959715}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439959816}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439959897}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439959975}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960050}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960122}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960252}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"90"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960331}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960400}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960465}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960531}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960591}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960657}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439960705}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439961239}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"55"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439961296}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439961343}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439961419}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439961523}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439961574}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439962656}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439962705}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439962781}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439962834}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439962891}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439962935}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439963994}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"035"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439964045}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439964090}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439964173}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439964265}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439964344}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439964401}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439964455}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439964492}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439965600}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439965654}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439965694}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"03"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439965734}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439965773}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439965828}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439965870}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439966684}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439966727}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439966860}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439966929}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439966977}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439967017}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439967067}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439967906}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"14"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439967953}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439968004}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439968055}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439968097}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439968143}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439968207}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439969380}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439969464}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439969561}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439969772}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439969844}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"16"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439969892}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439969934}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439970813}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439970862}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439970952}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Spr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439971028}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439971092}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439971156}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439971199}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972009}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972077}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972141}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972218}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972295}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972365}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Spr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972787}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972862}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439972927}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439973019}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439973124}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439973196}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439974243}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439974319}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439974386}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439974448}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439974510}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439974573}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439974644}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439974687}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439975466}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439975531}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439975583}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439975687}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"004"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439975762}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439975805}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439975867}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439977109}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439977181}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439977253}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439977334}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439977403}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439978240}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439978311}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439978371}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439978432}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"003"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439978498}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439978639}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439978716}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439979027}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439979116}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439979201}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439979291}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439979370}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439982136}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"180"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439982187}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439982241}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123439982307}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440007173}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440007257}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440007325}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440007670}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440007738}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"165"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440007809}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440007875}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440007937}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440089744}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"items"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440089810}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"():\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440089968}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440090031}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440094300}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440094364}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440094473}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440094718}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440097343}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440097390}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440097440}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440097576}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440098750}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440098805}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440098873}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440099230}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440116450}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440116499}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440116539}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440116768}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440129997}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440130045}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440130090}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440130158}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440130933}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440131007}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440131064}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440131127}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440142151}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uned"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440142231}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440142332}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440142485}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440145526}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440145590}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440145754}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440145850}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440146951}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440147025}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440147175}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440147230}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440148671}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440148817}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440148859}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440149034}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440152608}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440152677}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440152734}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440152847}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440171161}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440171247}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440171360}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440171418}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440171657}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440171711}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440171763}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440172189}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440208758}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440208814}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440208878}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440208952}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440230381}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440230435}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440230543}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440230605}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440250487}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440250558}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"une"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440250639}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" toward"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440250772}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" more"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440285613}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" visible"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440285685}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cycles"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440285735}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440285782}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ret"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440338887}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440339092}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440339184}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3032,"ts_us":1793123440339312}}

data: {"id":"4042aca616a5a7b934cd633cc7f4c1dd","object":"chat.completion.chunk","created":1793123428,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":151409,"completion_tokens":1763,"total_tokens":153172,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":147456,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1385,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3032,"ts_us":1793123440367640}}

data: [DONE]

