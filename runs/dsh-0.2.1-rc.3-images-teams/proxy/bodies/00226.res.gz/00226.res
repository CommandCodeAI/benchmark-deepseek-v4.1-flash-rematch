data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243458902}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Ext"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243539853}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inct now shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243539952}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243540016}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end labels stacked near"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243608314}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243608377}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-right:\n- \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243608440}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"✳"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243608709}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" FLORA 133\" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243674885}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"right-al"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243674945}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"igned count)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243674988}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓\n- \"◎"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243675032}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HERBIVORA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243747756}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / EXTINCT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243747801}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G30\" ✓"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243747877}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- \"‹"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243747955}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CARNIVORA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243806216}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / EXTINCT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243806262}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G18\" ✓\nThese"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243806298}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read well"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243806336}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and are right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243880064}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-aligned values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243880123}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243880166}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they overlap the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243880256}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243954960}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243955012}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-right region"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243955087}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" where"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124243955164}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244011198}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curve dips"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244011254}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; acceptable since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244011301}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244011350}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244094870}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"right margin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244094949}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244095002}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244095052}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are in the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244147057}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right margin outside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244147110}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot; plot ends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244147146}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at x≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244147194}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244204346}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4; labels at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244204446}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 101"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244204523}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4.."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244204584}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1030"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244261034}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244261132}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244261211}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"133"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244261283}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244317160}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aligned at W"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244317239}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-9 = 102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244317306}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244317379}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"canvas W"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244384843}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244384922}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1036"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244384973}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244385055}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canvas wrap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244475134}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width 966 from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244475192}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x=62 to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244475292}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1028) → \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244475379}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"133\" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244544376}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~1015"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244544481}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244544542}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244544592}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244591450}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244591519}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlap the plate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244591787}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s right frame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244591838}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244642910}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They end right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244642971}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244643007}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame edge ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244643042}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"W-9)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244713953}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fine.\n\nHowever,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244714004}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"EXT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244714051}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"INCT G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244714102}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30\" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244771598}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244771651}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for Herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244771707}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora overlaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244771825}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244828384}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"FL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244828456}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ORA "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244828507}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"133\" label above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244828561}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Sp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244912080}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"acing:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244912183}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244912245}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124244912287}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"≈316"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245021267}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (fl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245021317}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora), 333"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245021378}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245021477}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"343"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245100567}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (herbivora), 356"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245100643}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/367 (carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245100697}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora) → gaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245100733}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245161525}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245161573}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245161608}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245161665}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 343"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245234724}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245234801}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora line1 at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245234879}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"356 → 13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245234997}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px gap fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245333928}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBut the leader"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245334001}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines are not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245334067}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible? There"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245334121}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are faint lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245429272}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245429350}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dots to labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245429411}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245429537}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dots at baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245554841}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245554923}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"≈975"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245554993}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" area; labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245555039}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 101"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245621147}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245621284}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm dots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245621652}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at x="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245621746}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245673079}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245673165}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40) which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245673219}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is plot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245673270}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right (100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245729807}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4); labels start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245729905}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1013"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245729944}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; short"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245730003}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" leader. I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245786753}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" see small circles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245786803}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245786845}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right near "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245786882}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1004?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245845108}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" There are dots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245845178}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245845231}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245845323}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of flora line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245907389}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245907452}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245907535}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct hollow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124245907614}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" circle at extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246009245}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246009367}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible (small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246009446}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rings at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246009527}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246079480}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246079606}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18) ✓ ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246079917}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"subtle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246080000}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n\nSummary: \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246124979}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Her"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246125073}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"biv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246125148}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246125341}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 lost G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246206962}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30\", \"Carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246207025}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora 0 lost G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246207076}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18\" gray"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246207131}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246257479}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246257559}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓. Weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246257619}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246257682}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246343647}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Largest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246343705}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fall: \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246343758}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"✳ −153 ·"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246343798}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G18, ◎"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246408152}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" −185 · G30,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246408236}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ‹ −52 · G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246408354}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18\" ✓. Standing:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246408434}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Flora persisted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246470709}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to G40. Herbiv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246470802}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora lost at G30;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246471098}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Carnivora lost at G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246471185}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18.\" — 2 lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246517371}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246517445}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot it's one line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246517505}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It reads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246517637}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246562890}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246562947}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"≈407"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246562993}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" single line maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246563070}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wraps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246617841}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246617910}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" single"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246617965}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line ending \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246618046}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"G18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246690483}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\" F"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246690545}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"its!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246690599}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Great — card"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246690631}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content ends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246824129}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~410"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246824234}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246824302}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" card bottom 410"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246824387}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; no clipping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246886706}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246886777}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nHmm but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246886842}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" standing text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246886947}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246938705}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6px"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246938759}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246938819}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"354 width: "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124246938920}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"68 chars won"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247001628}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t fit one line;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247001721}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247001838}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247001910}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Flora persisted to G40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247064132}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Herbivora lost at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247064212}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G30; Carnivora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247064281}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lost at G18.\" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247064353}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two lines but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247164757}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second line partially"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247164867}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hidden? Looking closely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247164921}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": at y≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247164963}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"403 \"Flora persisted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247220346}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to G40. Herbiv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247220392}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora lost at G30;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247220431}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Carnivora lost at G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247220502}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18.\" appears as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247280358}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" one line spanning full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247280405}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width — font is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247280455}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tiny (9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247280499}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6px italic;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247334799}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" average char ~4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247334860}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247334917}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px → 68"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247334972}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*4.2=285"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247410203}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px > "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247410250}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"328? it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247410301}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fits 328"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247410348}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"!). OK"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247464495}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" single line. Great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247464569}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBUT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247464656}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": The summary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247464732}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247530590}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"STAND"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247530667}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ING"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247530865}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" row is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247530907}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247601989}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" very bottom edge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247602078}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of the card;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247602149}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the card"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247602222}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom border may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247676785}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247676886}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" desc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247676956}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enders. Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247677020}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fitSummary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247725364}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247725447}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247725527}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", adds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247727805}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is-tight which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247791718}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hides rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247791808}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-sub/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247791877}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"weather meta. In screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247791986}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247851007}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-sub \"SEED"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247851068}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1977 · "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247851132}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 GEN · 4 WE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247851205}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATHERS\" still visible and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247933026}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weather meta \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247933103}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 visits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247933157}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ...\" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247933208}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247983031}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-tight not applied,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247983088}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247983167}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Height <= clientHeight."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124247983243}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248062987}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nTra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248063087}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"its extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248063216}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248063265}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"iv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248127568}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora row line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248127624}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ends at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248127672}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248127723}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"29 with end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248227346}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dot;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248227401}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top-right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248227447}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248227522}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"to G"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248288357}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"29\"; band ends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248288440}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248288511}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carnivora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248288570}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248338655}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G17"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248338719}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"to G17"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248338761}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\". Row labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248338800}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show \"lost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248394778}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248394843}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"/\"lost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248394891}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G18\" in wax"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248394945}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" italic ✓. Nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248464248}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nC"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248464306}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ensus extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248464364}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": Herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248464422}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivora curve drops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248523478}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248523780}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248523866}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and flat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248523947}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248653526}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carnivora at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248653598}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18. Good.\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248653643}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248653685}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248741607}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rofr49uubhs2l5kp6pmifdim","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248741680}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248741769}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248741827}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248741887}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248741956}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742087}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742134}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742196}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742260}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742345}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742434}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742515}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742599}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742669}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742731}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742778}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742833}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248742993}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743045}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743110}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743153}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743196}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743238}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743279}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743326}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743369}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248743412}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248746319}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248746388}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248746427}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248746475}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248766756}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248766815}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248766880}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248766992}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248767372}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248767433}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248767543}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248767613}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248782116}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248782195}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248782343}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248782441}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248797168}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248797256}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248797319}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248797371}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248813254}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248813336}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248813404}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248813463}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248829868}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248829923}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248829970}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248830050}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ense"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248845888}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248845942}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248846033}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34173,"ts_us":1793124248846094}}

data: {"id":"6dc4b39c7cc7565aef88f9be4022b199","object":"chat.completion.chunk","created":1793124243,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":204410,"completion_tokens":946,"total_tokens":205356,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":203136,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":859,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":34173,"ts_us":1793124248894846}}

data: [DONE]

