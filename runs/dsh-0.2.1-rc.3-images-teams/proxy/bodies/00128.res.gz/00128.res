data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596850431}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_73dwo5pjjd3822ief27mtvm7","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596850510}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596850539}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596890833}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596890974}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596891113}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596891299}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596893798}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596893929}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596893987}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596894438}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596903529}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596903687}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596903823}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123596903948}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597029844}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597030019}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597030120}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597030241}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597033352}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597033401}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597033474}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597033941}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597033995}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597034075}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597034281}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597034787}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597037268}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597037408}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597037455}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597037574}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597064346}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597064470}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597064511}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597065209}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597066515}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597066602}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597066814}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597067037}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597068127}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597068387}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597068445}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597068653}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597069140}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597069286}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597069440}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597069523}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597077540}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597077647}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597077799}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597077844}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597086833}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597087023}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597087102}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597087498}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597112060}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597112117}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597112259}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"offset"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597112334}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597142428}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597142501}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"150"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597142654}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597142718}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597167276}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597167420}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"limit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597167471}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597167773}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597242760}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"120"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597242813}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1872,"ts_us":1793123597242982}}

data: {"id":"5c72013a2eb4174b6bcdeae267d7169d","object":"chat.completion.chunk","created":1793123596,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":166061,"completion_tokens":116,"total_tokens":166177,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":163584,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1872,"ts_us":1793123597243501}}

data: [DONE]

