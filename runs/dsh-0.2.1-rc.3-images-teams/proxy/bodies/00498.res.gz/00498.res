data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127130939907}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131035145}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" messages/status"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131035418}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131035685}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_bdkwp6mf84iu7aucqxeod7nw","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131041493}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131042553}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131042696}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131042862}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131048614}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131049982}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131050126}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131063594}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131063667}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131063731}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131063786}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131063862}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131063927}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131063999}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131064088}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131064198}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131064273}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131064339}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131064405}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131064468}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131101362}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131102239}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131102356}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131102483}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131107602}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131135575}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131135709}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131135853}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131135954}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131136035}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131136116}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131211956}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131212063}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131212207}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131212327}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131212372}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131212451}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131212531}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131218087}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131218216}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131218376}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131218499}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131218630}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131218810}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131218893}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131230528}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131230671}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131230712}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131230835}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131231003}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131231122}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131242958}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131243096}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131243227}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131243341}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131248864}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131249139}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131249186}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131249227}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131249266}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131249353}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131261302}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131261406}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131261532}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131261698}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131261806}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131261952}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131262056}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131273878}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131274034}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131274152}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131274218}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131274364}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131274465}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" */"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131274644}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131286127}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131286226}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131286325}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131286402}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131286512}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131294515}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131294650}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131294747}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131294879}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131310140}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131310209}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131311947}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" module"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131312090}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" freeze"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131342728}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131343232}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" again"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131343344}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131343422}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131397966}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_egadp5h86rppfqgw4x6srmxn","type":"function","function":{"name":"team_task_list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131398046}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131398103}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131398161}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"status"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131418619}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131418975}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131419068}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131419152}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"completed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131479883}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131481035}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10654,"ts_us":1793127131481130}}

data: {"id":"4d9a143e450a3ed75aa9e7b1748dbc22","object":"chat.completion.chunk","created":1793127130,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":344777,"completion_tokens":162,"total_tokens":344939,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":344320,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":5,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":10654,"ts_us":1793127131487251}}

data: [DONE]

