data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124846960655}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"While"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847025461}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that runs (~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847025504}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"75s), let me examine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847025550}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the screenshots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847099432}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from the official"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847099529}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847099636}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847099673}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" captured ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847150035}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"record-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847150208}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1440, record-fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847150246}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-1440,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847150364}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record-128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847225497}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, reduced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847225574}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-record)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847225618}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847226677}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" QA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847369616}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847369703}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crucial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847369974}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847370071}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847440642}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-record-1440.png"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847440690}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and verify-record-fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847440727}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-1440.png ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847441194}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847496908}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847497006}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847497065}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847497110}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 = different"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847553760}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847553835}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847553909}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847553956}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_n5tbhkulcigehofmas2qb4s4","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554042}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554119}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554190}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554260}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554311}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554400}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554531}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554621}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554683}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554807}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554879}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847554944}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847555003}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847555119}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847555171}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847555230}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847555295}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847555363}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847555416}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847555553}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847557911}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847558015}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847558109}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847558172}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847558325}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847558427}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847558561}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847558608}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847572338}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847572502}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847572593}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847572717}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847589946}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847590031}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847590155}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847590218}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847590360}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847590462}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847590567}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847590672}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847604537}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847604593}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847604669}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847604763}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847618085}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847618162}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847618230}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847618363}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847618462}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847618552}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847618598}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847618641}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847630956}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847631013}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847631158}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847631216}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847644874}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847644956}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847645038}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847645092}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3831,"ts_us":1793124847749890}}

data: {"id":"48e46afbf989affc2a026bd478d121f6","object":"chat.completion.chunk","created":1793124846,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":273059,"completion_tokens":164,"total_tokens":273223,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":272640,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":75,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3831,"ts_us":1793124847750022}}

data: [DONE]

