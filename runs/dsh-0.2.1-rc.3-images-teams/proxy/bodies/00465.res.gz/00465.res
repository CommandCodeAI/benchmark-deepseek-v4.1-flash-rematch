data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711008537}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"All"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711117450}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good:\n- one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711117535}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gen/empty harness works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711117621}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- DPR2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711184999}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": backing ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711185069}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2× CSS box"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711185133}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exactly.\n\nLet me view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711185221}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the dpr2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711248022}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711248078}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to confirm crisp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711248112}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ness (optional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711248379}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711308592}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" More useful:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711308686}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect onegen final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711308797}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual for the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711308956}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inline end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711398895}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels improvement."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711398986}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ae4fqhjxd3qqu46ampkvmoo9","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711399312}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711399405}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711399578}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711399895}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711400000}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711400102}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711400276}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711400465}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711400837}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711400931}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711401051}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711401184}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711401398}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711401494}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711413640}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711413694}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711413840}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711413921}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711489873}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711489941}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711489992}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711490040}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711490652}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711490703}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711491637}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711491716}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711496607}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711496658}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711496813}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711496893}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711504088}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711504135}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711504189}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711504280}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711505695}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711505817}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711505868}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711505978}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711524773}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711524827}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711524872}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711524952}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711526519}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711526600}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711526692}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711526840}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711527721}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711527862}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711527976}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711528048}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711533553}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711533631}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711533699}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711533761}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-one"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711553530}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711553592}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711553676}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711553751}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":14696,"ts_us":1793126711612394}}

data: {"id":"505af44219450651ab9ad1e111655f96","object":"chat.completion.chunk","created":1793126710,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":279676,"completion_tokens":143,"total_tokens":279819,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":279552,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":56,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":14696,"ts_us":1793126711612498}}

data: [DONE]

