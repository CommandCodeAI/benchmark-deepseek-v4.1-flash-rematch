data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615703396}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xgrwjl0usrm5ax0pmu86vx1w","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615703469}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615703500}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615746916}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615747056}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615747106}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615747378}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615766834}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615766966}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615767025}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615767317}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615773128}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615773308}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615773502}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615773574}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615774659}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615774771}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615775095}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615775180}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615777283}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615777409}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615777456}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615777781}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615788271}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615788416}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615788486}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615788544}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615788836}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615788881}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615788927}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615788967}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615789363}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615789434}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615789484}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615789529}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615789947}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615789990}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615790047}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615790096}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615790153}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615790541}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615790811}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615790856}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615802414}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615802515}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615802801}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615803053}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615810775}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615810840}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615810928}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615810983}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615811416}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615811700}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615811800}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615812129}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615831204}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"174"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615831488}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615831546}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615831657}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615860216}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615860281}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615860332}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615860470}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615861242}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615861384}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615861689}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615861753}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615923874}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615923979}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615924073}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615924209}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615928325}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615928479}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615928548}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615928685}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615934903}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CSS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615934947}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" block"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615935012}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615935150}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1717,"ts_us":1793123615973852}}

data: {"id":"cb94dea07cc70ad6701eda0f674fc95b","object":"chat.completion.chunk","created":1793123615,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":169383,"completion_tokens":114,"total_tokens":169497,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":168832,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1717,"ts_us":1793123615974071}}

data: [DONE]

