data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125740727551}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"While"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125740835932}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview3 runs,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125740835988}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" let me improve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125740836031}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125740994584}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generator for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125740994645}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125740994695}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" include module"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125740994754}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-Q"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741051964}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"A? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741052013}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741052077}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sure report reflects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741052154}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" results after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741112149}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741112226}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Update report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741112282}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mjs:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741112390}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mapping §"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741181489}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741181549}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741181591}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" item 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741181640}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741242935}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741243008}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741243106}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso add \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741243147}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"how"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741328661}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to reproduce\" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741328740}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Environment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741328806}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" details"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741328873}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741374587}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741374673}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rome version, node version"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741374744}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741374813}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capture Chrome version"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741450632}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via browser /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741450729}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"json/version; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741450813}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741450882}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation read from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741505683}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a file written"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741505765}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by suite?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741505838}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Simpler: report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741505910}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741566215}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" version and Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741566297}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" version static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741566353}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741566406}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741614869}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/lib"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741614955}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741615032}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"dp`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741615086}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Add EN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741693827}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V check in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741693881}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser suite:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741693918}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741693965}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" version via page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741779528}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741779589}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"val navigator.user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741779676}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Agent (head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741779743}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less UA contains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741857098}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome/..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741857169}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Store"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741857224}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741857283}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741941221}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in browser suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741941288}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after launch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741941341}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125741941423}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".note('ENV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742025166}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-UA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742025214}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"', ...)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742025550}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742025594}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Agent from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742076461}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742076509}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Need page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742076578}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742076629}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742144524}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742144584}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"json/version fetch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742144633}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at launch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742144707}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742222172}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742222241}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Browser.version"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742222296}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742222349}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742298063}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742298130}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" launch fetch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742298213}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742298268}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742439963}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742440042}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Implement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742440077}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": browser.version"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742440140}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" available; after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742490047}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" launch rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742490113}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".note EN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742490163}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742490231}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" version.B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742543665}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowser. Add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742543731}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742543802}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742543854}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": A7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742616369}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742616559}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" occurrences"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742616604}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" empty"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742616676}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → \"clean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742746020}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" (P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742746065}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ASS). Good.\n\nAlso need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742746117}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742746177}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" single"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742812600}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-file requirement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742812647}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": round"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742812685}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1 dir"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742812719}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only 1 file pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742870302}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742870348}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \n\nDo report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742870395}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ENV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742870447}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742933911}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742933962}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" env"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742934006}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note. Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742934060}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742992201}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742992259}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742992329}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"90"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125742992393}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081202}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_iclmh69s6l0uyq78bk3frc3a","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081291}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081358}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081409}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081461}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081513}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081667}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081736}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081782}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081828}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081880}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081920}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743081960}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743082001}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743082046}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743082085}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743091085}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743091139}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743091192}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743091242}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743091785}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743091836}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743091896}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743091952}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743099382}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743099426}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743099506}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743099574}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743126476}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743126538}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743126596}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743126638}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743161892}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743161962}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743162005}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743162056}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743162643}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743162714}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743162807}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743162876}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743201447}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743201512}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743201545}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743201594}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743202291}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743202338}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743202424}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743202503}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743220303}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743220353}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743220393}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743220471}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743239950}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743239993}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743240035}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743240084}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743241253}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743241301}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743241347}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743241388}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743255404}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743255469}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743255526}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743255613}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743272562}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743272612}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743272662}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743272750}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743289696}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743289762}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743289821}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743289862}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743290507}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743290586}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743290668}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743290741}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743306480}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743306550}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743306608}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743306655}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743325307}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743325406}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743325535}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743325810}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743325927}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743326016}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743326101}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" launch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743326169}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743347388}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743347484}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743347559}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743347632}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743371166}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743371274}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743371750}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743371841}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743371916}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743371992}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743372067}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743372133}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743394030}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743394116}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743394183}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743394247}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743451315}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743451415}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743451495}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743451589}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743451668}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743451858}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743451950}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452033}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452108}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452181}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452252}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452328}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452612}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452710}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452796}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" launch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452882}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743452963}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743453043}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743453131}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" width"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743453202}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743462782}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743462855}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743462943}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743463008}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743480870}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" height"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743480951}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743481013}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743481073}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743482615}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743482677}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743482734}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743482800}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743516228}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743516303}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743516348}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743516449}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"res"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743529279}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743529416}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743529494}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fetch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743529568}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743547261}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"http"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743547366}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743547442}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"127"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743547520}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743562926}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743563025}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743563128}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743563222}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743564538}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743564632}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743564773}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743564837}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743579394}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743579514}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743579608}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"port"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743579686}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743600339}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743600431}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743600502}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743600570}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`);\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743600663}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743600817}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743600877}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743600923}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743622218}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743622317}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743622392}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"res"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743622459}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743638139}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743638248}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743638328}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rec"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743638382}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743638719}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ote"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743638786}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743638839}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743638888}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743672793}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743672852}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743673006}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"WS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743673052}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743673207}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743673261}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743673313}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743673378}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743710987}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743711065}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743711117}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743711579}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743737488}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743737579}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743737650}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743737718}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743771285}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743771355}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" protocol"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743771463}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743771555}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743779930}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743780007}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Protocol"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743780083}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743780164}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ersion"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743781763}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743782129}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743782203}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743782270}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743802536}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" area"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743802587}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743802626}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743802683}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"env"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743826968}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743827034}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743827090}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743827135}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743839793}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743839870}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743839932}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743839992}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ignore"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743861176}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" */"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743861269}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743861349}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743861392}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743870450}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" catch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743870535}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743870606}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743870664}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743889353}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743889402}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743889461}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743889513}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743891287}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743891383}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743891436}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743891478}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743907024}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743907109}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743907165}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743907215}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743923466}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743923523}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"env"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743923698}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743923759}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743924302}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ched"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743924350}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743924519}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743924563}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743944089}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743944172}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743944252}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743944309}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743957571}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743957638}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743957696}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743958509}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743958637}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743958723}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743958794}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743958836}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" OK"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743973586}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743973659}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743973724}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743973823}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743990597}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743990676}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743990739}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743990799}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743992268}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743992348}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FAIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743992416}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125743992485}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744031990}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744032073}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744032120}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744032165}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744033327}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744033386}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744033439}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744033518}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744033620}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744033951}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744034037}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744034107}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744046442}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744046484}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744046528}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744046628}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744067358}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744067440}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744067506}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744067568}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744103082}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744103183}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744103271}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744103546}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744120796}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744120959}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744121098}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Add"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744121166}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744168761}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" version"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744168857}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744168933}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744169011}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744177671}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744177725}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744177817}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744177901}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22201,"ts_us":1793125744227415}}

data: {"id":"3f90b3a65cb661bbee4d4df92fcd714f","object":"chat.completion.chunk","created":1793125740,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":318207,"completion_tokens":616,"total_tokens":318823,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":316928,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":273,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":22201,"ts_us":1793125744227487}}

data: [DONE]

