data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915377811}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Tim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915409402}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed out with no message."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915409480}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Check statuses and m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915409525}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"times."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915488190}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1s95y2jh4si454n7ljl2780f","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915488279}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915488365}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915489085}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915489957}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915490079}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915490167}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915494565}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915494716}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915494776}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915494845}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915494901}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915501962}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915502090}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915502160}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915502207}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915518746}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915518804}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915518845}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915518927}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915535184}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915535252}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915535297}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915537328}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915551554}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915551651}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915551722}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915553745}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915573678}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915573752}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915573817}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915573880}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915607626}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915607687}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915609009}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915609135}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915609179}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915609284}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915609415}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915609483}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915648148}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915648500}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915648586}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915648668}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915658606}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915658702}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915658786}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915658880}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915663280}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915663376}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915663456}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915663538}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915672563}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915672650}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915672913}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915672990}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915675687}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915676088}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915676240}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915676493}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915683868}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915683958}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915684036}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915684181}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915700848}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915700940}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915702154}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915702282}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915702621}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915702744}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915702824}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915702900}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915736194}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915736361}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915737203}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nder"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915737294}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915737472}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915737610}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915737693}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915737876}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915766036}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915766160}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915766255}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915766390}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915768023}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915768115}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915768196}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" */"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915768270}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915779235}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915779310}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915779378}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915779446}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915844892}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915844960}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915845015}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915846073}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915846206}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915846275}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915846345}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915846404}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915852158}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915852533}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" are"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915852604}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" frozen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915852660}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915916590}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915916641}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_o4mj21m6fuijiu7sos2gyy9v","type":"function","function":{"name":"list_agents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915916737}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11085,"ts_us":1793126915916812}}

data: {"id":"2c8736cf0b456fca9911820db6ff6b86","object":"chat.completion.chunk","created":1793126915,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":340251,"completion_tokens":167,"total_tokens":340418,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":339200,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":14,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":11085,"ts_us":1793126916026909}}

data: [DONE]

