data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115128323}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Wild"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115156443}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" oscillation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115156597}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115158089}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115213391}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115214232}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens: herbivores 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115214288}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"→411 in one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115214380}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen (!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115290978}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") because initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115292412}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115292613}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115292694}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and reproduction occurs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115369233}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" immediately for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115370168}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many; plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115370293}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" got"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115370458}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" destroyed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115444385}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (574 plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115445242}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deaths in gen 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115445366}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", eaten"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115445446}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1211"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115507097}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115507995}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators bo"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115508200}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"omed to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115508309}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"99 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115568987}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115569798}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" went extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115569925}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115572870}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115631912}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115632626}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115632741}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115632851}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial conditions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115717621}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are too hot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115718542}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115718666}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivores reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115718783}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instantly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115863764}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115864721}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115864767}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ze,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115864866}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115887457}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115888231}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rash; predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115888349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115888537}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hoot."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115944535}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115945504}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115945571}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" things"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123115945655}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" down"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116015384}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and establish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116016283}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116016426}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116016470}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nKey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116087588}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issues:\n1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116088487}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116088575}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore energy 0.62"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116088663}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–0.86 vs threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116180094}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116180880}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".02; they quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116180994}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116181128}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116252874}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce. Birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116253696}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116253787}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 339 in gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116253836}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1: 150 initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116321334}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + 339 births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116322233}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" - "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116322319}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"78 deaths = 411."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116322434}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That's ~2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116390699}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".3 births per starting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116391487}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivore in "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116391626}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 ticks. Too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116391672}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high. Lik"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116454600}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ely eat lots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116455435}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116455564}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; energy gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116455638}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116563860}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bite high;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116564773}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116564877}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can eat multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116564932}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116612683}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116613496}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116613600}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat only one plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116613706}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per tick."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116715991}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Each plant can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116717471}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" give many bites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116717636}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" until"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116720409}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" depleted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116862845}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116863813}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116863960}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116864006}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116903272}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116904150}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → gain ~0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116904210}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"38 per bite; 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116904295}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks = 11.4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116918643}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116919489}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" potential"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116919668}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; threshold 1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116919733}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"02 reached"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116993422}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116994370}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116994423}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123116994588}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117069012}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117070884}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117071014}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" times per gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117071084}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? cooldown "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117139802}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12 ticks, threshold 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117140728}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".02: after birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117140846}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy 0.47"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117140888}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117228927}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 bites back"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117229046}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117230535}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.0 → wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117230622}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12 ticks..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117304085}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could reproduce ~2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117304853}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"x/gen."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117304968}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That's high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117305048}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117367503}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117367619}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 121"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117369068}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 bites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117369132}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen ≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117479204}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117479291}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants/pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117480824}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117480921}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117502066}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wiped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117503018}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117503089}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y can eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117506064}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same plant over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117581353}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiple ticks ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117581471}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"bite 0.42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117581867}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of plant energy ~1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117581908}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".0 → 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117648749}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117649683}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bites). Need reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117649742}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intake"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117649857}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117721734}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117722415}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117722547}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frequency"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117725717}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n2. Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117793094}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator hunt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117794745}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117794831}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 73 in gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117794880}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117871665}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117871752}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117873207}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117873261}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then 152"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117937874}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117938727}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117938773}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123117938862}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 99 predators; predation over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118014667}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118015408}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ills. Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118015476}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118015610}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instantly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118073220}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too. Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118074068}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator biomass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118074132}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118074228}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118194349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118194453}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118195895}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118195958}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" die out when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118223220}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118224077}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118224163}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118224306}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118297919}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118298864}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118298998}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", cooldown longer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118299095}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", energy share"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118369019}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower), and predation rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118369185}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower.\n\n3. Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118370945}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": growth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118371016}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118448625}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118448782}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118450465}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118450625}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118528858}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" times"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118528918}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118528952}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118531026}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118668012}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" length"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118668863}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30 ticks maybe too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118668913}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" short for creatures to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118669003}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce once"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118689008}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118689944}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" here"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118690049}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118690161}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" times"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118763643}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nGoal: population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118764441}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118764549}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spanning ~10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118764596}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118814302}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20 gens, not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118814395}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118815878}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–3. In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118815924}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118889653}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens want"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118890504}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~3 cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118890593}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118890635}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118972400}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Raise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118973240}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction thresholds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118973407}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123118973464}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119044152}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119044969}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; leng"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119045018}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"then cooldowns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119045137}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; make reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119107596}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probabilistic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119107667}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119107723}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" than immediate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119109594}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" once threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119181721}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119182592}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119182639}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119182721}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold and then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119253214}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119253307}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".g. 0.02"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119253376}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119255421}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119381585}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" once"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119382484}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" above threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119382532}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119382669}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" accumulates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119426486}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119427306}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set cooldown in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119427348}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations (e.g. "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119427426}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119474743}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119475617}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119475696}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 15 ticks). Let's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119475793}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" think desired"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119525612}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per-cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119525747}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ita birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119527096}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119527178}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nIf each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119607987}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivore reprodu"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119608475}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ces about"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119608743}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119608843}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119690145}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–12 gens (heavy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119690971}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119691211}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119691279}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119768020}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119768804}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predation/st"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119768877}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arvation every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119769007}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119908773}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119909691}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119909778}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stabilize. With 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119909880}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119926949}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen and energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119927086}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119928665}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119928727}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119979406}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119980301}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy accumulated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119980394}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" across a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123119980479}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" few gens and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120062573}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cooldown "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120063531}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120063601}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120063728}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 gens). That's slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120133331}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120133421}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120133468}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But then genes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120135377}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/th"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120212770}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"reshold selection"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120212889}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could instead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120214465}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120214599}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 30 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120269062}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen but make energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120269146}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" economics such"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120270872}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120270916}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mature adult"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120336548}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120337429}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120337525}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over ~2 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120337693}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120407885}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120408726}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy intake enormous"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120408787}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's quantify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120408907}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120476697}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick with current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120477544}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120477685}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore eats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120477748}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant bites up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120545135}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 0.42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120545969}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120546045}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120546160}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~0.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120623659}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → 0.38 per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120623826}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick. Cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120625205}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~0.004"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120625318}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2+0.003"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120697382}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6+0.002"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120698206}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6+0.001"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120698251}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5+move"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120698333}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.0013"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120768683}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≈ 0.013"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120769598}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120769776}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Net +0.367/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120769904}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick if always"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120867091}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eating. Obviously"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120867859}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120867981}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much. Real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120868055}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"istically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120922942}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing contact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120923704}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120923924}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" few ticks."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123120924024}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But even"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121004316}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121005379}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121005577}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121005747}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121073103}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.038"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121073287}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick net"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121073378}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still +0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121075308}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".025 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121212216}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121212362}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121213800}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121213903}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121248483}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing rare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121249328}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121249458}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121249522}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121319511}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121319597}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121321090}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 560/144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121321141}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"00=3.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121402623}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121403528}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and perception/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121403613}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ovement; currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121403654}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121463233}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121464002}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121464101}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly, yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121464181}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121552753}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still eat "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121553737}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1211 bites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121553819}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121553868}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121652914}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 (~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121653803}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121654010}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121654062}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121727940}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore) — because plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121728717}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clustered"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121728948}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So prey find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121729014}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants easily"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121780362}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nOptions:\nA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121781297}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121781387}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Reduce energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121781433}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per bite drastically: bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121838391}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.2,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121839413}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121839504}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.55 → gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121839636}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121926157}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.12; but plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121926963}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121927088}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123121927154}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122009780}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122010652}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122010802}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4 bites. Cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122010870}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per tick "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122069373}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.013, need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122070280}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat ~1 bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122070364}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/9 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122070457}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122146470}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122147379}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plausible."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122147510}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But at plant density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122147593}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4%, they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122229322}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may not find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122229488}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122229740}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"—"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122229815}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122299828}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" starve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122299970}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122301427}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need to reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122301514}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122380344}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nB) Keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122380411}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intake"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122381811}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but lower reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122381852}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" opportunity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122463831}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": require"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122464742}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold 2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122464786}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122464875}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"energy cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122525009}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122525866}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122526070}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" impossible) —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122526267}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122596550}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nC) Add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122597545}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122597783}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122597859}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and cooldown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122692765}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122692919}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Better to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122694354}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" model life"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122694530}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122756445}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": energy >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122757040}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122757180}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → spend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122757234}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122846797}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to reproduce after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122847668}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a minimum"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122847753}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122847794}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; offspring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122922972}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122923131}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 35"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122923275}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%. Cooldown "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122923442}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"90"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122990335}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122990437}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 gens). This controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122991893}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth rates. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123122991977}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy threshold high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123094396}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (1.2)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123095352}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with costs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123095419}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123095525}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123140617}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\nD) Scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123141583}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123141779}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123141828}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60 ticks?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123222173}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123222263}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123222315}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-gen counts changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123224406}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but reproduction co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123282380}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown too.\n\nLet's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123283193}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123283242}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sensible energet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123283338}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123345550}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Plant energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123345647}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123346977}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.7–1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123347025}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123500462}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bite min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123500599}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123502094}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".energy, 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123502144}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123529676}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") with digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123530487}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.65"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123530669}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → 0.12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123530741}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per bite;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123577181}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a plant yields"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123577972}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~4 bites.\n- Herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123578066}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore metabolism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123578179}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123653855}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123654790}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.012/tick →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123654846}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.36/gen."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123654948}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Needs ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123726271}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 bites/gen to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123727184}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" break"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123727293}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" even;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123727346}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123782955}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123783867}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bites/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123783950}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123784050}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123868997}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123869057}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen. With vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123870400}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123870484}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123924300}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density, they can find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123924413}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123925787}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123925905}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123997242}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 plants/gen? Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123998117}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant density "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123998214}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123123998263}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%. Movement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124064886}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124065967}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cells/tick over 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124066048}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124066167}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" passes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124130350}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" through ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124131266}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"33 cells; if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124131400}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124131548}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4% occupied"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124206656}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", ~1.3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124207658}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant encounters/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124207723}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; each plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124207817}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124283930}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 bites = 5."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124284765}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 bites/gen. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124284893}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124285033}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to survive and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124350454}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slowly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124351231}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grow. After"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124351291}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124351414}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"row, maybe more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124419692}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124420584}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124420927}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".15, start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124421027}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy 0.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124482304}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; gain ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124482413}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.2/gen → reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124482540}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124484335}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124567625}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124567734}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124569066}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cooldown 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124569116}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks (2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124629076}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens). Population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124629192}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doubles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124630707}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124630784}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124696089}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 gens → boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124696238}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124697658}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124697762}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124764071}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124764150}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ation &"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124765673}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124765763}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124843969}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124844861}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Herbivore death"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124844950}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": starvation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124844989}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124912944}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy <="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124913032}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, plus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124914552}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predation. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124914613}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124969599}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" efficient"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124970665}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124970710}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123124970820}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator:\n- Plant-e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125037284}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ater"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125037395}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125037470}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125039635}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".0; meal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125106473}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gain = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125107403}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.18 + prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125107480}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".energy*0.35"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125107641}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≈ 0.53"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125179956}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Cost ~0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125180019}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".02"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125180056}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125182124}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.6/gen."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125247595}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125247698}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125249340}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 kill/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125249390}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to survive."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125372420}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" With"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125373349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 24 predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125373473}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125373573}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 150 prey, kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125409953}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125410854}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125410906}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125411011}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125479309}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be ~0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125480075}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".7–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125480182}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1/gen."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125480219}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Initial kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125554605}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 73/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125555403}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125555494}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"24 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125555591}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125620354}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125620433}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125621943}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too high. Need hunting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125622017}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harder"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125688331}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125688531}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125689883}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125689945}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125751916}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.38 vs prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125753234}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.12, kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125753482}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125753567}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.92"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125819497}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125820280}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125820483}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125820564}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" often"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125926208}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fuel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125926331}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125927437}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125927518}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125938663}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125938749}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125940510}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators chase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123125940555}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; contact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126021233}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126021356}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126021431}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Reduce kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126023502}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range to 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126085593}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".55"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126086580}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", reduce predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126086645}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed advantage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126086787}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126164538}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126165412}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126165555}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator meal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126165610}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" smaller"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126237379}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", more expensive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126238281}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126238430}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126238494}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126368994}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve unless prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126369888}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" abundant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126370000}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126370058}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" where predators kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126476870}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126477671}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126477755}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126477820}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126575517}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126575595}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126577068}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2–4 gens."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126577122}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" That's hard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126611051}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126611938}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hand"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126612060}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-tune; iterate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126612194}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlternative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126685945}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simpler approach: use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126686042}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126687624}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probability"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126687692}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + energy;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126835953}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use fewer births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126836856}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126836961}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- Cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126837009}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126853499}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per generation by requiring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126853614}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cooldown in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126855254}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations (e.g., "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126855300}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126972914}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens) and threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126973705}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126973823}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123126973857}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y still can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127005349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overeat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127005458}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127005494}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127007642}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127047850}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen if contact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127048780}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate high; reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127048884}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127048974}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127126448}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127126556}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127128079}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127128210}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per tick ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127212207}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"only one kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127212935}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127213043}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", already);"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127213085}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127292450}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 kills/p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127293195}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"redator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127293344}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen means encounters"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127293436}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127350900}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 times"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127351005}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127351095}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". With prey density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127351146}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 150/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127413647}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"14400=1%,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127413774}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127415321}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127415364}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scanning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127498161}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 113"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127498955}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cells finds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127499028}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~1 prey; chase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127499185}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127565009}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127565930}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127566092}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reduce predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127566211}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127644737}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127644902}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127646350}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127646431}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey evasion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127712607}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more effective"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127712761}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127714464}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127714544}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127780591}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127780743}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127782089}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.85 (currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127782185}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127847980}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5 limit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127848852}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", effective"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127848984}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4.8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127849097}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127932607}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.85=4."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127933457}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1);"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127933616}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127933672}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6.2; fleeing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127991650}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey moves away"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127992525}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127992717}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" faster"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123127992799}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128055600}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.38 vs 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128055654}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128055695}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128055734}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128122600}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.12*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128123619}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.12=1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128123694}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"25 while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128123816}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fleeing. Predator gains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128195284}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128196112}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128196155}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick; needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128196235}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~5 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128265393}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to close "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128265505}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128267054}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128267103}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cells"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128344030}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Enc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128345052}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ounter rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128345163}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still. Could raise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128345311}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey flee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128391039}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed to equal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128391823}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128391954}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed (pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128392031}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y base"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128469179}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128470026}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128470087}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128470188}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=1.34"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128540817}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs predator 1.38"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128540908}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and reduce predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128542260}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" base"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128542345}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128629668}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.3. Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128629767}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kills r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128631221}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arer. Good.\n- Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128631260}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128729081}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cost high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128729710}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; meal moderate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128729801}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128729830}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128780340}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128781233}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128781271}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and cooldown 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123128781316}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129060512}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". They might star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129061377}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve; tune"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129061455}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nThis balancing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129061555}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can take iterations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129075407}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I'll write a parameter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129075484}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ized tuning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129077056}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harness that adjusts K"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129077144}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129096767}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constants via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129096862}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" creating"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129098311}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" worlds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129098357}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129111787}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" K is internal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129111859}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not exposed for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129113469}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation. I can expose"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129113559}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" T"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129135306}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UNING"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129135404}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" object"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129135522}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and mutate its"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129135570}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" properties before create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129206551}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World. Yes `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129207523}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129207561}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".TUNING` is K"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129207663}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129272120}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modifying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129272198}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129273600}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also config mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129273767}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129343591}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"regrowth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129344552}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129344727}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129344772}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129402728}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129403550}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constants using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129403698}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129403856}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129490197}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", scoring"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129490315}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stability"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129491927}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129492041}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129563718}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129564589}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (esp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129564632}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129564795}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n- Count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129652356}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129653320}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ranges"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129653425}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": flora 250"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129656322}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–140"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129715938}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, herb "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129716030}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129717505}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–300"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129717561}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", carn 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129782370}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–60.\n- Non"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129782472}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"zero variance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129783991}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129784029}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cycles.\n- At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129848192}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" least"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129848343}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129849767}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" present"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129849881}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129967182}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129968022}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≥"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129968077}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"90% seeds; herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129968193}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≥90%;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129998387}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129999161}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.\n- Events occur"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129999248}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123129999337}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"it drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130080472}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130080576}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130081878}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130081957}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to bounds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130178152}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130179138}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" much.\n\nBut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130179257}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130179352}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ware: adjusting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130234196}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constants via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130235013}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tuning script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130235109}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" isn't persistent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130235155}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130394742}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" once"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130394826}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chosen,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130396370}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bake"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130396441}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" into engine.\n\nFirst, understand"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130429473}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130430401}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130430448}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130430554}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130457962}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130458956}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130459040}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130459125}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130514900}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y consume plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130515049}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130516448}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130516498}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash ->"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130583723}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130584670}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crash), and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130584723}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130584877}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom. To stabilize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130652414}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130652517}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Slow prey reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130653951}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130654057}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130734922}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n2. Slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130735029}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator reproduction; prevent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130735109}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130735200}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n3. Ensure predators have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130793460}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" refuge at low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130793589}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey densities"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130793633}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? General"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130795772}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130862243}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130863192}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eat plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130863245}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130863340}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Predator extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130929522}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" risk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130930389}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130930437}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130930533}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" systems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130997466}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130998344}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130998451}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we want"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123130998492}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131075430}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to show cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131075529}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131077005}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" occasional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131077090}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131144275}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptable?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131145221}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131145339}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131145398}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131217262}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131218239}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131218292}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131218404}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run with chart showing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131292240}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all populations. If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131292339}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131292393}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" go"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131294582}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131366167}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131366284}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131367765}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fails. Need generally"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131367857}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" robust ecology"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131449714}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131449859}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131449904}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"imm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131451996}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"igration\" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131514723}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131514900}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Not natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131514944}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in a sealed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131517046}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" terr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131623091}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arium, but could have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131623240}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131624896}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ormant seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131625003}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bank\" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131669804}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131670691}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131670892}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131671021}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131750785}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could add predator energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131751603}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maintenance lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131751707}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131751773}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they survive sl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131823969}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"umps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131824028}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131824078}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131826300}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ugia"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131903334}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131903395}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" model predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131904901}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131905041}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131978975}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131979112}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ing\" behavior"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131980502}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and low metabolism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123131980642}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132177783}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey scarce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132178923}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132179043}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132179085}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132228909}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no prey ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132229017}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"amb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132230591}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132230643}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). That helps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132242408}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" survive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132243341}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132243427}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. Also prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132243524}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132278074}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132278860}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132278991}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ugia; plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132279051}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132354987}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nIdea"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132355039}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": predator at low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132356317}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132356410}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can scav"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132451087}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enge? Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132451212}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"tor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132451261}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"por"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132453401}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" reduces"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132506338}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" metabolism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132506443}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when prey not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132508074}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" found"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132508197}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132577495}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" *0.6; gives"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132578337}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resilience"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132578455}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reason"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132578500}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able biology"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132681901}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132682805}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132682846}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132682924}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSeed initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132731219}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" conditions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132732107}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132732184}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132732320}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" near equilibrium to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132797935}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoid first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132798762}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132798826}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explosion. Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132798921}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial herbivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132866611}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy to 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132867563}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".45–0.6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132867614}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (below threshold),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132867704}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132957551}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132957641}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132957708}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 110; predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123132957756}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133032163}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy 0.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133032301}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133033759}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants 700"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133033930}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then herbivores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133106786}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133107600}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" forage"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133107694}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to reproduce, slowing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133108070}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133190091}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSimplify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133190851}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133191004}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" making reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133191083}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133271588}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-dependent instead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133272348}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of instant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133272492}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- `try"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133272567}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Reproduce`: if energy >="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133335694}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold and cooldown "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133336566}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0, with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133336611}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chance `birthChance`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133336744}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (e.g., 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133404370}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".06/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133404528}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ick) else wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133404566}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133406585}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133486777}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rise above threshold;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133487611}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eventually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133487743}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133487794}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But if energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133559972}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133561095}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133561157}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133561236}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can hold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133625173}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133626084}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133626206}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133626334}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133694786}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This makes birth timing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133694930}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stochastic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133696479}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133696524}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133759369}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" once"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133759441}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" above threshold. More"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133760881}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" importantly, threshold acts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133760969}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as gate.\n- Better"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133862058}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133862238}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" costs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133862322}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133864169}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" big energy chunk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133909761}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": parent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133909817}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133909906}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133912048}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".55"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133984158}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" split, so reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133984240}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" occurs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133985700}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only when energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123133985744}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134048282}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold, and then parent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134048328}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drops well"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134049976}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134050061}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134136358}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134137212}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intake, next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134137285}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134137368}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" takes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134205816}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134205870}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134207238}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" share"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134208964}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 46"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134294585}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% + child"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134295364}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 44% = 90"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134295479}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%: parent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134295536}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drops to 46"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134369723}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134370825}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of threshold; needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134370876}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recover "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134371010}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"54%. With"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134442272}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intake ~0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134442368}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134443901}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134444011}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 gens. That's okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134527795}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! Why"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134528600}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134528688}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" births 339"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134528776}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134584959}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen? Because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134585014}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey can reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134586742}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" repeatedly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134586815}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134675662}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134675788}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12 ticks cooldown,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134675875}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regenerating "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134678625}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.54 energy by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134760866}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134761825}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134762008}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12 ticks (bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134762143}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134823737}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.38 ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134823796}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2 = 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134823885}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"76). So grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134823927}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134875825}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134875973}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" core"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134877349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" problem. Fix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134877393}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134939376}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and cooldown to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134940120}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134940225}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123134940278}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30 ticks (1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135014684}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen) and energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135015445}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intake moderate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135015577}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135015622}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135119426}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135119502}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 birth/gen,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135119559}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135121519}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high; initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135161384}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135162191}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"150 → could double"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135162254}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135162334}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen. But food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135238429}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135239383}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n- Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135239490}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" availability"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135239581}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" limits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135299674}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135300571}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 560"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135300664}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135300708}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135412622}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 bites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135412725}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135414117}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivores eat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135414158}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 121"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135443958}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 bites in gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135444822}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1 → almost all plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135444894}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumed. If bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135444999}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is smaller"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135518856}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (0.15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135519651}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and plant energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135519734}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.8, same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135519805}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135596252}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be eaten many"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135596963}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" times? Total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135597080}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant biomass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135597127}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135699619}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = bites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135700293}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×0.15"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135700339}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; 560"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135700426}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants × 0.8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135810334}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 448 energy;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135811149}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135811221}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hist 121"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135811338}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 bites = 182"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135838918}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy (with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135839834}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135839942}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Hmm plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135839994}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deaths 574"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135911942}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" indicates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135912873}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" most plants fully"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135912949}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123135913074}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136029128}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prevent over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136029988}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"grazing,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136030115}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136030177}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136065185}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" encounter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136066226}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate must be lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136066314}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", or plant reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136066389}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth stronger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136125150}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", or herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136125205}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore count lower. Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136125250}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136127280}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"150 herbivores in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136202188}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136203261}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"00 cells with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136203312}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"560 plants:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136203406}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136267305}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136268020}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136268062}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"zed; predator-free"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136268148}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136338958}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivores can eat a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136339076}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lot. Real ecosystems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136340540}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have more plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136340640}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" than herbivores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136426378}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" biomass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136426464}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136427806}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial plants to 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136427894}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 and lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136497457}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivores"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136498365}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136498412}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 90. Plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136498536}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136556973}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136557023}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136558426}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136558505}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136655073}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136655950}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regrowth base"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136656110}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" higher"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136656250}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBut if herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136695020}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivores are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136695123}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 90"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136695198}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", they may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136697020}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136760644}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Add disease"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136760704}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136762196}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"redation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136762230}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's rest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136849547}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ructure energet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136850401}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ics with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136850446}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136850522}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136940708}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\nGrid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136940778}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136942299}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"160"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136942347}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×90=14"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136996500}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",400 cells. Visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136996693}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136998155}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123136998204}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 800"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137062061}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137062239}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5%) look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137062303}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137064229}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Herbivores ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137137018}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"120 (0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137137823}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8%)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137137879}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137137947}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Predators ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137216290}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20.\nDaily"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137217075}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137217222}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137217277}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137278716}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137279681}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137279736}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137279818}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".02 energy net"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137342664}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per tick?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137342743}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Over 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137344184}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137344267}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137419293}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137419379}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy to reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137419446}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137421510}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~0.3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137522732}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; total"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137522834}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intake 0.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137524902}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen. If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137524961}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant bite = 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137551725}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".18 raw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137552662}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137552736}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.7 ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137552812}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.126"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137631154}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137631245}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", need 7 bites/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137632779}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". With 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137634396}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137703890}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5% plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137704834}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density and movement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137704959}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.1: encounters"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137705008}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137798576}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Cell pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137799372}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-through ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137799461}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"33 cells×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137799506}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137874548}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5% = 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137875318}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8 cells"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137875439}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; each plant 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137875499}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8 energy/0.18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137955576}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = 4."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137955631}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 bites. So ~8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137955671}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bites/gen available"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123137957885}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Balanced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138026108}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138026993}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Herbivore must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138027040}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138027140}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" most"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138091205}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138091967}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138092095}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to break"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138092230}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" even/g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138170265}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"row slowly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138170339}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That works."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138171981}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Set bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138172031}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.18, digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138246441}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.68"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138247227}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138247268}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138247328}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.012/tick ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138315719}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.36/gen), energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138316587}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138316679}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138316765}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138382097}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.72*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138382145}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.126"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138383738}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138383774}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": digest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138463497}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" applies"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138463746}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to bite: 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138463810}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18*0.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138465736}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=0.126;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138532633}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138533665}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 bites*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138533746}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.126=0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138533891}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"55 energy per plant."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138605735}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138606620}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138606743}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".36 cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138606788}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138670201}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.2 growth →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138670263}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138671350}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".4 bites ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138671397}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138800158}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138800210}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per gen. That gives"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138801565}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138801628}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth. Plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138814042}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consumption: 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138815017}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivores × 4."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138815100}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 bites = 528"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138818256}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bites/gen, each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138882978}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.18 ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138884046}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 95 plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138884100}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy ="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138884186}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138961122}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants/gen."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138961263}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Plant regrowth needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138962507}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123138962590}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants/gen; 800"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139038141}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants seeding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139038831}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139038960}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0042*30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139039037}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139114538}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139114598}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139114640}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139114693}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139187939}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139188908}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139189044}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139189129}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 93"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139282925}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139283505}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"190 → plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139283631}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139283675}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grow to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139316948}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139317778}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need balance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139317849}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": lower plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139317930}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth/se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139387854}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eding or more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139387984}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbivores. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139389352}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139389463}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139465222}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2100, herbivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139466023}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population can grow until"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139466122}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing balances"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139466183}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Plant reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139526850}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowth scales"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139526938}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with density and seeding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139528320}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139528397}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equilibrium at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139596771}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139597621}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139597672}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139600690}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may be dense but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139682489}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay; chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139683423}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139683494}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139686576}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139761868}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139761977}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0. Might look"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139763649}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush. Reduce max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139763728}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora to 150"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139832349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.\n\nHmm."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139833046}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139833093}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" iterate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139833221}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" empirically with a tuning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139901322}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harness."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139901418}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Key le"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139901504}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"vers:\n- herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123139901542}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bite &"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140031632}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" digest\n- herb reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140031735}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140033261}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + cooldown\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140033341}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140053851}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140054618}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140054737}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- predator efficiency"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140054775}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" & costs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140130358}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140130434}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth/se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140132027}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eding/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140132081}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"prout\n- herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140209598}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore flee"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140210408}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nEasiest first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140210501}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140210573}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140272788}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140272880}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explosion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140274325}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140274408}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140400730}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herbs 90"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140401638}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", initial energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140401799}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140401974}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".35"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140438088}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–0.55"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140438135}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140438213}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hungry"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140438291}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")\n- initial plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140486195}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140486242}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- initial predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140487804}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140487846}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140578767}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140579644}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", digest 0.66"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140579698}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- herb repro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140579832}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cooldown 30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140651847}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140651934}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140653432}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), threshold 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140653527}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".15\n- herb cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140721544}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" base as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140721630}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is (~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140721678}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.013/tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140724094}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")\n- predator:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140782183}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140783099}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.8, threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140783231}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.25, co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140783442}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown 45"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140848010}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (1.5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140848788}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens), meal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140848859}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140848949}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + prey energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140971937}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*0.4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140972782}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140972843}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.5), cost "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140972954}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.018/tick ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140995068}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.54/gen)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140995118}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140995172}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123140997203}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 kill/gen to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141067847}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141068738}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if kills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141068809}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141068956}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141163257}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen loses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141163330}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141164776}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; cannot reproduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141164820}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Need reproductive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141208548}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" success ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141208779}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 kill/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141208843}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 gens with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141210804}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141285125}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" split"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141285958}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141286061}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141286200}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator needs energy 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141353897}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".25 to birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141354768}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; gains"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141354821}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141354914}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" per kill, loses "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141438387}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.54/gen; net"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141439219}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141439324}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2 kills/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141439500}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" just to maintain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141501350}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". That's high"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141502282}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141502460}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141502539}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cost to 0.012"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141594973}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/tick (0.36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141595769}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen);"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141595888}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141595959}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141675393}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141676327}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.5) net +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141676433}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.14;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141676585}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduce every 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141751823}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141752788}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141752847}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141752958}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matters"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141823673}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Predator kills "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141824628}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141824759}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" currently;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141824810}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141887700}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey slower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141888728}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reproduction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141888873}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141888940}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count should decline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141997818}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; maybe 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141998783}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill/gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141998825}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nRather than guessing,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123141999029}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" build"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142025914}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a fast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142026029}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tuning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142027574}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142027679}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that takes over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142102434}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rides and runs 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142102523}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds ×40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142104153}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens, reports"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142104200}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stats. Use mutation of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142207682}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142207739}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".TUNING and create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142207783}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World with custom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142207848}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config. Also engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142248024}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" normalization"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142249013}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142249087}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/height; fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142249192}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWe also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142338838}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need to avoid initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142339020}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" transient"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142340787}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" blow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142340874}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-up. Maybe start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142419698}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" populations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142419832}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142420626}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142420724}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142498326}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eded\" balanced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142498401}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state:\n- plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142499869}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142499943}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", herbs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142560404}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 90, predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142561177}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142561298}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Start with herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142561349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142618403}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142619233}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142619369}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142619440}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5–0.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142697664}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), predator energy "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142697759}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.7–0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142699315}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".9.\n- Increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142699371}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142777767}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" length"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142777886}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Keep "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142777945}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30.\n\nAlso should consider"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142780029}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142831818}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142831899}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142833479}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" affects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142833527}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" immediate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142902224}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing; set "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142902282}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.3–0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142903758}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".8.\n\nLet's patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142903810}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" K and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142968423}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142969145}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142969223}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World and rer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123142969333}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"un. I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143040852}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143040954}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quick iterative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143042472}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edits via node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143042587}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143109562}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" imports engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143110350}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" code"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143110469}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143110508}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and regex"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143180282}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replaces?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143181211}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Easier: edit engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143181344}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143181455}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directly, run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143250037}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143250095}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", iterate. Values exist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143251597}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in K and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143251691}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seedInitialWorld. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143321424}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143322199}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143322304}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Flora 900, initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143322473}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Herbiv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143410697}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora 90, initialC"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143411634}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arnivora 18,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143411848}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143411911}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Flora 1800"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143454984}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- herbivore"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143455114}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143456587}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy 0.45–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143456664}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.65"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143550467}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143551382}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143551461}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–0.9\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143551590}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143600786}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143600894}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy 0.3–"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143602301}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143602431}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- herb bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143665716}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143666516}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", bite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143666600}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meta"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143666735}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.06"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143824348}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; digest 0.62"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143824417}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + meta"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143825801}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143825876}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; threshold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143873482}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143873598}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143873643}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (gene"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143875773}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143897828}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143898685}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143898751}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143898869}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" around 1.1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143978429}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":");"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143979359}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143979428}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown 30\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123143979540}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144059751}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" base"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144060638}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144060693}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144060792}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144138411}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144138459}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" base"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144139942}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cost 0.004"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144140066}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8, speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144236112}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144237046}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.0028"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144237100}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", visionCost 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144240017}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"00035, metabolism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144270491}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cost 0.001"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144270582}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2, meal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144272086}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144272164}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+0.42"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144340948}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*energy, kill range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144342097}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.8, initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144342533}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" threshold mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144342629}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144421146}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", cooldown 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144421247}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n- prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144421370}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flee multiplier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144421439}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.15;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144490153}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144490814}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144490944}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144491002}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144562626}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144562747}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" growth a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144564332}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bit lower? test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144564401}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAdd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144628264}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144629164}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator tor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144629223}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"por\":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144629330}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when no prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144705939}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", cost 0.6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144706080}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144707468}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Add in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144707514}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144804708}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Carniv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144804821}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora if !prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144804942}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144805078}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lower? fauna"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144836433}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cost called"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144837308}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after; compute cost with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144837412}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" factor. Do: `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144837508}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144951518}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144951575}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -= faunaCost(..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144951673}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") * (prey ?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144954527}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1 : 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144988268}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"62);` But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144989184}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144989314}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within vision"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123144989374}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" even if not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145102620}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eaten"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145102833}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145103038}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no prey in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145103159}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vision, torpor."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145133160}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This helps survive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145134066}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso predators"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145134273}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wandering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145134341}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145206614}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prey might star"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145206740}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ve slowly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145208381}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay.\n\nHer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145208454}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"bivore reproduction: after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145282969}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" split"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145283187}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145284693}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"46"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145284772}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145360385}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" child"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145361372}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145361563}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"44%, energy threshold "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145361670}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1.12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145431372}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → parent 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145431435}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"51; needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145432887}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.61"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145432936}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" net"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145503385}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145503452}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145503500}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bites? With"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145505334}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145619923}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145620739}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/bite, 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145620847}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bites = 0.65"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145620931}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; plus cost"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145653918}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.36"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145654888}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145654933}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145655023}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bites, about"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145713266}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145713994}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145714124}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145714238}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145789372}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145790224}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145790351}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145790462}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Birth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145862885}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145862977}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145863024}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145865051}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still possible. Food"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145935590}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-limited"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145936464}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Cooldown "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145936542}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123145936623}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146082293}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146082432}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" these settings"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146082484}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146084691}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" patching file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146110187}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Use python"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146110244}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146111663}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed? I'll edit specific"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146111779}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" constants."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146167075}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_4m2xnrfsrlt1436nxmjcsrnr","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146167138}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146168909}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146168990}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146180917}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146180995}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181048}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181122}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181179}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181253}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181319}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181384}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181544}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181655}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181835}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146181882}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146192757}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146192858}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146192951}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146193001}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146203252}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146203327}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146203417}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146205606}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146205715}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146205859}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146205907}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146206021}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146214380}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146214437}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146214588}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146214651}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146264121}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146264216}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146265877}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146265979}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146266100}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146266294}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146266379}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146266431}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146283244}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146284148}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146284243}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146284325}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146289915}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146290068}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146290165}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146290307}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146296518}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146296616}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146296704}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146296787}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146304175}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146304310}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146304494}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146304672}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146319747}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146320721}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146320778}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146320904}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146321057}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146321154}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146321238}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146331029}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146342918}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146342967}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146344509}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146344580}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146355529}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146355613}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146357239}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146357376}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146357500}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146357641}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146357734}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146357783}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146376432}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146376482}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146378175}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146378232}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146414914}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146414964}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146415007}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146416409}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146416491}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146416571}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146416622}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"560"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146416751}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146429795}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146429891}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146430971}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146431021}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146448084}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146448130}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146448176}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146449387}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146449490}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146449577}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146449689}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146449740}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146461627}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146461720}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146462517}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146462569}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"150"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146488091}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146488145}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146488194}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146489022}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146489900}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146489984}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146490094}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146490136}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146493753}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"90"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146493894}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146494501}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146494564}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146513090}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146513242}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146513291}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146514081}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146514177}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146514252}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146514297}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"24"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146516891}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146527751}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"initial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146528104}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146528212}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146528262}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146546139}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146546181}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146546842}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146546890}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"18"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146548155}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146548242}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146548351}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146548404}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146560490}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146560544}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146561127}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146561202}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"210"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146578158}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146578531}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146578644}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146579953}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146580044}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146580089}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146580222}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146580299}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"180"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146598493}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146598903}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146598947}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146599033}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146610394}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146610503}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146611063}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146611119}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146628732}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146628786}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146628943}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146629705}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146630432}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146630517}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146630598}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146630687}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146642825}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146642871}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146643409}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146643454}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146664491}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146664854}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"18"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146664948}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146665026}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146667056}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146667207}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146667344}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146667398}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146682770}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Meta"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146682863}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146683412}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146683506}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146691637}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146692008}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146692069}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146692166}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146693984}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146694133}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146694178}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146694273}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Meta"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146719223}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146719273}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146719321}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146720160}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146734317}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"06"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146734366}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146734495}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146735147}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146735207}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146735397}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Dig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146735483}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146735546}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146752736}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146753295}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146753345}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146754150}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"70"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146769145}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146769286}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146769953}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146770009}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Dig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146770770}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146770873}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146770934}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146771012}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146808033}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146808438}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"62"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146808487}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146809453}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146809565}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146809684}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146809836}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Dig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146809906}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146824279}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Meta"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146824332}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146824861}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146824916}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146843695}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146843913}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146844119}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146844319}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146844782}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146845088}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Dig"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146845180}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146845369}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Meta"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146864754}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146864866}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146865431}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146865565}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146877667}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146877766}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146878382}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146879114}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146879208}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146879447}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Me"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146879552}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146879760}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146904569}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146904673}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146904757}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146905088}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"26"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146923132}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146923261}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146923781}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146923983}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Me"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146924161}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146924388}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146924489}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146924662}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146953037}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146953178}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146953323}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146953629}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146962647}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146962693}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146963289}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Me"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146963409}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146964425}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146964515}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146964607}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123146964657}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147000016}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147000066}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"56"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147000863}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147000960}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147006446}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147006502}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Me"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147006954}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147007010}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147007096}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147008499}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147008554}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147008641}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147018883}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147018929}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147019380}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147019475}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147049137}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147049191}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147049753}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147049830}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147050839}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147050935}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147050975}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147051105}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147066761}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"92"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147066813}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147067496}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147067604}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147084349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147084631}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147084686}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147084851}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147086215}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147086353}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147086409}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147086502}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147103055}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147103407}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147103507}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147103556}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147122648}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Base"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147122699}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147123194}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147123251}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147124294}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147124393}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147124435}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"006"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147124575}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147144464}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147144510}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147145234}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147145286}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Base"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147156250}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147156441}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147156547}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147156609}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147158223}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147158271}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"004"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147158332}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147158433}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147193693}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147193957}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147194002}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147194109}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147195569}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147195782}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147195853}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147197143}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"000"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147212083}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"55"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147212529}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147212596}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147213509}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147213755}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147213904}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147213960}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147214108}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147265696}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"000"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147265770}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147266225}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147266291}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147267195}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"met"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147267257}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"abolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147267368}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147268870}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147268962}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147269065}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147269126}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147271148}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"001"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147271244}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147271320}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147271383}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"met"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147271489}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"abolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147285136}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147285225}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147285797}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147285875}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147286618}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147286729}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"001"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147286779}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147286889}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147304164}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147304350}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147304414}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147305143}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147320613}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147320686}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147321241}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147321292}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147342548}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147342594}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147343023}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147343645}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147343739}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147343833}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147343888}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147343980}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147362550}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147363133}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147363190}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147363294}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147381512}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147381568}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147382049}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147382130}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lee"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147415967}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147416047}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147416665}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147416757}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147439952}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147440005}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"85"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147440048}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"':'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147440124}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147440182}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147440230}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147440287}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lee"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147440353}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147455726}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147456285}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147456340}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147456463}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147475202}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"90"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147475259}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147475696}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147475802}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147476818}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147476947}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147477027}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147477122}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" repl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147506611}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".items"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147506691}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"():\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147507194}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147507259}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147511728}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147511837}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147512431}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147512545}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147513407}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147513500}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147513591}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147513637}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147529233}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147529308}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147529372}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147529913}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147564272}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147564330}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147564805}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147564946}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147581584}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147581769}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147581821}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147582788}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" make"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147597971}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147598344}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147598395}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147598503}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147616330}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147616405}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147616477}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147617076}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147630281}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147630644}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147630729}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147630869}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147632397}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147632515}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147632592}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147634009}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147650263}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147650348}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147650683}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147650810}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147664449}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147664492}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147665094}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147665196}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147666164}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147666257}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147666318}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147666385}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147683259}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"62"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147683314}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147683868}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147683934}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147703654}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147703798}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"86"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147703876}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147704416}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147715161}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147715494}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147715588}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147715628}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" make"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147733321}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147733646}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147733726}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147733903}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147735300}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147735478}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147735530}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147735640}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147750490}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147750639}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147751060}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147751157}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147762059}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147762316}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147762376}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147762474}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147764067}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147764196}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147764338}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147764407}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147781885}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147781939}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147781992}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147782590}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147799989}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147800033}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147800596}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147800641}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147815855}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"42"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147815911}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147816356}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147816409}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147817388}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147817475}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"66"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147817521}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147817662}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147835037}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147835096}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147835562}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147835661}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147848526}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147848578}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147849034}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" make"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147849168}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147850349}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147850421}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147850598}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147850649}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147869639}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147869691}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147869741}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147870352}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147881897}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147881950}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147882000}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147882621}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147883180}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147883308}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147883374}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147884866}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147900714}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147900762}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147900800}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147901473}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147930626}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147930688}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147931253}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147931307}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147931410}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147931551}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147931589}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147931694}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"78"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147955180}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147955236}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147955289}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147955984}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147959936}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147960197}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147960288}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147960334}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147961903}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"genes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147961953}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147962082}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" make"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147962144}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147976659}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147976771}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147976831}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123147976926}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148007112}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148007439}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148007536}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148008523}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148008626}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148008729}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148008848}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148008922}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148021736}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148022057}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148022114}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148023106}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148029752}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148029980}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148030028}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148030127}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148031700}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148031780}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148031900}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148031951}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148064294}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148064372}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148064452}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148064979}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"70"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148071942}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148071999}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148072529}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148073224}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148073269}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"92"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148074245}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148074302}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148074419}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148082295}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148082343}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148082810}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148082865}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148101899}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148101947}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148101991}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"awn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148102615}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148122094}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148122190}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"orld"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148122265}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148122849}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148142439}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148142500}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148142558}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148143128}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" make"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148143235}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148143348}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148143418}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148145345}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148160894}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148161196}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148161264}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148161389}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148176569}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148176622}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148177141}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148177180}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148178242}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148178292}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"15"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148178379}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148178471}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148198105}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148198155}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148198615}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148198701}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148219193}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148219248}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148219284}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148219903}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148220520}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148220573}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148220748}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148220809}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"15"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148242639}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148242707}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" continue"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148243160}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148243220}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148259727}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148259978}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148260058}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148260183}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148282501}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"awn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148282583}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Plant"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148282700}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148283333}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"orld"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148283512}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148283658}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148283726}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148285478}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148293955}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148294027}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" make"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148294459}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148294566}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148311775}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148311834}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148311869}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148312499}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148313149}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148313194}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148313333}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148313417}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148325538}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148325585}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148325644}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148326263}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"15"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148341553}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148341923}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148341991}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148343008}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148343165}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148343224}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148343309}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148343468}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148362612}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"28"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148362900}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148363038}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148363085}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148377863}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148378180}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"92"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148378280}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148378377}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" continue"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148379808}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148379921}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148379970}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148380069}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148423191}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"por"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148423243}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148423299}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148423943}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ivores"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148424525}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" when"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148424633}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148424697}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" prey"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148424767}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148429565}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sight"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148429673}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148430127}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148430172}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148450239}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148450289}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148450846}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148450890}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148451854}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148451946}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148451991}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148452058}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fauna"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148463621}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148463704}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148463772}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148464356}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148483984}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148484064}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148484120}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148484649}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148503457}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148503755}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" moved"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148503813}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148503897}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148512300}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148512597}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148512655}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148513669}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148529918}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148529976}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148530529}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fauna"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148530569}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148531497}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148531625}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148531702}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148531795}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148559571}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148559643}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148559998}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148560064}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148569334}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" moved"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148569382}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148569513}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148569560}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148570254}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148570393}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148570560}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148570656}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148597846}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148597911}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148597956}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148598485}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148609737}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148609777}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"62"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148610236}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148610333}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148611520}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148611628}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148611708}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148611799}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148623671}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148623733}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148624256}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148624365}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148639641}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148639732}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148640268}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148640315}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ched"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148640445}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148640495}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148642336}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148642389}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148664412}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148664460}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148664525}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148665395}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148681446}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148681510}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148681882}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148683385}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148702935}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148703009}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148703071}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148703659}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148723813}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148723880}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148724382}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148724494}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148736617}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148736664}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148736707}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148737295}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148753899}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148753950}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148753992}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148754550}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Patch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148897216}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ecology"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148897262}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" constants"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148897800}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148897849}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ret"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148927794}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148928180}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148928231}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1557,"ts_us":1793123148929114}}

data: {"id":"f2a7493dc1f4026933925ad2a893a17c","object":"chat.completion.chunk","created":1793123115,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":111615,"completion_tokens":5160,"total_tokens":116775,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":106496,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":4318,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1557,"ts_us":1793123148940268}}

data: [DONE]

