data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671431610}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671431711}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" teammates are using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671431795}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shots/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671495041}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too. Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671495096}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Now screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671495394}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671495649}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mock preview at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671567283}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440x900."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671567350}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1hxjpmhcgykuvwm830uuhvrr","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671567467}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671567694}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671567761}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671567888}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671568065}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671568136}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671572134}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671572315}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671572412}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671572567}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671586982}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671587087}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671587432}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671587819}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671606531}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671606811}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671606865}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671607300}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671622699}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671622816}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671622888}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671623016}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671640547}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671640647}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671640839}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671640889}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671641350}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671641448}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671641495}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671641792}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671681962}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671682057}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671682169}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671682356}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671683442}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671683557}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671683669}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671683879}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671697765}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671697877}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671697928}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671698149}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671718060}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671718138}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671718303}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671718351}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671729157}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671729244}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671729350}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671729614}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671743993}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671744086}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671744146}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671744344}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671744566}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671744676}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671744909}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671744992}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671762668}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671762831}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671762945}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671763069}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Applications"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671788583}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671788797}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671788861}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671789010}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671791065}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671791197}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671791338}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671791394}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671800100}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671800314}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671800389}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671800606}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671817314}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671817391}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671817455}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671817560}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671819178}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671819302}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671819354}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"disable"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671819411}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671836965}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pu"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671837099}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671837264}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671837357}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671846894}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671847031}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671847100}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671847255}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671865452}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-data"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671865578}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671865711}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671865762}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671881670}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671881742}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671881828}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671881960}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671882356}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671882427}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671882467}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hide"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671882560}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671896578}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671896685}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bars"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671896827}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671896870}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"force"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671911948}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671912107}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671912167}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-scale"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671912351}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-factor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671912861}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671913004}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671913050}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671913287}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671931005}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-size"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671931367}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671931417}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123671931485}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672065310}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672065362}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672065420}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672083472}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672083555}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672083622}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672083707}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672083775}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672083824}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672083868}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672124821}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672124876}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"01"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672235639}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672235729}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672235801}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"virtual"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672235865}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672235918}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672235970}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"udget"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672236033}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672236115}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672236320}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672236363}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672236407}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672324820}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672324869}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672324913}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672324963}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"WD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672325084}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672325134}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672325217}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672325295}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672325346}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672326192}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672326239}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672326289}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672326352}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672326409}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672326466}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672326519}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672326575}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672327163}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672327242}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672327305}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672327415}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672327474}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672327508}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672327551}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672328375}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672328421}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672328479}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672328528}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672328572}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672328627}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672329347}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"01"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672329394}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672329457}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672329733}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672329776}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672329838}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672329901}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672330883}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672330967}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672331029}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672331085}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672331127}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mock"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672331174}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672331241}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672331303}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672331904}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672331987}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672332063}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672332123}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672332168}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672332233}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2324,"ts_us":1793123672332287}}

data: {"id":"f999a1ed2b691462c8a0390c2867ec88","object":"chat.completion.chunk","created":1793123671,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":181148,"completion_tokens":250,"total_tokens":181398,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":180352,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":22,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2324,"ts_us":1793123672332978}}

data: [DONE]

