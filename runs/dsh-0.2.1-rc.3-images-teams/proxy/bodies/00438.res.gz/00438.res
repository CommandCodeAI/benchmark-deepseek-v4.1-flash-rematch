data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368635742}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Third"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368686960}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" command running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368687024}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in background (rule end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368687066}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368760514}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") — maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368760564}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stepping 12 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368760596}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368760625}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368819532}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" triggers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368819592}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368819685}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Should be quick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368819724}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368869045}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the harness hangs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368869096}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368869136}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stepping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368870884}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368941760}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368941796}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event firing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368941822}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126368941846}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369012918}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ers etc. Or CLI waits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369012958}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let me wait for job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369012984}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Meanwhile read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369013009}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the detail images"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369086588}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369086641}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_2fgvclvcurhondtywqzu5awi","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369086841}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369086904}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369086937}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369086974}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087002}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087029}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087057}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087144}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087173}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087632}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087659}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087694}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087722}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369087748}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369090350}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369090391}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369090423}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369090458}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369103459}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369103651}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369103686}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369103714}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369104453}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369104600}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369104646}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369104682}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369130234}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369130275}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369130308}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369130342}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369147082}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369147277}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369147311}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369147339}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369147848}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369147965}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369148003}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369148032}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369164864}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369164899}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369164926}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369164956}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369188730}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369188772}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369188803}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369189476}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369189741}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369189776}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369189803}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369189831}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369218661}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369218699}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369220207}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369220235}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369227218}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369227271}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369227309}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369227338}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ool"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369227998}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tip"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369228036}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369228079}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ocus"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369228116}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369317711}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369317765}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48323,"ts_us":1793126369319372}}

data: {"id":"eade75c3ae48be5e3939be085f97a7b3","object":"chat.completion.chunk","created":1793126368,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":358474,"completion_tokens":156,"total_tokens":358630,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":356608,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":63,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":48323,"ts_us":1793126369324622}}

data: [DONE]

