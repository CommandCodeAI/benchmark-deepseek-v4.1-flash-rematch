data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453340042}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453423265}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output got truncated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453423310}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at top; ref history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453423373}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows gen2 flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453493026}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 777, gen3 plague"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453493095}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453493147}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453493233}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like the same as live?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453567783}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453567864}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453567938}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 16 though"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453568014}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453697057}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": ref events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453697168}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": only plague"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453697227}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen3 then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453697356}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought at gen30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453774179}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — interval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453774244}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config? `ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453774298}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".e"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453774353}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"vents` count"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453827836}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" probably small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453827898}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453827947}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453828011}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" have interval="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453872737}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3? Let me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453872829}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" see"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453872908}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier part of output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453872980}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (truncated)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453951553}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453951630}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453951688}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows refHist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126453951742}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454034515}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454034601}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": liveConfig"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454034663}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454034721}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"refConfig differences"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454112314}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and first ref"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454112391}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454112443}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454112497}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454187209}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454187259}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454187305}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2,3 counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454187342}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454263488}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ash) and live hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454263559}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454263615}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run and print"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454263672}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377269}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377331}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" summary only."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377407}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_fkie2namfyxzr37gcn35bcne","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377461}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377530}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377574}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377638}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377702}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377820}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454377904}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454378074}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454378147}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454378210}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454378282}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454378341}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454378389}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454385587}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454385645}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454385690}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454385742}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454402003}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454402062}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454402112}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454402154}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454431025}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454431112}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454431225}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454431304}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454442054}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454442175}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454442255}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454442345}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454442829}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454442924}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454443108}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454443214}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454463508}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454463605}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454463686}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454463766}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454480439}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454480547}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454480632}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454480715}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454482559}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454482669}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454482764}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454482875}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454498681}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454498820}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454498922}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454499016}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454544651}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454544745}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454544842}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454544933}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454590866}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454590971}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454591057}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454591138}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454591218}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454591298}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454591385}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454591469}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454596294}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454596386}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454596470}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"urity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454596554}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454598292}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454598394}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454598486}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454598571}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454601388}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454601483}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454601568}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454601673}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454617285}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454617386}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454617468}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454617544}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454640369}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454640475}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454640560}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454640646}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454659317}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454659407}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454659486}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454659566}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454674929}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454675063}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454675191}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454675281}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454692665}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454692760}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454692838}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454692938}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454693367}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454693454}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454693530}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454693603}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454713748}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454713817}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454713902}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454713962}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454737588}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454737662}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454737741}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454737822}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454752253}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454752351}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454752461}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454752536}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454770632}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454770684}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454770762}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454770835}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454820854}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454820917}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" big"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454821218}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" body"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454821293}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454821355}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" compact"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454821397}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454821469}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454821532}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454835582}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454835659}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454836343}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454836414}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" onward"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454864823}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" by"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454864916}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rebuilding"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454864989}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454865054}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454904873}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454904929}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454904992}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454905178}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454925050}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454925113}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454925165}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454925289}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454925670}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454925998}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454926059}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454926126}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454950673}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454950744}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454950826}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454952421}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454983317}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"end"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454983370}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454983510}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454983578}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454983650}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454983703}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454983904}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454983951}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454984031}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454984103}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454984156}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126454984229}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455013940}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455014023}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455014093}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455014155}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455024983}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" await"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455025042}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455025111}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455025157}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"val"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455026072}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455026129}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455026188}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455026345}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455050459}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455050511}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455050553}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455050612}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455059049}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455059103}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".__"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455059694}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455059745}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455080093}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455080176}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455080406}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"__,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455080475}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455081891}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455081938}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455081982}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455082029}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455096398}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455096443}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455096497}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455097039}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENG"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455111821}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455111890}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455112009}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455112073}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455112539}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455112604}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455112671}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455112741}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455132166}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455132233}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455132301}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455132387}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455155620}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455155696}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455155756}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455155795}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".parse"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455156096}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455156176}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455156258}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455156695}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455172695}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455172750}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455172819}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455172934}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455202675}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455202753}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455202818}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455202975}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455229506}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455229576}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455229632}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455229662}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".parse"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455229946}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455230004}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455230041}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455230090}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455248845}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455249290}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455249357}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455249418}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455266621}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455266724}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455266811}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455266997}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455283200}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455283251}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455284091}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455284175}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455302014}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455302085}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455302150}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455302221}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455324905}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455324958}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455324998}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455325042}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455343062}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455343182}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455343296}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455343374}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455343623}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455343694}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455343749}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455343791}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455363298}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455363406}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455363598}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455363659}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455377041}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455377135}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455377206}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455377270}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455377417}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455377477}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455377601}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455377680}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455400897}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455400990}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455401064}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455401121}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455425548}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mutation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455425618}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455425673}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cfg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455425790}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455425958}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455426009}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455426048}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455426093}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455460778}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455460847}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455460900}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455461149}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455461253}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455461323}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455461428}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455461493}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503160}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503258}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503336}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503401}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503462}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503511}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503595}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503664}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455503755}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455504777}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455504828}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455504928}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573082}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573157}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573280}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573349}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573410}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573469}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573543}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573639}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573710}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573746}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573896}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573940}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455573990}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574066}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574136}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574188}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574262}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574337}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574406}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574475}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ast"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574542}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rophes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574611}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574794}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455574885}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" live"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455593325}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455593920}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455593987}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455594039}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455610113}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455610192}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455610259}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455610319}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455610484}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" counts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455610558}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455610616}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455610678}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455644445}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455644502}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455644547}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455644602}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455660608}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455660705}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455660783}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455660967}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455670646}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455670738}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455670802}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455670852}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455685352}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455685439}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455686436}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455686505}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455686569}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455686636}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455686685}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455686768}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455703672}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455703723}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455703781}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455703866}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455729376}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455729474}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455732215}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455732264}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455755449}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455755535}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455755611}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455756983}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455758184}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455758247}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455758308}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455758369}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455800271}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" typeof"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455800336}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455800398}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455800460}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455824994}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455825073}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455825138}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455825200}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455836896}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455836968}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455837024}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" [],\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455837069}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455869147}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" };\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455869210}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455869258}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455869324}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cur"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455878905}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455879035}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455879115}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455879166}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455892947}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455893020}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455893107}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455893147}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455893495}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455893576}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455893647}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455893712}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455920220}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455920296}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455920367}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455920437}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455941440}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455941504}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455941552}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455941621}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455953003}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455953065}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455953127}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455953164}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455953710}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455953760}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455954158}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455954220}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455967808}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455967893}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455967960}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126455968004}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010079}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010137}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010202}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010274}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010320}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010367}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010509}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010580}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010635}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010678}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456010723}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456013109}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456026666}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456026764}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456026907}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456026986}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456093882}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456093942}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094104}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094153}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094228}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094281}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094423}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094473}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094544}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094646}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094710}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094773}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" flora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094919}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456094989}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456095043}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456095095}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456104085}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456104140}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456104183}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456104292}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456119898}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456119948}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456119990}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456120477}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456139147}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456139220}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456139282}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456139334}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456139539}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456139627}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456139697}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" car"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456139971}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ni"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456159790}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456159872}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456159938}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456159980}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456180510}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456180586}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456180647}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456181112}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456181197}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456181261}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456181325}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456182047}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456199056}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456199111}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456199375}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456199457}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456219748}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456219820}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456219881}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456219942}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456220733}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456220817}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456220884}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456220948}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456272944}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456273023}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456273080}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456273139}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456290997}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456291121}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456291204}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456291265}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456291675}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456291754}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456291863}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456291914}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456310796}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456310868}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456310929}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456311517}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" target"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456327866}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456328078}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456328157}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456328209}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456365815}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456365881}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456365927}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456365998}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456385650}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456385756}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456385834}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456385903}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456404202}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456404282}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456404344}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456404798}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456427103}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"live"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456427162}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456427793}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456427865}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456427938}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456427979}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456428032}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456428073}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456444071}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456444124}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456444164}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456444212}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456465970}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456466053}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456466119}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456466190}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456466414}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456466542}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456466627}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456466693}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" return"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456527730}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456527836}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456527921}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456528020}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456528708}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456528824}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\"\\\"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456528918}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456528977}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456529721}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456529810}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456529888}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456529994}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456538454}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456538553}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456538657}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456538812}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456539794}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[end"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456540014}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456540201}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456540301}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":]\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456578087}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456578184}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456578264}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456578343}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456579630}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456579719}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456579984}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456580063}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456595638}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456595727}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456596490}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456596582}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456621649}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456621752}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456621833}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456621911}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456622332}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456622412}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456622493}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456622597}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456640814}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456640918}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"500"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456641016}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456641096}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456653208}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456653310}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456653644}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456653738}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456654194}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456654285}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456654366}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456654444}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456682012}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456682112}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456682190}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456682264}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456696570}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456696654}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"slice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456696730}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456696805}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456697447}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456697550}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456697653}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"400"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456697746}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456713465}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456713564}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456713644}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456713718}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456734961}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456735063}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456735145}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456735347}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456735570}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456735660}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456735796}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456736009}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456749151}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456749219}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456749271}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456749321}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456852595}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bg"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456852699}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456852779}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"urity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456852851}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853125}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853219}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853296}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853364}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853410}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853507}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853594}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853661}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853716}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"60"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853786}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456853880}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456854059}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456854144}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456854217}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456854288}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456854352}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456860634}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Compact"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456860698}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" debug"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456860813}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456860900}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" live"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456935207}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456935612}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reference"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456935686}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" divergence"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456935752}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456981721}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22877,"ts_us":1793126456981797}}

data: {"id":"d91f00bf5b3460e8f95572416a7971fe","object":"chat.completion.chunk","created":1793126453,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":334096,"completion_tokens":816,"total_tokens":334912,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":331904,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":130,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":22877,"ts_us":1793126456981906}}

data: [DONE]

