data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542375401}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542436581}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542436654}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nicely. Great.\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542436807}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542503142}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542503188}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ize soon."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542503231}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542503468}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542523398}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542523766}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/atel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542523811}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ier complete"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542524154}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tasks +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542567038}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verifier final."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542567270}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542567490}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_agent to wait for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542567547}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes; meanwhile maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542622693}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run own"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542622750}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542622986}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542623355}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542722068}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542722225}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542722432}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edits. Let's see"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542722676}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542759509}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier/controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542759923}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change still ongoing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542760047}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; they said"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542760396}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542832504}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"still refining detail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542832742}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542833133}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542833333}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542905802}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"23:30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542906182}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542906232}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest. Chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542906399}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright updated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542971257}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 23:35"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542971345}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542971398}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fixed. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126542971890}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait for messages"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543042228}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's wait_"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543042842}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"agent timeout 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543042918}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s, then re-list."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543042980}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_2w4ak43229700jnw4d0grfw6","type":"function","function":{"name":"wait_agent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543098131}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543098242}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543098614}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543098894}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543123809}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543123981}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543124029}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543124430}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543195417}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543195565}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":48190,"ts_us":1793126543195621}}

data: {"id":"0698ae9ad37ab0441b84cb353c54a0a1","object":"chat.completion.chunk","created":1793126542,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":336747,"completion_tokens":154,"total_tokens":336901,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":335488,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":112,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":48190,"ts_us":1793126543206125}}

data: [DONE]

