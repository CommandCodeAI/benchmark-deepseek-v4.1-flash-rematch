data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642525242}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642598680}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642598778}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" see: src/engine.js mtime 23"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642598842}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":09, seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642683328}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642683525}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1; preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642683594}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembled "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642683698}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"23:05 with seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642765603}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1859. Lead is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642765644}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" *rot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642765964}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ating the default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642766008}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"*??"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642865314}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Actually more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642865394}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely: Lead is running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642865450}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a seed-search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642866373}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642943381}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modifies D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642943448}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed temporarily"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642943521}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to find a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124642943583}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643002117}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"good\" seed (a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643002196}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643002258}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" whose"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643002311}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643080674}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40-gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643080773}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run looks nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643080820}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643080865}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643147254}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots), and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643147303}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hasn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643147483}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t reverted to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643147532}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1977"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643213329}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643213379}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643213461}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643213541}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explicitly requires"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643282521}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default 1977!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643283106}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643283178}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643283226}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`round"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643345816}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1/index.html` is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643346141}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now REAL ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643346184}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"313KB, "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643346223}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"23:10)**"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643427313}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643427380}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead assembled!"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643427430}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643427466}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643477790}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" official full suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643477841}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nImportant: check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643477877}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DEFAULTS seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643477940}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643554080}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643554129}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643554165}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643554200}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1977 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643618118}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contract fail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643618177}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643618219}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643618281}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643714348}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able and run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643714421}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suites. Also note the B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643714479}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"19"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643714526}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parity mismatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643796724}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" root"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643796775}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cause: stale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643796811}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643796883}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs updated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643866495}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine — resolved"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643866592}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by testing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643866657}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliverable."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643866699}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643933568}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643933619}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DEFA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643933678}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ULTS.se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124643933753}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed currently "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644010339}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 — must"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644010389}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flag to Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644010821}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644010895}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644081468}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" non"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644081554}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-1977 default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644081678}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644081741}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" round"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644163965}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644164020}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644164194}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644164252}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644213720}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_nk1il4c1zsac3g99azswkxa8","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644213822}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644213895}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644213961}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644213997}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644214055}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644214126}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644214200}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644214266}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644214333}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644214874}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644214949}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644215002}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644215079}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644215144}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644215234}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644215283}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644215346}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644215400}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644215443}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644223914}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644223994}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224056}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224104}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224251}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224341}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224424}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224501}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224636}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224683}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224738}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644224785}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644239071}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644239152}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644239210}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644239373}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644239444}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644239510}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644239569}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644239627}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644265756}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644265890}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644265979}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644266053}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644285646}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644285716}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644285786}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644285844}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644305228}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644305307}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644305514}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644305590}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644308614}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644308701}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644308846}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644308915}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644322284}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644322346}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644322395}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644322449}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644345676}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644345785}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644345849}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644345909}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644362590}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644362686}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644362735}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644362810}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644363649}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644363705}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644363760}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644363819}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644378591}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644378676}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644378744}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644378822}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644399694}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644399789}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644399908}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644399987}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644400234}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644400320}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644400393}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644400461}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644409046}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644409117}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644409178}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644409244}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644428103}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644428179}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644428246}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644428413}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644466385}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644466448}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644466490}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644466553}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644470472}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644470521}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644470563}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644470625}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644472062}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644472141}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644472207}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644472260}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644481936}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644481990}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644482033}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644482073}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644482202}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644482338}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644482394}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" latest"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644482444}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644519880}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644519941}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644520008}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644520108}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644520326}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644520387}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644520636}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644520690}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644552123}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644552180}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644552244}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644552293}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644564582}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644564628}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644564681}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644564765}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" official"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644581479}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" deliver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644581561}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"able"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644581624}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644581668}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644594812}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" freshness"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644594889}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644594941}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19306,"ts_us":1793124644594992}}

data: {"id":"ba647dfada0538fb59f7b2754362783c","object":"chat.completion.chunk","created":1793124642,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":256154,"completion_tokens":392,"total_tokens":256546,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":255488,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":222,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":19306,"ts_us":1793124644670951}}

data: [DONE]

