data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184679415}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184720704}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ensity slightly improved"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184720780}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; plants more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184720872}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible. Still field has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184800451}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sparse gaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184800522}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184800581}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that's natural grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184800757}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good enough"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184875098}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184875235}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" higher"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184875289}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184875717}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recovery"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184966115}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lush. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184966209}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" composition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184966481}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is strong.\n\nCould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126184966558}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consider making"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185048257}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the initial **c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185048367}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"amera moment"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185048405}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185049896}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185126300}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185126352}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185126397}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", auto-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185126447}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" required; starts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185205220}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185205361}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185205401}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185205679}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"900 plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185285325}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; screenshot 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185285495}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5s at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185285744}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6 after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185285808}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grazing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185361744}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine.\n\nOne issue:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185361834}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185362037}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"plate\" label /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185362103}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185473002}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" area"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185473059}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185473099}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185473361}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-left glass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185551347}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185551531}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no annotation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185551609}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay.\n\nAt"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185551838}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier hasn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185601702}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t finished; their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185601935}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest changes improved"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185602169}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185602209}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels etc. Wait for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185679440}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" completion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185679560}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow, visual design could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185679603}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" benefit from a stronger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185679867}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" signature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185773590}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" element. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185773702}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Generation Rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185774014}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185774064}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", wax seals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185842608}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; the field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185842710}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" journal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185842751}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" concept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185843034}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is coherent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185925545}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185925673}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" think design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185925718}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" meets brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185925763}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed decide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185999801}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" whether"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185999874}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to adjust UI of \"seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126185999962}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" to show "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186000102}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186075035}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186075124}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n\nPotential issue: the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186075444}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **left/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186075526}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"right margin** at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186159320}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440: sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186159393}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nearly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186159452}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fills"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186159581}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screen with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186262444}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small desk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186262625}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" border"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186262663}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; nice.\n\nPotential"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186263148}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186326457}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 fixed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186326549}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186326631}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verify with latest modules"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186326676}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186487970}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280 check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186488051}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186488187}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186488350}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_podtxugydwarx4ayao4cu13m","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186495591}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186495721}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186495769}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186496141}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186496830}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186496952}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186497000}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186497470}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186509763}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186509856}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186510098}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186510154}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186521333}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186521504}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186521566}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186521642}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186535300}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186535367}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186535425}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186535541}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186554505}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186554583}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186554641}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186554724}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186575030}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186575156}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186575203}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186575480}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186591087}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186591216}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186591265}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186591440}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186666008}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186666105}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186666253}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186666298}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186667749}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186667816}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186667880}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186668003}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186669368}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186669460}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186669509}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186670017}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186674543}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186674606}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186674662}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186674756}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186695249}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186695334}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186695450}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186695536}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186696060}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186696205}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186696265}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186697098}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186774551}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186774613}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186774659}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186774785}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186777174}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186777254}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186777406}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186777461}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186777911}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186777967}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186778030}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186778151}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186784734}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186784831}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186784883}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186784965}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186791276}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186791319}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186791415}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186791485}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186791762}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186791818}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186791866}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186792620}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186793469}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186793650}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186793734}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186793850}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186816082}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186816132}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186816254}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186816403}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186816893}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186817001}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186817137}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186817201}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186830599}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186830850}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186830920}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186831924}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186852535}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186852592}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186852623}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186852915}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186853298}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186853345}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186853414}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186853527}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186875238}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186875293}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186875350}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186876023}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186891088}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186891224}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186891259}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186891405}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186911080}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186911196}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186911249}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186911328}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186956101}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186956178}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186956265}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186956389}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186956774}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186956822}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186956863}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186957457}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186973976}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186974036}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186974113}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186974216}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186988974}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186989092}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186989218}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126186989279}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187009649}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187009732}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187009798}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187009918}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187011344}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187011467}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187011557}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187011637}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187033215}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187033262}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187033463}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187033519}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187048085}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187048149}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187048215}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187048379}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187078460}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187078570}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187078642}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187079075}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187100691}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187100787}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187100898}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187100970}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187209228}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187209309}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187209373}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187209419}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187230218}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187230293}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187230328}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187230568}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187230873}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187231044}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187231094}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187231140}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187257976}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187258042}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187258083}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187258190}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187262510}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187262560}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187262595}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187262783}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187263275}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187263328}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187263479}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187263515}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187264867}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187264930}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187264997}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187265128}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187276167}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187276216}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187276259}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".search"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187276317}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187276363}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187276419}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187276475}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187276571}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187277123}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187277188}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187277339}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187277425}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187279866}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187279989}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187280047}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187280181}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187280301}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187280345}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187281052}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187281898}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187285746}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187285924}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187286169}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187286254}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".group"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187292440}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187292654}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187292748}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187292950}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187293521}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187293615}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187293692}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187293858}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187312175}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187312291}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187312386}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187312574}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187323618}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187323766}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187323874}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187324105}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187324257}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scroll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187324388}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187324495}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"canvas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187324563}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187397815}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"finished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187397871}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187397976}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187398022}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Hidden"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187417168}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187417239}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187417320}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187417683}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187417726}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"canvas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187417795}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187417896}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187417969}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187423153}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"canvas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187423224}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'])\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187423364}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187423433}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187433116}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187433233}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187433310}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187433403}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187459735}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187459781}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187459845}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187460637}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187460703}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187460767}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187460814}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187460859}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187479132}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187479182}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187479298}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187479601}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187593437}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187593517}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187593645}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":44196,"ts_us":1793126187593730}}

data: {"id":"832eb9cc0729a1ba0ece0d7f583b51fb","object":"chat.completion.chunk","created":1793126184,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":326954,"completion_tokens":521,"total_tokens":327475,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":325760,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":222,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":44196,"ts_us":1793126187615057}}

data: [DONE]

