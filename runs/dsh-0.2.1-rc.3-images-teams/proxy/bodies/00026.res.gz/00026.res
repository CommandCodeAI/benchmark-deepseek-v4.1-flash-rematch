data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725540158}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725634239}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me claim task-2 first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725634286}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725634334}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_i3w6c1yswgfpeu2iv03q2h9v","type":"function","function":{"name":"team_task_get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725634397}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725634445}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725634494}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725634544}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725691629}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725691687}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725691736}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725691786}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725691885}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725691948}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725691991}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725692088}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1289,"ts_us":1793122725716846}}

data: {"id":"f83e0ee1bd06105d0b377ea975800825","object":"chat.completion.chunk","created":1793122725,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":24680,"completion_tokens":50,"total_tokens":24730,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":22528,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":8,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1289,"ts_us":1793122725717316}}

data: [DONE]

