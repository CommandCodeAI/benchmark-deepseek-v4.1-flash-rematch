data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866720639}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866757784}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866757813}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out still shows `197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866757865}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7` ·"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866844655}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed example"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866844703}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; should change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866844810}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866845334}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901` for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866903258}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consistency. Fix. Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866903317}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866903476}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest page at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125866903497}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867024638}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1440 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867024688}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867082509}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modules; perhaps at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867082554}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier still editing."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867082593}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867082622}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a bit for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867082647}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867082677}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier/ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867127323}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"artwright to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867127352}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867203496}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tasks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867203517}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" complete. Meanwhile, verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867203540}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our own"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867203557}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867261393}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" integration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867261418}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867279572}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regressions. Run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867279593}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assemble preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867279695}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and 1280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867279717}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867409773}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867409944}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_w2sltscqjmgp5402r4290ehs","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867410227}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867410515}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867410545}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867410568}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867410588}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867411487}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867411507}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867411526}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867412118}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867412382}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867443332}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867443466}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867443529}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867443763}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867446298}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867446442}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867446571}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867446704}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867461300}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867461355}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867461558}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867461576}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867461759}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867461866}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867462148}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867462169}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867477988}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867478110}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867478352}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867478375}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867496128}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867496294}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867496314}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867496332}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867515176}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867515326}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867515388}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867515534}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867530341}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867530365}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867530382}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867530461}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867550734}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867550869}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867550896}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867550954}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867578590}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867578615}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867578825}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867578852}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867579706}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867579729}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867579749}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867579929}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867606649}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867606912}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867606935}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867606971}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867608722}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867608881}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867608902}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"DES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867609146}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IGN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867609178}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867609284}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867609369}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867609400}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867624734}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867624915}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867624956}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867624989}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867647865}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867648015}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867648038}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867648072}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867661849}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867661885}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867661932}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867662009}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867706080}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867706117}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867706194}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867706270}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ·"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867706292}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867706423}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867706443}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867706609}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867727926}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" `"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867727952}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867728010}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867728104}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867728128}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ·"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867728320}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867728342}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867728420}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867734201}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867734278}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867734349}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867734472}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867767683}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867767777}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867767861}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867767997}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867768242}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867768283}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867768661}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"brief"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867768678}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867779851}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867780060}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867780088}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867780156}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867804366}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867804412}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867804524}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assemble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867804597}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867805026}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867805046}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867805092}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867805164}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867847389}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867847412}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867847475}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867847507}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867847894}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867847953}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867848095}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"quiet"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867848116}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867883476}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867883569}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867883641}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867883665}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867903280}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867903339}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867903408}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867903492}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867903799}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867903851}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867903985}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867904116}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867917348}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867917370}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867917448}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867917503}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867937055}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867937207}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867937235}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867937316}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867937399}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867937420}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867937617}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867937643}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867956784}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867956804}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867956866}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867957029}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867973752}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867973980}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867974004}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867974021}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867974394}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867974443}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867974562}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125867974681}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868007763}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868007829}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868007980}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868008032}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868008288}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868008311}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868008443}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868008547}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868036384}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868036413}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868037399}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868037456}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868049117}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868049145}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868049164}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868049184}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868049588}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868049610}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868049637}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868049697}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868076725}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868076808}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868076903}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868076924}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868080883}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868080949}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868081010}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868081090}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868099735}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868099762}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868100054}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868100074}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868122798}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868122979}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868123010}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868123030}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868157019}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868157062}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868157117}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868157363}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"350"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868175986}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868176073}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868176103}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868176298}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868225350}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868225402}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868225556}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868225586}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868227850}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868227882}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868227918}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868227938}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868230570}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868230611}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868230827}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868230855}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868232119}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868232146}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868232166}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868232185}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868251723}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868251875}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868251936}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868252087}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868270625}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868270926}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868270944}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868270961}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868294278}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868294313}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868294394}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868294418}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868294975}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868295028}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868295261}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868295294}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868332351}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868332376}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868332728}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868332760}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868369075}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868369213}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868369317}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868369428}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868369727}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868369841}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868369907}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868369948}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868370498}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868370627}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868370775}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868370870}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868380629}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868380667}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868380704}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868380736}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868381783}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868381836}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868381878}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868381914}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".search"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868384721}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868384803}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868384922}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868385023}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868399603}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868399651}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868399684}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"S"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868399719}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868419986}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868420042}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868420398}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868420447}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868421484}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868421578}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868421750}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"try"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868421808}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868444935}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868445017}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868445211}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"json"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868445237}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".load"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868463044}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868463075}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868463105}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".group"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868463174}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868463738}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868463773}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"))\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868463822}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868463950}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868483128}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868483153}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868483172}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868483221}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868499146}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868499171}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868499534}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868499611}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868513671}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ['"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868513716}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868513782}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868513843}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868533057}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868533130}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868533211}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868533245}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868546842}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868546870}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scroll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868546919}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868546962}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"finished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868565782}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868565812}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868565871}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Hidden"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868565951}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868604223}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"event"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868604248}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868604271}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"als"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868604326}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868643449}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"led"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868643475}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ger"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868643625}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868643664}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"resources"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868653455}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"']"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868653495}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"})\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868653525}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868653597}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868673831}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"canvas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868673867}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868673941}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868673964}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868689001}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868689041}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"canvas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868689115}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'))\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868689217}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"except"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868703393}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Exception"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868703418}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868703479}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868703511}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868722344}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868722386}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868722503}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868722526}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868723499}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868723530}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868723586}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"180"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868723631}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868739287}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868739383}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868739414}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868739463}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868758708}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868758733}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868758836}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868758863}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868759480}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868759631}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868759655}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868759673}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868776974}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868776995}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868777068}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868777087}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868802363}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868802392}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868802456}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868802481}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868814190}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868814229}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868814277}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868814366}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868832957}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868833071}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868833205}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868833226}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868852655}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868852741}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868852764}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868852938}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868870743}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868870767}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868870785}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868870803}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868871272}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868872189}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868872214}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868872270}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868884854}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868884878}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868884943}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868885036}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868945259}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868945285}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868945303}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868945351}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868945674}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868945840}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868945861}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868946060}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868946674}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868946692}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868946906}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868946958}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868953174}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868953202}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868953256}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868953284}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868960670}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868960701}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868960765}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868960847}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868990229}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868990262}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868990317}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868990369}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868999631}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868999681}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868999823}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125868999882}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869042990}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869043153}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869043175}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869043237}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869076261}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869076295}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869076316}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869076384}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869095081}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869095105}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869095126}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869095143}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869130718}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869130742}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869130809}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869131194}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869157098}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869157130}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869157174}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869157223}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869181803}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869181902}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869182166}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869182204}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869182240}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869182264}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869182285}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869182486}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869190562}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869190736}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869190758}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869190969}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869207119}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869207142}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869207174}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869207207}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869207290}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869207315}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869207404}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869207425}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869249923}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869250084}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869250106}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869250195}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869250692}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869250779}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869250802}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scroll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869250940}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869265646}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869265671}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869265691}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869265737}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Hidden"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869281177}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869281202}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869281220}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869281377}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chart"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869300929}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869301102}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ixels"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869301124}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869301187}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869322940}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869322969}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869323047}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869323071}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869345276}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869345302}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869345321}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869345382}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869346633}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869346829}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869346858}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869346909}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869386947}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869386971}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869386992}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869387074}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869415054}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869415079}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869415157}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869415189}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869465616}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869465643}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869465694}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869465791}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869466197}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"emble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869466366}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" latest"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869466399}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869466512}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869478859}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869478981}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869479009}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869479179}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" layouts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869561507}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869561530}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":39049,"ts_us":1793125869561554}}

data: {"id":"41d93d3fa3fd02f2dbff1bf213d81edf","object":"chat.completion.chunk","created":1793125866,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":320003,"completion_tokens":633,"total_tokens":320636,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":318848,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":85,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":39049,"ts_us":1793125869568953}}

data: [DONE]

