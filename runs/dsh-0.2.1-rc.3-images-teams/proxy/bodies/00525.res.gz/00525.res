data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708323147}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xvejba0hdedx5nmwg473ezgg","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708369324}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708369392}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708369518}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708383347}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708383404}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708385559}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708385639}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708404391}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708404446}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708404487}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708404531}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708418313}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708418384}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708418460}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708418528}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708449563}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708449628}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708449829}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708449875}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708468909}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708468986}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708469038}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708469104}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708469946}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708470054}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708470228}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708470271}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708487440}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708487615}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708487749}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708487821}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708503875}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708503925}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708503986}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708504136}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708504365}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708504410}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708504632}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708504685}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708521949}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708522027}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708522142}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708522257}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708539417}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708539464}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708539532}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708539603}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708542187}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708542236}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708542294}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708542345}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708566672}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708566908}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708566957}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708568986}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708571078}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708571145}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708571193}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708573145}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708634561}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708634618}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26688,"ts_us":1793127708634658}}

data: {"id":"8a21823212ca9470b9dfbdde5ea2aba0","object":"chat.completion.chunk","created":1793127708,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":369150,"completion_tokens":90,"total_tokens":369240,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":368256,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":26688,"ts_us":1793127708642242}}

data: [DONE]

