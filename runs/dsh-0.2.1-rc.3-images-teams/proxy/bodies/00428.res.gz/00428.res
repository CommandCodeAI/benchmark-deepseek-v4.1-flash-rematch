data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213707941}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1hyw92l70g0ekmkuhhcb8yg6","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213748453}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213748544}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213748595}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213767214}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213767299}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213767383}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213767465}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213783181}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213783254}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213783316}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213783446}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213801490}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213801569}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213801638}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213801710}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213818737}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213818829}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213818896}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213818959}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213845316}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213845374}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213845414}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213845471}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213867136}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213867220}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213867281}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213867370}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213867620}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213867681}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213867724}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213867803}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213936853}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213936910}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213937101}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213937162}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213938332}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213938381}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213938439}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213938493}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213943703}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213943779}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213943856}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213943944}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213961075}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213961126}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213961205}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213961281}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213999726}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213999812}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213999888}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126213999966}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214021398}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214021464}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214021724}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214021792}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214038892}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214038954}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214039008}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214039070}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214039846}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214039908}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214040428}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214040492}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214059825}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214059884}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214059942}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214060050}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214076041}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214076136}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214076206}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214076271}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214077182}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214077252}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214077294}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214077863}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214102135}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214102215}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214102286}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214102348}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214113152}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214113212}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214113262}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214113304}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214152611}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214152718}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214152793}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214152880}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214177134}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214177196}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214177241}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214177294}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214194004}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assembly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214194217}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214194277}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214194334}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214278807}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23218,"ts_us":1793126214278883}}

data: {"id":"3cc1925b3228b665071c5916e8b4aeb0","object":"chat.completion.chunk","created":1793126213,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":326507,"completion_tokens":132,"total_tokens":326639,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":326272,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":23218,"ts_us":1793126214278950}}

data: [DONE]

