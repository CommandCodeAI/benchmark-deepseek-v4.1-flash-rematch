data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720314194}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ptq21g3hr1vmgvmbf6gqiql2","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720384637}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720384700}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720384762}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720392635}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720392715}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720392844}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720392938}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720402020}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720402099}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720402250}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720402360}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"raits"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720422916}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720422987}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720423041}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720423123}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720510525}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3151,"ts_us":1793123720510576}}

data: {"id":"a70de7281bb2116750f7b33684e8a710","object":"chat.completion.chunk","created":1793123720,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":185128,"completion_tokens":45,"total_tokens":185173,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":183424,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3151,"ts_us":1793123720510647}}

data: [DONE]

