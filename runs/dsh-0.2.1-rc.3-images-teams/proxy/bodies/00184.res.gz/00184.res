data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889085168}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"S"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889138736}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"creenshots from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889138876}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verifier already exist."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889138998}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's look at ours"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889225173}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889226169}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_sidogk94tjqof483vv4wz0ni","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889226238}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889226465}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889226571}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889226653}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889226705}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889235340}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889235423}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889235540}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889235584}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889235645}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889246677}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889247579}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889247684}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889247798}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889261709}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889262608}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889262652}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889262794}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889278425}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889298420}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889298468}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889298579}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889309179}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889309300}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889309407}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889309587}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889309664}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889309745}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889309811}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889322784}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889322924}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889323031}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889323126}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889323256}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889323380}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889323471}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889328726}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889328807}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889371847}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889372903}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889372961}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889373069}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889373179}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889373249}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889373359}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889373432}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889409223}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889409359}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889409567}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889409645}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889409754}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889415209}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889415268}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889415395}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889415473}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"01"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889415517}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889415563}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889415610}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2859,"ts_us":1793123889468129}}

data: {"id":"a062a292fd668a2d4a4fad60415d036a","object":"chat.completion.chunk","created":1793123888,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":213892,"completion_tokens":102,"total_tokens":213994,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":212992,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":15,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2859,"ts_us":1793123889468261}}

data: [DONE]

