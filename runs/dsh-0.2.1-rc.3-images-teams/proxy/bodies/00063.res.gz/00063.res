data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123095948963}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096028035}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine is real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096028087}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Note `gly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096028106}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ph` values"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096226302}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are 'fl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096226333}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ora', 'fa"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096226368}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"una', 'pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096226412}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator' — I'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096276003}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" normalize"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096276026}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Colors"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096276042}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096278269}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soft available"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096330822}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nImportant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096330842}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096330917}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" entry 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096330936}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recorded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096418324}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at creation (before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096418348}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" any gen)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096418365}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096418700}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me check create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096475593}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"World calls record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096475619}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"History."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096475786}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096475825}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runGeneration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096532665}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" increments"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096532793}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096532853}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" firing events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096533547}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / recording"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096593369}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096593403}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" order"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096593426}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me look at run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096593473}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation/runHeadless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096654756}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and event order"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096654792}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096654824}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be sure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096654841}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" about x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096708804}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-axis"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096708834}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and event gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096708851}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096708888}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_twir9z2rs1y6v9tb31z76w0g","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096708936}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096708975}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709017}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709065}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709102}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709178}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709205}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709230}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709250}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709272}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709291}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096709309}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096715159}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096715185}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096715205}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096715288}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096733402}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096733427}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096733445}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096733506}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096735772}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096735803}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096735982}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096736024}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096750347}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096750373}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" step"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096750786}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096750813}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096781452}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096781539}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" conclude"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096781601}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096782386}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096828405}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"History"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096828430}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096828592}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096828617}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096829599}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096829622}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096829640}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096829661}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096830812}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096830837}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096830856}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096831019}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096834992}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096835017}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096835037}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096835056}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096854405}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096854429}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096854449}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096854469}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096854626}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096854660}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096855008}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096855031}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096871805}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096871834}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096871853}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096871873}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096888717}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096888757}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096888789}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096889126}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096889792}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096889821}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096889896}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096889917}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096906761}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096906964}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096906987}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096907012}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096927305}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096927347}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096927411}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096927560}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096928238}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096928262}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096928730}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096928759}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096946080}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096946109}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096946131}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096946150}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096976014}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096976041}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096976060}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096976502}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096976955}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096977000}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096977039}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123096977383}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097007683}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097007742}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097007769}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097007790}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097025031}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097025059}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097025316}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097025340}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097049549}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097049572}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097049592}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097050022}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Generation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097074353}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097074381}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" timing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097074406}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097074806}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1966,"ts_us":1793123097133227}}

data: {"id":"b04731857ec01d35182da7878fdb97aa","object":"chat.completion.chunk","created":1793123095,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":66109,"completion_tokens":239,"total_tokens":66348,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":63104,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":95,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1966,"ts_us":1793123097133270}}

data: [DONE]

