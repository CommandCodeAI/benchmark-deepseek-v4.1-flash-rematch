data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541045059}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541077596}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine replacement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541077867}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failed because `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541077961}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'const"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541136735}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed = 1859;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541136805}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'` not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541136933}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" present? It failed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541137216}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before writing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541208889}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541209263}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541209318}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changed. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541209666}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541276101}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no seed →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541276427}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541276550}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541276800}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s grep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541360987}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541361055}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_d11lxhpv9rls6tz49no33t7v","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541361305}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541361868}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541361932}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541361988}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541362049}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541362112}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541363701}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541363820}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541364112}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541364358}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541383426}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541383667}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541383812}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541384002}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541388309}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541388466}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541388570}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541388787}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541408395}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541408454}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541408612}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541408678}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541408793}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541408861}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541408979}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541409053}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541422362}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541422460}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541422623}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541422748}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541441705}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541441820}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541441987}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541442053}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541460690}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541460783}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541460995}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541461052}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541478419}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541478528}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541478645}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541478803}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541506224}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541506294}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541506399}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541506498}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541514646}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541514813}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541515873}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541515983}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541516138}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541516284}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541516384}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541516444}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541537297}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541537402}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541537535}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541537590}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541553148}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541553277}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541553450}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541553602}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541579826}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541579996}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541580087}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541580305}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541580593}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541580672}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541581108}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541581212}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541588405}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541588492}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541588603}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541588687}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541632035}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541632157}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541632495}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541632597}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541748423}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541748523}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541748676}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Loc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541748782}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541767969}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541768077}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541768235}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" strings"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541768331}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541807166}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":24857,"ts_us":1793124541807376}}

data: {"id":"82bf62b0cea2adbbfb5bdc71487c1bf3","object":"chat.completion.chunk","created":1793124540,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":263399,"completion_tokens":168,"total_tokens":263567,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":260992,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":45,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":24857,"ts_us":1793124541807483}}

data: [DONE]

