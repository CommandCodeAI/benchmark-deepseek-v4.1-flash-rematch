data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832425333}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832495654}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stub"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832495731}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then write."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832495789}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_zx9i96qqk5adqdmkargnk0nl","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832510260}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832510332}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832510491}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832510532}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832524685}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832524751}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832524827}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832525073}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832545161}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832545261}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832545491}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832545548}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832546294}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832546358}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832546752}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832546799}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832560814}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832560885}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832560962}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832561156}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832578586}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832578685}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832578763}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832578971}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832596544}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832596727}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832596793}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832597248}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832611702}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832611986}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832612031}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832612262}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832612574}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832612799}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832612849}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832612915}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832634148}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832634278}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832634327}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832634420}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832646238}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832646330}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832646383}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832646619}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832646856}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832646910}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832647020}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832647068}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832663148}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832663258}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832663408}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832663467}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832688631}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832688811}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832688900}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3876,"ts_us":1793123832689045}}

data: {"id":"0294ee7e66cab157acb7c31792f1bf7f","object":"chat.completion.chunk","created":1793123832,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":202815,"completion_tokens":88,"total_tokens":202903,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":188672,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":5,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3876,"ts_us":1793123832754363}}

data: [DONE]

