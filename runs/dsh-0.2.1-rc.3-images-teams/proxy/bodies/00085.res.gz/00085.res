data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123322806277}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123322855511}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failed partway:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123322855826}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123322856585}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wrote only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123322925691}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123322926070}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123322926702}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replacements succeeded?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123322926817}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The script asserts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323018305}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323018567}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" writing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323019215}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; it failed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323019356}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at last replacement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323106782}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and never"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323106912}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wrote. So engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323107014}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unchanged. Need check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323198504}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exact string for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323198612}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" child cooldown."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323198671}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323199610}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323199665}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `cooldown: K.reproCooldown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323240292}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", dead: false`?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323286954}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me grep. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323287028}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323287153}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" energy"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323379136}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323379285}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replacements"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323379421}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may be beyond"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323379562}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323384317}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exception occurred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323384473}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before `open(p,'w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323385264}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"')`, no changes. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323385333}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323499381}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"un with correct string."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323499660}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me inspect lines."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323499964}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_adeze5xvezoh6cynfgvzjwwc","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323500058}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323501937}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323502033}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323502115}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323502201}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323509910}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323510391}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323510475}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323511909}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323527905}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323528293}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323528357}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323529592}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323545200}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323545744}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323545809}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323547024}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323559863}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323560311}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323560474}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323560516}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323562479}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323562582}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323562653}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323562809}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323678632}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323678684}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323679316}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323679384}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323706577}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323706887}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323706971}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323707018}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323714402}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323714818}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323714873}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323716147}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323725205}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323725707}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323725754}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323725859}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323739441}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323739723}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323739797}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323739938}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323745746}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323746155}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323746258}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323746385}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323755440}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323755897}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323755981}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323756115}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323758023}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323758124}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323758169}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323758266}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323758401}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323762805}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323762852}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323762900}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323764648}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323765004}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323765115}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323765161}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323767126}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323767308}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323767450}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323767507}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323770300}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323770604}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323770650}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323770752}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323784813}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323784918}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323784999}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323786010}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"orpor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323817345}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323817525}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323817609}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323818438}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323841302}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323841647}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Share"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323841728}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323841866}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323859788}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323860035}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323860081}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323861509}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elines"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323871522}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323871848}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323872018}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323872074}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323894931}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323895428}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323895507}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323895654}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323931051}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323931566}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323931615}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323931689}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323933587}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323933711}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323933815}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323933870}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323939720}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323940131}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323940228}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323940321}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" lines"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323957507}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323957561}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" patch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323957627}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" targets"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123323957720}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123324045833}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1939,"ts_us":1793123324045961}}

data: {"id":"ee9cf67b73ffeb2b1859fcdfe2f684f1","object":"chat.completion.chunk","created":1793123322,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":143965,"completion_tokens":252,"total_tokens":144217,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":138752,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":102,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1939,"ts_us":1793123324046044}}

data: [DONE]

