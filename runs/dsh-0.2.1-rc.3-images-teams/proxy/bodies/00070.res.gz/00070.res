data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123163849419}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123163901494}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ators still extinct by ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123163901615}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"gen 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123163901852}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" everywhere"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123163958588}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123163958763}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"y boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123163958833}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123163959224}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164052202}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"300 then crash;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164052261}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" predator boom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164052410}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164052466}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164094046}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-60 then extinct."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164094109}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need drastically"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164094221}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change predator dynamics"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164094279}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164189175}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s trace seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164189236}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1977 again to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164189292}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" see predator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164189363}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numbers/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164238960}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"energy/k"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164239242}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ills."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164239345}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_wui2l63x4iv44w0f78766hkg","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164239943}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164255662}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164255869}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164256236}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164256310}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164273805}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164273973}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164274034}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164274416}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164288226}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164288491}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164288547}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164288817}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164310635}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164310864}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164310932}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164311065}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164324415}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164324513}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164324631}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164324888}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164385435}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164385525}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164385571}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164385966}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164386131}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164386203}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387044}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387103}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387147}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387201}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387240}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387300}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387331}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387780}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387836}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164387883}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164404401}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164404483}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164404584}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164404638}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164417291}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164417343}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164417431}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164417521}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164418395}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164418486}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164418533}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164418708}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164433389}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164433441}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164433511}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164433942}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164454238}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164454327}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164454438}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164454506}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164485667}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"race"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164485820}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164485923}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164485976}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164500436}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164500527}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164500606}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164500840}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164500901}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164501126}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164501210}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164501364}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164564579}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164564829}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164564918}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164565096}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164571838}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164571950}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164572059}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Trace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164572255}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tuned"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164588191}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" simulation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164588606}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" first"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164588686}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164588759}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164614512}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164614662}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164614807}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2433,"ts_us":1793123164614901}}

data: {"id":"c3476038533291c66165deb5c23e7016","object":"chat.completion.chunk","created":1793123163,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":118301,"completion_tokens":173,"total_tokens":118474,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":111488,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":53,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2433,"ts_us":1793123164663372}}

data: [DONE]

