data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305376878}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305376966}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" third screenshot command"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305377007}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is still running (event eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305431156}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305431279}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stepping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305431561}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305431646}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"... loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305478071}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305478127}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be slow?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305478219}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Actually `V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305478341}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".actions.st"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305547470}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"epGen` runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305547924}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305547994}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305548275}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305701204}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 steps fine. Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305701287}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the harness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305701433}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" got stuck due to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305701583}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" audit?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305741737}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Or the chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305741814}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305741940}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" didn't exit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305742017}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305800776}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still running after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305800830}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60s."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305800922}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me check job output."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305801126}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_toa2trx178ebld9rtcnyvl95","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305801215}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305801385}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305801460}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305801506}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305802472}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305802656}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305802859}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305803055}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305821773}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305821828}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305821906}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305822127}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305833300}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305833448}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305833546}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305833613}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305834184}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305834383}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305834526}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305834701}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305881082}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305881249}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305881415}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305881474}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305887424}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305887496}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305887646}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305887878}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305922924}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305923060}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305923153}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305923247}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305936052}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305936117}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305936282}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305936635}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305949873}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305950011}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305950127}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305950293}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305971341}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305971419}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305971627}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305971696}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305982376}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305982440}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305982527}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305982627}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305982907}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305983008}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305983126}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125305983200}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306008365}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306008496}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306008576}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306008656}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306021674}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306021847}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306022029}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306022076}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306040159}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306040215}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306040326}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306040372}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306040799}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306040957}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306041106}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306041152}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306054796}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306055040}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306055099}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"jobs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306055200}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306071550}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306071614}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" aux"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306071707}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306071845}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306087995}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306088292}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306088341}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306088437}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306123148}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306123238}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306123434}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306123547}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306155672}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306155735}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306155783}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306155824}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306156088}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306156250}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306156332}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306156491}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306174141}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306174317}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306174394}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" screens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306174570}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306206632}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306206732}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306206899}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" processes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306206960}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306278191}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":8108,"ts_us":1793125306278328}}

data: {"id":"4c0ea7c4fe288bc873846242c5cbbe8a","object":"chat.completion.chunk","created":1793125305,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":322020,"completion_tokens":207,"total_tokens":322227,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":319616,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":71,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":8108,"ts_us":1793125306278412}}

data: [DONE]

