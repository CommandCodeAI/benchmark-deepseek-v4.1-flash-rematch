data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368048936}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_i4rmt5c1xxseqgwde8n3q66h","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368066365}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368066466}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368066545}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368085927}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368086009}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368086488}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368086543}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368113138}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368113222}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368113290}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368113353}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368126258}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368126311}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368126357}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368126455}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368148621}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368148722}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368148781}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368148948}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368207654}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368207732}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368207790}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368207842}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368208165}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368208218}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368208288}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368208890}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368213977}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368214024}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368214065}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368214104}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368241534}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368241604}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368241696}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368241766}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368242442}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368242525}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368242584}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368242651}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368255675}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368255745}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368256689}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368256737}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368305229}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368305299}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368305355}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368305393}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368307920}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368307969}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368308009}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368308121}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368308490}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368308664}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368308718}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368308790}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368325987}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368326062}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368326117}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368326159}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368353007}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368353064}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368353114}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368353178}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368365040}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368365112}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368365199}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368365290}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"..."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368389999}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368390107}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368390189}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368390382}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368425889}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368425960}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"330"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368426024}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368426095}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"470"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368426169}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368426241}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368426303}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368426368}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368453401}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368453519}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368453596}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368453661}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368473080}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368473268}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368473351}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368473416}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368484768}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368484858}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368484945}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" boot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368485051}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" URL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368502068}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" params"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368502153}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368502215}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368502270}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" loop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368621067}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368621119}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10668,"ts_us":1793124368621160}}

data: {"id":"0a333e2e05a785ba20a37c5f22fd80ad","object":"chat.completion.chunk","created":1793124367,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":235131,"completion_tokens":133,"total_tokens":235264,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":234368,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":10668,"ts_us":1793124368626929}}

data: [DONE]

