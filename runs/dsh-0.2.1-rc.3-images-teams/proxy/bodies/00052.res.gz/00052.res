data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020008879}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"There"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020084173}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s a bug: B18"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020084220}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020084544}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is async inside check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020147000}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" which"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020147049}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" awaits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020147112}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fn — good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020147161}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But I used"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020222715}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `await"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020222781}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" snapshotDel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020222834}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"iverable` inside non"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020222886}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-async arrow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020281982}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020282067}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wrote `async () =>"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020282133}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` — yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020283481}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020371714}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18 has `async"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020371781}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" () =>`?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020371831}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me check..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020371868}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I wrote:\n\n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020514198}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"```\nawait rec.check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020514254}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(\n    'B18',\n   "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020514303}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" '..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020514357}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"',\n    ()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020654106}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" => {\n      const"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020654191}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" snap = await snapshotDeliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020654273}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able(...)\n```\n\nThat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020654377}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s a syntax"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020709672}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" error. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020709775}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `async ()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020709839}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" =>`. Let me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020709908}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020770368}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running node --"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020770439}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020770582}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_9g9hfc9cbvti0o3wkh3hhavt","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020770660}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020770712}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020770797}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020770875}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020770938}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020771134}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020771198}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020771669}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020771741}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020771807}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020771907}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020771979}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772044}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772118}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772182}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772237}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772320}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772388}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772474}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772540}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772601}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772658}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772798}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772882}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020772959}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773023}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773098}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773160}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773218}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773292}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773333}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773398}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773469}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773533}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773716}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773793}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773853}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773911}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020773986}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774041}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774110}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774166}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774228}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774287}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774336}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774407}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774545}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774602}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020774667}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020805999}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020806091}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020806162}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020806232}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020822369}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020822444}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020822513}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020822556}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020822767}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020822910}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020822978}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020823077}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020836714}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020836811}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020836928}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020837017}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020850504}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020850701}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020850787}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020850829}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020856354}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020856418}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020856554}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020856637}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020872100}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020872171}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020872241}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020872336}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020882009}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020882087}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020882157}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020882243}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020902384}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020902461}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020902523}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020902587}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020920701}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020920785}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020920864}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020920925}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020938117}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020938198}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Syntax"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020938262}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020938701}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020959130}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020959330}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020959402}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020959746}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" against"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020971850}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" stub"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020971959}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020972028}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1333,"ts_us":1793123020972091}}

data: {"id":"80b90380fc512baa04bd80f2341a2caf","object":"chat.completion.chunk","created":1793123019,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":52051,"completion_tokens":246,"total_tokens":52297,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":45440,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":110,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1333,"ts_us":1793123021031941}}

data: [DONE]

