data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584823898}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_q29ne8vukjsg0fac3qo6o8yh","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584824017}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584824068}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584846634}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584846719}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584846787}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584846852}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584859724}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584859993}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584860086}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584860304}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584876658}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584876837}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584876931}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584877031}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584890366}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584890552}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584890622}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584890739}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584892024}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584892170}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584892323}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584892487}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584908398}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584908520}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584908589}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584908851}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584931553}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584931739}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584931820}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584932002}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584934171}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584934294}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584934367}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584934558}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584944922}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584945043}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584945249}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584945435}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584964830}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584964964}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584965090}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584965145}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584982757}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584983040}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584983160}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125584983214}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585001178}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585001336}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585001491}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585001559}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585017864}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585018021}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585018243}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585018312}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585019615}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585019719}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585019774}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585019881}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585156198}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585156275}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585156496}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":13504,"ts_us":1793125585172168}}

data: {"id":"029c58b1ff479f9955fd48c974ca8b43","object":"chat.completion.chunk","created":1793125584,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":341424,"completion_tokens":90,"total_tokens":341514,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":340608,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":13504,"ts_us":1793125585172423}}

data: [DONE]

