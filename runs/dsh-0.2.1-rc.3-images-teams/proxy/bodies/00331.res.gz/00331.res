data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094082786}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Interesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094164839}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094164882}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P rawKeyDown for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094165236}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Enter does NOT trigger native"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094227144}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" button click in head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094227205}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less Chrome (native activation requires"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094229608}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyDown with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094229679}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text '\\"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094293701}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"r' maybe,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094293771}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094293920}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" treats"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094293970}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rawKeyDown differently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094360169}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Space"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094360236}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094360307}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". So my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094360338}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Enter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094537639}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dispatch is incomplete"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094537713}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": need `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094537827}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Input.dispatchKeyEvent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094537870}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` with type 'keyDown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094617744}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094617805}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and text: '\\r'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094617850}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for Enter to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094619855}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" trigger default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094678182}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" action"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094678236}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me adjust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094678277}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094678328}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"dp KEY"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094737312}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_DEFS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094737367}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Enter: {"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094737406}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"code:'Enter', v"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094737462}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k:13, text:'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094801616}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\\r'}. Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094801672}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" key() will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094801706}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" send type"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094801752}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 'keyDown' with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094925993}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text '\\"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094926039}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"r' → click"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094926081}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125094926116}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Test again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095016158}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSimilarly other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095016212}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" defaults"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095016251}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095016335}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need text. Let me patch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095086270}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and retest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095086324}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095086536}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_059s7ufwpseilv7zlq5yhz82","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095086593}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095086675}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095086751}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095086817}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095086933}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087003}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087085}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087129}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087192}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087242}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087293}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087349}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087412}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087460}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087504}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087542}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087630}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087674}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087718}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087759}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095087797}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095093533}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095093581}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095093620}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095093677}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095118562}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095118625}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095118671}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095118731}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095119295}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095119368}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095119426}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095119474}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095127585}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095127634}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095127674}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095127742}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095141930}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095141979}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095142057}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095142111}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095178403}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095178462}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095178512}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095178566}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095186436}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095186499}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095186663}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095186770}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095186857}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095186919}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095186973}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095187031}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095202021}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095202098}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095202160}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095202228}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095245678}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095245761}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095245813}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095245868}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/lib"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095248470}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095248527}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095248568}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095248616}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095248989}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095249046}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095249127}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095249211}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095250999}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095251050}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095251159}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095251226}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095251708}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095251889}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095251937}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095251987}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095267281}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095267332}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095267372}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095267416}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095284597}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095284656}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095284724}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095284803}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095284892}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095284936}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095285013}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095285056}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095302704}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095302810}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095302930}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095302979}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095325585}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095325662}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095325724}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095325790}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095327178}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095327248}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095327337}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095327384}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095336889}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095336941}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095336989}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095337375}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095364510}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095364608}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095364693}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095364760}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095367211}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095367259}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095367333}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095367399}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095374480}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095374532}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095375270}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095375339}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095386325}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095386405}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095386495}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095386561}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095387090}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095387163}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095387224}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095387313}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095411745}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095411799}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095411900}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095411969}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095420009}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095420095}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/key"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095420171}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095420209}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095420527}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095420593}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095420647}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095421480}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095444738}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095444789}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095444842}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095444909}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095458094}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095458158}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095458244}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095458296}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095469858}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095469934}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095469987}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095470037}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095488663}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095488718}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095488786}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Enter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095488868}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dispatch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095536554}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" with"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095536640}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CR"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095536708}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" text"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095536758}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095557148}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ret"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095557206}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"est"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095557264}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095557333}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16244,"ts_us":1793125095630987}}

data: {"id":"e31f28557e731e497bffe0ab69b7a8ad","object":"chat.completion.chunk","created":1793125093,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":287708,"completion_tokens":336,"total_tokens":288044,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":286848,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":139,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":16244,"ts_us":1793125095631150}}

data: [DONE]

