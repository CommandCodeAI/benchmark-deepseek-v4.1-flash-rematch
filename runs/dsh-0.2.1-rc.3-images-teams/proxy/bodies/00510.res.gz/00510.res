data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331372853}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331505015}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliverable assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331505067}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with sha f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331505287}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"820f20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331554693}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"a. My preview6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331554762}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run is ongoing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331554831}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" against preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331554895}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331603011}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331603075}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" useful)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331603120}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but now run the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331603162}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" FINAL official"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331665900}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matrix against `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331665949}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"round 1/index.html`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331665995}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" exactly."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331666038}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" To"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331755172}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" avoid CPU contention from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331755233}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331755285}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser preview6 run ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331755324}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331819547}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" affect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331819597}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timing/r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331819629}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331819674}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331888900}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots), I should kill the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331888966}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview6 run before starting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331889167}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" official. Check job list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331889210}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331953276}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" processes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331953385}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": the background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331953448}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" command started with `&"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127331953515}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` in a bash call;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332004015}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332004083}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" don't have job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332004129}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" id since started as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332004177}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332055647}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background, not tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332055694}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332056561}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" job. I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332056605}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can kill via pkill -"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332144149}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"f \"VER"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332144319}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IFY_P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332144354}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AGE="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332144413}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"shots/verify-integration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332212134}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6\" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332212205}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332212266}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowser.test.mjs\". Care"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332212297}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ful not to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332294798}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kill final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332294845}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run. Use pkill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332294935}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332295000}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"f \"verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332355068}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-integration6\" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332355120}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"the env"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332355182}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" var appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332355246}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in shell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332409934}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" command? p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332410019}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"kill matches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332410070}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process command"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332410123}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines: node verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332500536}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/browser.test.mjs with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332500583}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" env not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332500625}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in cmdline). Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332500692}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" env"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332563006}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not visible in ps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332563082}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cmdline. The node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332563129}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process cmdline is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332563155}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"node verify/browser.test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332623938}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mjs\". Any"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332624045}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" other browser.test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332624119}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mjs running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332624176}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Only preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332693827}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6. Kill it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332693866}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via pkill -f \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332693973}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"node verify/browser.test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332694013}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mjs\" — safe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332759726}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now (no official"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332759776}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332759834}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332759904}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Then verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332821456}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332821504}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome leftovers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332821552}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332821609}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"they'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332912974}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be killed by test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332913052}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" process? if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332913112}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" killed abruptly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332913150}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", Chrome may linger; find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332983853}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chrome-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332984058}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"verify tmp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332984102}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" profiles processes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127332984138}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and kill)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333061993}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Use pkill -f \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333062054}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"chrome-verify\" maybe;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333062102}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome cmd"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333062158}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line includes --user-data-d"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333125470}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ir=/tmp/ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333125515}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rome-verify-*"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333125577}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nThen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333125627}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333183925}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1. Sn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333183998}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"apshot &"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333184100}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record sha —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333184191}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333242724}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite snap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333242810}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"shots itself; static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333242875}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333242942}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333313908}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333314012}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"18 snapshots. To ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333314088}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333314140}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" three test the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333397284}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" SAME sha"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333397331}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", I'll snapshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333397383}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" manually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333397433}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333451069}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333451117}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"napshots/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333451157}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inal-f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333451200}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"820f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333510331}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20a.html and run suites"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333510408}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" against that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333510487}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? But deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333510557}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333568372}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" required artifact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333568436}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; instructions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333568529}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" say test as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333568589}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333653746}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with snapshot if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333653789}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333653851}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Since src"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333653899}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frozen and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333715007}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead won"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333715051}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t touch unless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333715097}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" blocker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333715151}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", testing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333772630}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directly is fine;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333772679}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333772795}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite snapshots (stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333772847}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and results"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333850486}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" EN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333850531}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V notes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333850566}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash. Reports will show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333850671}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" consistent sha"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333932896}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333932943}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n2. Run engine suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333933045}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333933133}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"72"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333982057}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s), static ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333982119}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fast),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333982163}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser (~95"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127333982204}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s). Total ~3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334039015}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"min. Run engine+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334039066}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"static in one background job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334039120}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sequentially then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334039179}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334137341}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CPU contention if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334137394}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" concurrent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334137490}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334137560}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" affects"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334197474}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" timing. Better sequential"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334197547}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334197594}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background job: `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334197637}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"node verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334290921}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/engine.test.mjs;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334290984}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node verify/static.test.mjs; node verify/browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334291048}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".test.mjs;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334291081}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334339161}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/report.mjs --"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334339233}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"write`. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334339294}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" takes ~3min."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334339349}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334427938}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334428005}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" killing preview6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334428073}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n3. Watch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334428120}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" logs; then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334484038}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect screenshots and report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334484087}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; message Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334484127}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me kill and launch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334484176}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334671914}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_9hvzh4zkswrt8vlnqhry4nnp","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334671993}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672067}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672149}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672234}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672314}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672396}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672474}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672564}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672619}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672752}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672797}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672853}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672910}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672952}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334672992}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673031}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673125}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673195}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673250}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673290}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673338}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673767}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673838}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673902}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334673958}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674001}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674055}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674095}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674139}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674182}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674221}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674261}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674325}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674652}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334674724}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334677013}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334677072}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334677106}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334677151}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334694970}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334695034}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334695074}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334695128}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334695700}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334695755}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334695807}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334695855}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334697302}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334697381}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334697448}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334697540}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334699350}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"kill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334699397}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334699475}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334699548}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334700002}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334700171}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334700258}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334700304}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334701338}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334701409}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334701473}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334701616}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334711455}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334711530}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334711578}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334711634}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334712164}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334712243}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334712314}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334712387}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334722846}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334722903}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334722948}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334722992}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"kill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334739754}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334739836}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334739904}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334739986}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334740700}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334740753}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334740932}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334741002}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334754298}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334754347}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334754393}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334754442}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334773719}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334773772}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334773814}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334773875}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334774588}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334774641}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334774684}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334774742}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334797624}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334797673}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334797712}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334797757}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334806034}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334806085}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334806143}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334806196}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334806595}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334806722}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334806777}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334806818}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" stat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334854528}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334854583}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334854640}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"%"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334854690}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334857609}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" %"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334857658}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"z"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334857698}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334857799}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334879731}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334879785}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334879829}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334879870}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334880090}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334880143}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334880196}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334880313}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" killed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334912393}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334912470}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334912568}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334912613}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334949483}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334949558}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334949615}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334949666}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334961585}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334961673}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334961744}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334961810}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334967157}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334967206}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334967265}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334967325}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334990931}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334990985}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334991053}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334991112}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334995273}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334995320}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334995377}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127334995435}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335066576}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335066642}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335066686}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335066889}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335066937}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335066976}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067027}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067101}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067143}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067183}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067221}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067284}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067460}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067893}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067939}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335067984}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335068062}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335068103}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335071814}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335071873}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335071918}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335071978}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335072061}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335072160}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335076620}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335076747}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335076794}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335076890}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335102933}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335102980}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335103033}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335103081}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335103599}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335103643}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335103695}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335103738}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335104199}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335104245}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335104288}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335104329}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335130015}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335130093}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335130144}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335130185}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335131173}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335131231}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"port"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335131278}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335131325}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335136994}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335137052}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335137096}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335137144}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335152736}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335152794}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335152835}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335152897}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335154079}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335154141}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335154187}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335154244}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335167040}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335167091}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335167131}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335167172}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335183626}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335183684}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INAL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335183731}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335183786}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ONE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335232058}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335232127}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335232184}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335232259}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335232694}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335232750}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335232802}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335232858}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335240441}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335240507}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335240574}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335240638}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335253357}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335253420}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335253463}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atrix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335253524}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-st"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335291627}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arted"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335291748}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335291843}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335291955}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335292462}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335292604}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335292713}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335292818}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335308453}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335308554}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ill"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335308631}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335308725}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335339185}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335339269}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" start"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335339341}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335339487}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" matrix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335406104}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335406212}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":28063,"ts_us":1793127335406302}}

data: {"id":"af54fc5a0779716d278d7521b20b0cf0","object":"chat.completion.chunk","created":1793127331,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":362434,"completion_tokens":832,"total_tokens":363266,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":361728,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":547,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":28063,"ts_us":1793127335413292}}

data: [DONE]

