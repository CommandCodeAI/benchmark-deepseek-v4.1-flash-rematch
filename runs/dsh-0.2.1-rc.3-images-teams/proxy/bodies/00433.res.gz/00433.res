data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286436911}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_9qq1qeudnfsw6k2hm5i0k979","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286517737}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286517795}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286517837}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286518682}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286518727}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286518769}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286518810}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286528936}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286529010}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286529075}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286529138}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286546876}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286546954}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286547029}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286547092}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286560152}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286560248}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286560322}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286560393}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286560917}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286560981}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286561042}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286561087}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286580132}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286580189}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286580227}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286580277}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286599011}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286599062}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286599265}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286599308}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286620667}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286620727}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286620776}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286620819}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286621337}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286621407}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286621482}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286621530}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286655701}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286655761}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286655812}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286655860}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286656344}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286656395}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286656553}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286656599}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286673059}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286673123}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286673173}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286673219}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286690824}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286690896}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286690939}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286690983}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286691465}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-header"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286691508}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286691588}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286691760}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286766916}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286767008}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286767088}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":61473,"ts_us":1793126286767168}}

data: {"id":"29c0a454de31a1cc37ea8f940c0fd420","object":"chat.completion.chunk","created":1793126286,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":270094,"completion_tokens":91,"total_tokens":270185,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":269312,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":61473,"ts_us":1793126286830333}}

data: [DONE]

