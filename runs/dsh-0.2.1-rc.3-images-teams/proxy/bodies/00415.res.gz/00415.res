data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032315263}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_7w0i6yjlfmsze9tscs8p5d4p","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032334651}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032334806}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032334846}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032336167}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032336623}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032336737}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032336990}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032344622}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032344683}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032344963}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032345021}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032364435}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032364511}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032364662}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032364766}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032384628}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032384827}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032384951}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032384998}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032385201}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032385432}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032385481}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032385662}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032394281}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032394448}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032394500}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032394593}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032416697}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032416828}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032416886}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032417049}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032450778}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032450941}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032451084}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032451238}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032451408}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032451639}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032451701}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032451896}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032468894}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032468950}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032469179}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032469233}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032484280}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032484371}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032484565}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032484609}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032499844}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032499929}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032500027}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032500162}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032501358}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032501447}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032501636}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032501711}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032521440}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"480"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032521496}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032521655}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"565"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032521717}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032531821}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032531916}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032532007}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032532043}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032550427}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032550673}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032550721}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032550896}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032607233}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032607325}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032607521}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032607652}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032610312}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032610376}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032610504}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032610553}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CSS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032610664}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" details"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032610736}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032611058}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42531,"ts_us":1793126032611112}}

data: {"id":"5264cb824f0fac61f6f2b1e01ff31e53","object":"chat.completion.chunk","created":1793126032,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":323549,"completion_tokens":114,"total_tokens":323663,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":322048,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":42531,"ts_us":1793126032691962}}

data: [DONE]

