data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250603174}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_224fhu288jfot4224hnda4lm","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250657639}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250657695}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250657766}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250675456}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250675526}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250676084}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250676148}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250694755}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250694833}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250694893}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250694960}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250706739}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250706819}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250706877}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250706984}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250737124}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250737195}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250737241}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250737294}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250757747}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250757828}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250757889}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250757977}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250766532}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250766581}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250766797}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250766866}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250767483}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250767553}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250767605}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250767651}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250840100}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250840183}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250840253}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250840315}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250840537}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250840675}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250840738}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250840774}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250841434}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250841526}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250841673}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250841738}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250841903}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250842080}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250842135}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250842173}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250842734}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250842867}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250842956}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250843068}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250857356}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250857449}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250857538}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250857606}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250876899}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"over"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250876955}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250877028}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250877124}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49323,"ts_us":1793125250975232}}

data: {"id":"aae2971afd3eeea30b0518d193be9b5c","object":"chat.completion.chunk","created":1793125250,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":235336,"completion_tokens":88,"total_tokens":235424,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":234240,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":49323,"ts_us":1793125250975348}}

data: [DONE]

