data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126271967756}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"While"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272052272}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272052369}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 runs, check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272052432}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272147581}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-record-nocat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272147646}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272149395}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0.png` visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272149456}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (from preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272250019}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272250222}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272250266}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272250302}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272350958}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272351021}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272351059}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" risk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272351115}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" notes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272421194}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nActually, more valuable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272421273}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272421326}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272421379}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272491464}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272491527}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272491608}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"already good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272491669}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and 102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272542173}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272542249}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview4 later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272542309}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272542440}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the nocat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272622922}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272622992}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_qi37jxjjb2uzjrwn8kuv0ndm","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623060}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623105}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623156}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623316}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623375}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623426}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623476}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623520}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623573}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623695}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623738}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623826}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623930}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272623977}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272631764}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272631843}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272631888}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272631947}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272651312}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272651392}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272651456}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272651507}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272669790}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272669856}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272669906}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272669999}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272689046}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272689108}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272689155}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272689206}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272689612}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272689672}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272689745}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272689829}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272733777}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272733857}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272733908}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272733980}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272738298}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272738385}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272738463}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272738551}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272772481}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272772557}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272772625}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272772693}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272772914}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272772978}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272773038}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272773097}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272814110}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272814201}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272814272}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272814321}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272823267}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272823338}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272823400}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272823502}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272823572}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272823647}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272823709}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272823760}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272912170}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22401,"ts_us":1793126272912255}}

data: {"id":"a14b66e872b5c8c73b0805bcd36b7f7f","object":"chat.completion.chunk","created":1793126271,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":327358,"completion_tokens":160,"total_tokens":327518,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":326912,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":68,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":22401,"ts_us":1793126272912380}}

data: [DONE]

