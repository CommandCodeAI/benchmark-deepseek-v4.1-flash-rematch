data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260647340}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260694391}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260694531}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260694980}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state (`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260766936}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"HE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260767009}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"LD`) because at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260767072}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260767132}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot script pauses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260845956}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; shows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260846001}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus ring around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260846383}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation slider (good visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260846427}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus). Spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260937228}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lines much"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260937594}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" better: mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260937639}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260937726}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line nice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260999701}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", seeds line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126260999933}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", regrowth,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261000115}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261000157}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", tempo, weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261072545}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261072693}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261072880}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261073146}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dots. The field looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261136926}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good with plant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261137317}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" density. Typography improved"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261137397}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nIss"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261137542}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ues:\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261218180}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The seed control row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261218282}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows top-right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261218548}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" readout \"190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261218601}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1\" plus scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261298624}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below; okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261298818}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261299086}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261299715}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cursor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261364305}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261364418}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"GEN 06"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261364609}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" appears as black box"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261364685}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still? It looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261430933}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like black/ink"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261431075}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" filled label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261431259}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with white"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261431302}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261502690}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier said"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261503022}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261503146}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label with brass; in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261503206}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" this screenshot it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261581044}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s dark."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261581138}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe screenshot from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261581241}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261581978}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261654438}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mtime maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261654675}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" old. Could be CSS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261654795}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261655391}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261734728}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cursor label styling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261734911}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is paper"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261735050}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261735110}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dark; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261811071}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" critical; it's a label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261811221}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and looks deliberate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261811480}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261811526}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ring around"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261880603}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slider"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261880861}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has dark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261880920}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outline around whole"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261881142}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control, fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261969889}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Time read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261970426}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"out \"110"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261970486}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126261970518}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s realised\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262046685}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262046835}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262046951}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" decays"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262047269}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262143536}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262143947}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pause (should maybe show 0 t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262143990}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s or last). But okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262144199}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; after pause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262222025}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262222254}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate measurement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262222723}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" decays;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262222891}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on a paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262308516}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state it shows 110 t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262308614}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s realised though"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262308896}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" actual 0,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262308930}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262379034}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262379204}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" measures rate as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262379284}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks/sec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262379876}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262520546}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" last 500ms including"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262520591}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pause transition"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262520635}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Over"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262520678}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time it will show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262552179}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0. In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262552255}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot at pause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262552737}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262552849}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"110. Minor.\n- `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262621695}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ticks 018"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262621948}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 · 0/s`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262622142}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262622200}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262695084}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262695186}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262695374}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".paused; okay.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262695692}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The \"TEM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262771558}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"PO\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262771659}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dial readout says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262771801}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2.0× and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262772042}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 110 t/s realized"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262880738}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262880915}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262881134}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" t/s;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262881216}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at pause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262973787}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262973886}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" measurement 110 from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262974044}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prior? Not ideal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126262974865}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but minor.\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263036520}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" field:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263036755}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 656"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263036904}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora, nice.\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263036950}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" layout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263107898}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feels maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263108111}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slightly sparse"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263108402}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" left edge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263108623}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263184310}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay.\n- The mast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263184573}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"head subtitle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263184820}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263184881}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263262522}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ecology...\" strong"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263263169}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The instrument"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263263247}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" panel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263263331}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right has some"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263348598}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" blank bottom after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263348954}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263349030}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fine.\n\nLatest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263349112}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263436295}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" changes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263436475}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263436590}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263436638}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible in screenshot due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263512828}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" old timestamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263513225}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263513302}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll regenerate after final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263513360}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263587392}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263587474}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263588168}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" backing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263588215}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fix;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263718728}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263718852}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if they updated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263718958}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263719200}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 23:27"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263759159}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". mtime later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263759244}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263759528}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check. Also check messages"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263759566}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263880649}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"asks."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263880735}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_eo12ei4avemln0lhw818hcb7","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263881035}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263881320}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263881365}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263882227}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263882279}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263882323}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263882375}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263882422}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263882481}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263883384}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263884341}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263884402}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263884460}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263884531}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263884713}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263884763}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263884800}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263884850}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263932710}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263932760}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263933030}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263933077}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263976378}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263976424}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263976479}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263976527}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263976578}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263976617}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263976777}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263976855}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263995197}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263995310}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263995436}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126263995526}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264007073}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264007226}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264007313}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264007369}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264024717}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264024944}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264025008}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264025119}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264025476}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264025591}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264025734}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264025794}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264040216}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264040306}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264040560}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264040746}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264040842}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264040889}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264041568}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264041638}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264057851}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264057911}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264057952}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264058053}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264109186}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264109300}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264109486}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264109579}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264131848}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264131927}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264132036}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264132109}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264135706}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264135840}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264135982}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264136040}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" */"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264137460}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264137600}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264137715}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264137850}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264144800}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264144849}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264145189}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264145276}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264169653}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264169710}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264169820}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264169871}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264190895}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" states"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264190954}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264191020}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264191068}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264208837}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264208890}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264209034}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264209091}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264238201}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ;"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264238252}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264238353}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264238431}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264249716}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264249877}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264250011}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264250066}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ifier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264268438}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264268565}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" exists"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264268658}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264268709}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264280716}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264280829}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264280955}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264281037}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264325314}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264325366}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264325480}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264325534}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PORT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264326395}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264326436}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264326528}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264326579}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264330161}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264330218}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264330307}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ||"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264330409}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264376671}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264376780}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264376867}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264376961}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264388622}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264388666}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264388782}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264388830}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264389190}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" latest"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264389278}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" module"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264389406}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264389450}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"estamps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264405558}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264405622}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264405735}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264405785}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264538609}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_s063fcvsx5ycw49jbrjsmlv7","type":"function","function":{"name":"team_task_list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264538669}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":45960,"ts_us":1793126264538886}}

data: {"id":"01a5aed8b6cdc97d5ffdeb4d86472242","object":"chat.completion.chunk","created":1793126260,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":329904,"completion_tokens":622,"total_tokens":330526,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":328192,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":439,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":45960,"ts_us":1793126264545612}}

data: [DONE]

