data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555468164}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555506448}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CSS is paper-colored."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555506733}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Yet screenshot label looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555506915}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" black? Maybe it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555572658}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s dark due to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555573627}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555573712}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scale"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555573751}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555662088}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555663037}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s paper with dark text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555663129}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and brass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555663221}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" border; at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555713262}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1440 screenshot it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555714091}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555714211}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" black because the label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555714254}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is at small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555784959}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" size with shadow."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555785912}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Zoom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555786036}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555786086}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555853653}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"13"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555854493}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-rule-end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555854613}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".png to see."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555854713}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_qiclkvjmfmb5awcx2aiah4ru","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555895809}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555896958}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555897074}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555897166}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555905575}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555906529}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555906636}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555910369}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555910463}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555910550}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555917019}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555917074}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555925570}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555926595}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555926753}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555926872}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555939136}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555940110}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555940206}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555940293}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555954444}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555955423}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555955565}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555955616}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555960429}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555960525}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555960648}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555960694}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555972742}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555973137}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555973256}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555973380}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555988688}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555988779}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555990522}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555990580}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555990716}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555990835}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555990939}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127555991059}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556002566}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556002692}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556005051}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556005217}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556029367}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556029482}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556029579}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556029679}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556029775}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556029918}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556071753}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556071910}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556072114}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556072223}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556072311}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556072414}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"13"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556077861}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556077916}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rule"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556078033}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-end"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556078159}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556113691}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556114701}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10400,"ts_us":1793127556116651}}

data: {"id":"2c9cb6f252aed80baa3417748033cdb5","object":"chat.completion.chunk","created":1793127555,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":358051,"completion_tokens":153,"total_tokens":358204,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":357504,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":62,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":10400,"ts_us":1793127556125489}}

data: [DONE]

