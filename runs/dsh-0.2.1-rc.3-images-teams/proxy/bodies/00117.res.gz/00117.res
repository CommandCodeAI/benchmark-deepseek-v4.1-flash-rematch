data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123542924856}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_n65xjb7r9emx0v8kzcs7pga5","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123542956816}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123542956877}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123542956923}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543003632}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543003695}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543003799}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543003863}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543003903}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543004014}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543004074}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543005371}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543018036}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543018080}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543018628}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543018689}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543032460}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543032553}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543032705}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543032762}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543070627}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543070704}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543070769}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543070887}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543070959}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543071011}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543071049}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543071093}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543071157}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543071214}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543071259}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543071317}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543075322}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543075376}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543075406}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543075450}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543075499}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543075972}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543076050}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543077646}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543092888}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543092954}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543093005}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543093044}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543152975}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543153038}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543153093}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543153142}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543154180}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543154229}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543154276}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543154316}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543154445}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543154496}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543154657}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543154693}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543160494}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-dr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543160552}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ift"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543160596}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543160653}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543174805}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543174856}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543174904}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543174960}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6904,"ts_us":1793123543237065}}

data: {"id":"785dccf3b0c49297f8c958c14e42c050","object":"chat.completion.chunk","created":1793123542,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":146909,"completion_tokens":92,"total_tokens":147001,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":144512,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6904,"ts_us":1793123543237173}}

data: [DONE]

