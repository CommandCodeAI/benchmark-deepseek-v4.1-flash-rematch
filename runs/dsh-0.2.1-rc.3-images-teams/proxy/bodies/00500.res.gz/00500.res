data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147561972}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147582960}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright frozen. Atelier still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147583140}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running but no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147583452}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" writes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147635186}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" since 23:47"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147635901}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; likely finishing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147636017}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147636134}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots/re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147701960}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"port. Need freeze"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147702824}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" confirmation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147702964}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". We can proceed to assemble"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147703033}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now but at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147778651}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier may still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147779450}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edit design.css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147779576}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/controls.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147779659}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147852452}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they marked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147853270}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task complete"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147853348}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147853416}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147921387}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147922418}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147922518}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" completed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147922605}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147989201}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147989364}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier reply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147989512}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Wait more or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127147989658}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interrupt?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148051079}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's wait "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148052136}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148052347}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148052415}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148112959}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148113871}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148113987}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148114099}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" freeze"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148176693}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148177664}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" send"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148177780}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148177878}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" direct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148244600}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" message \"free"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148245483}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ze now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148245609}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", reply\"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148245669}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148319185}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148320137}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe they're doing "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148320226}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1024 sanity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148320367}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148417809}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reply"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148418770}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Wait."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148418899}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_0s06cwh1478i93qwoig3el8p","type":"function","function":{"name":"wait_agent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148419082}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148424754}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148424939}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148425053}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148425146}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148441222}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148441294}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148441347}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148444104}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148545716}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":11418,"ts_us":1793127148545823}}

data: {"id":"b61af6fc1af57ab0a8994b6179a2fa19","object":"chat.completion.chunk","created":1793127147,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":346326,"completion_tokens":151,"total_tokens":346477,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":344704,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":109,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":11418,"ts_us":1793127148547609}}

data: [DONE]

