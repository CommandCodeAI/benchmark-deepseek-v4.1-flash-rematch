data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993510212}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993614552}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 horizontal fixed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993614606}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (scrollW 1024"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993616222}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), vertical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993664233}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll remains (allowed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993664300}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). 1440 all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993664518}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pass. 1280 run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993664586}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still in background (probably"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993748994}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" needs a bit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993749060}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993749164}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait for it ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993749212}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993836000}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993836065}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shortly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993836113}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Meanwhile compute final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993836175}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hashes after the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993884717}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993884796}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993884878}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for 1280 pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993884930}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before freeze. Let me poll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993976550}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the job."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993976622}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_u9t6z18k1nl47j6gx9ksma6k","type":"function","function":{"name":"job_output"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993976694}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993976751}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993976826}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"job"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993976891}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993976955}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977025}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977172}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977240}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977329}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977383}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977416}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977465}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977499}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"776"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993977993}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993978059}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993978106}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993978149}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"477"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126993978178}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994005664}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994005716}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994005768}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994005807}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994022568}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994022677}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994022759}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"true"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994022838}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994055736}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994055850}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994055965}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994056022}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994071971}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994072075}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994072325}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994072397}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994167103}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57751,"ts_us":1793126994167169}}

data: {"id":"7a1f3b5aec7c5d49afbc563d4ee47f81","object":"chat.completion.chunk","created":1793126993,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":372471,"completion_tokens":153,"total_tokens":372624,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":369408,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":69,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":57751,"ts_us":1793126994167261}}

data: [DONE]

