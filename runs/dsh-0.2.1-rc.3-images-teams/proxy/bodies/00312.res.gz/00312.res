data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944391093}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944480934}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rule crop: I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944481020}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" see"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944481080}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" transport"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944625029}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" buttons, \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944625101}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"RUN\" vertical, GEN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944625142}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 01 black label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944625193}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944713648}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rule line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944713701}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with ticks:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944713779}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" major ticks with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944713843}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numerals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944766748}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944766814}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944766873}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5,10,15,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944766905}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20,25,30,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944829742}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"35,40 visible ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944829789}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"small). The numbers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944829826}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are tiny ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944829889}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"8px) and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944925285}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" light; but per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944925365}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brief \"eng"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944925426}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"raved major"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944925482}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124944999935}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5 gens, minor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945000046}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks, numerals "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945000147}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0..N\" — they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945000211}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are present"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945169211}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". At 144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945169292}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 they look small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945169350}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945169401}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Cursor label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945237003}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" readable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945237055}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMissing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945237135}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": wax"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945237205}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seals ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945304255}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"none yet at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945304309}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 1) — fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945304357}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Progress fill"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945304407}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945379388}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 to cursor: there"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945379487}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s a darker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945379538}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945379592}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945436176}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"140 to cursor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945436261}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945436315}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t see clearly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945436388}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". OK.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945492499}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me check folio crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945492544}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945492585}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_bkzr35fuv1yenyxrorrxib10","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945492677}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945492773}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945492851}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945492934}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493030}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493115}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493193}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493445}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493509}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493552}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493663}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493738}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493788}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ol"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493843}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"io"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493893}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945493950}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945494004}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16719,"ts_us":1793124945494058}}

data: {"id":"2805f52604c7bdcbad436d2bcacbf198","object":"chat.completion.chunk","created":1793124944,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":278637,"completion_tokens":202,"total_tokens":278839,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":278016,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":156,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":16719,"ts_us":1793124945494151}}

data: [DONE]

