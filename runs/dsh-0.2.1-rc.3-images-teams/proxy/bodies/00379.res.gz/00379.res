data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554616695}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554727085}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview2 suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554727132}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" progress (~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554727169}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"90"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554842667}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s). Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554842741}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 60s then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554842797}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554842835}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8lvv2mdq60vpjgq8br225334","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554842892}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554843146}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554843191}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554843236}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554843291}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554843376}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554843631}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554843694}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554843742}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"55"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554844364}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554844424}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554844485}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554856463}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554856556}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554856621}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FAIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554856672}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554862492}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554862540}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554862619}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554862696}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554868858}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554868925}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554868966}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554869011}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554884506}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554884550}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554884591}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554884641}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554885614}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554885655}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554885714}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554885761}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554902591}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554902645}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554902702}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554902797}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554915722}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554915772}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554915825}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554915884}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554949377}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554949417}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554949460}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554949499}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554972561}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554972602}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554972655}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125554972706}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125555001735}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125555001810}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125555001865}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" progress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125555001898}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125555094940}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":21517,"ts_us":1793125555095038}}

data: {"id":"d5ca49c553a101d25bce86c28470862b","object":"chat.completion.chunk","created":1793125554,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":310931,"completion_tokens":105,"total_tokens":311036,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":310016,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":16,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":21517,"ts_us":1793125555095171}}

data: [DONE]

