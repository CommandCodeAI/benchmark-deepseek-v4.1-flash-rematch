data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509304709}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rr1vpwblsisfgcvz8qdfwsvm","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509347372}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509347454}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509347496}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509368234}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509368331}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509368384}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509368434}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509388130}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509388182}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509388256}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509388334}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509403383}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509403434}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509403592}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509403641}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509403732}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509403856}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509403900}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509404000}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509418697}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509418751}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509418800}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509418872}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509433460}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509433517}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509433562}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509433626}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509447104}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509447150}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509447214}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509447266}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509447683}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509447752}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509447830}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509447897}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509484822}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509484889}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509485050}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509485099}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509502281}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509502366}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509502507}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509502618}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509503150}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509503226}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509503322}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509503432}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509516492}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509516569}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509516639}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509516779}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509533530}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509533591}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509533650}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509533728}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509534334}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509534388}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509534485}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509534634}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509551524}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509551576}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509551726}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509551779}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509589031}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509589095}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509589186}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509589293}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509589738}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509589801}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509589874}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509590796}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509601666}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509601755}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509601826}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509601924}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509602041}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509602159}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509602249}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509602335}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509613531}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509613629}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509613723}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509613816}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509635734}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509635803}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"interval"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509635873}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509635921}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509651783}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509651847}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509651918}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509651963}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509673670}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509673793}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509673869}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509673944}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509681021}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509681165}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509681215}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509681258}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509716143}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509716218}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"150"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509716283}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509716333}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509717032}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509717087}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509717182}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509717298}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509734260}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509734334}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509734417}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509734498}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509773962}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509774015}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509774065}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509774111}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509785012}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509785066}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509785200}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509785258}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CD"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509807635}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509807689}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" harness"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509807890}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509807949}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" capture"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509820670}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509820786}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" errors"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509820892}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509820954}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2815,"ts_us":1793123509888297}}

data: {"id":"15d9d39e6fb5853fd3bb287fe63fc74f","object":"chat.completion.chunk","created":1793123509,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":144342,"completion_tokens":163,"total_tokens":144505,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":140800,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2815,"ts_us":1793123509888376}}

data: [DONE]

