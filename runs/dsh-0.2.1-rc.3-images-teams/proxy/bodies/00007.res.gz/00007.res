data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358405572}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358458139}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rome available; playwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358458257}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browsers in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358458514}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358516159}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/Library/Caches/ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358516319}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-playwright probably."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358516410}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358516631}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358597156}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also can use Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358597218}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless screenshot CLI:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358597304}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358597344}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Applications/Google Chrome.app/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358658452}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Contents/MacOS/Google"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358658539}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome --headless=new --"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358658599}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"screenshot=... --window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358658990}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-size=144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358730050}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0,900 file:///"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358730119}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...`. That works without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358730205}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" installing."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358730311}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Very useful"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358792912}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for visual QA."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358792980}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Since file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358793129}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358793182}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local, no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358853477}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network needed (Ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358853603}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rome may try"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358853755}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" network but the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358853814}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page doesn't)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358930008}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I can screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358930118}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCheck"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358930259}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" playwright module"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358930324}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" availability ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358998028}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"node can't"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358998126}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" require unless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358998291}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" local"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122358998448}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Use Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359096428}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless screenshot with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359096503}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `--virtual-time"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359096750}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-budget` to advance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359096818}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" animation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359121754}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359121839}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359121990}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359122041}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359187890}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me see ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359187989}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-playwright contents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359188173}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359188250}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1p8qbprsx55n9v48lzlczit7","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359229229}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359229329}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359229446}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359229615}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359236541}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359236642}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359236722}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359236903}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ~"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359237154}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359237298}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Library"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359237431}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359237547}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aches"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359254784}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359254916}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359255198}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359255285}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359271674}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359271933}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359272028}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359272374}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359272468}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359272688}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359272788}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359273104}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359293472}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359293676}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359293980}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359294078}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ~"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359446290}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359446367}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Library"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359446402}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359466877}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aches"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359466971}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359467041}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359467105}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359467181}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359467243}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359511016}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359511067}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359511143}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359511184}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640161}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640258}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640349}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640433}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640509}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640581}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640663}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640853}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640931}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359640988}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359641036}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731129}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731192}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731238}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731318}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731383}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" npm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731445}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" root"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731786}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731862}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359731919}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359732005}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359732077}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359732146}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359732199}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359732932}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359733005}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359733059}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359733124}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Play"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359733191}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wright"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359733232}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cache"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359733286}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359734196}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359734244}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359734312}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_gjp44824tgy0qrck9kurzjym","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359734410}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359734470}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359734548}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359735038}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359735108}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359735157}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359735204}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"mkdir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359735277}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359735351}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359736083}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359736132}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359736181}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359736227}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359736269}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359736315}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359737310}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" printf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359737357}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359737396}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359737435}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"><"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359737514}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"body"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359737592}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" style"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359737670}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359738394}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"background"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359738458}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":":#"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359738532}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"eee"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359738588}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\\\"><"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359738635}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359738689}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359738744}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359738811}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Hello"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359739657}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"</"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359739733}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359739782}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359739834}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"></"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359739902}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"body"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359739955}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"></"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359740675}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359740749}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359740799}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359740840}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359740882}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359740935}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359741880}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359741940}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359741988}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359742041}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359742097}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359742149}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359742204}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Applications"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359743029}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359743097}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359743165}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359743244}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359743327}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359743405}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359743495}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359743551}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359750967}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"OS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359751202}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359751256}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359752457}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359766102}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359766524}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359766597}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359766667}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359766749}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"=new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359766828}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359766890}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"disable"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359767172}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359784656}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"pu"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359784790}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359784873}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"hide"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359785033}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-sc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359795426}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359795579}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"bars"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359795663}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359795715}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359812769}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359812860}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"=/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359813013}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359813068}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359813424}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359813476}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359813625}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359813683}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359825744}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359826076}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359826139}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-size"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359826246}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359845737}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359845817}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359845978}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"600"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359846070}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359846324}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359846454}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359846500}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359846689}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359861765}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359861818}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359861861}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359861908}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359879723}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359879937}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359879978}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359880286}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359880347}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359880446}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359880528}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359880754}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359893913}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359893991}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359894069}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359894290}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359911409}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359911489}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359911540}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359911765}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"hot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359944213}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359944336}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359944506}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359944579}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359945238}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359945400}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359945588}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359945657}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359962750}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"Test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359962831}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359962982}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359963142}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359981042}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" screenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359981159}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" capability"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359981401}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122359981491}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1232,"ts_us":1793122360044452}}

data: {"id":"c9c15145990d1ce18c4d4934f4c99da1","object":"chat.completion.chunk","created":1793122358,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":19575,"completion_tokens":415,"total_tokens":19990,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":9600,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":146,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1232,"ts_us":1793122360044628}}

data: [DONE]

