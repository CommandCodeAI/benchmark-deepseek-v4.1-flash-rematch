data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600559953}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600560823}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me apply the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600560865}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edits. First find"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600601025}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600601189}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `.inst` padding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600601472}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600601534}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600636500}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_r5taejwk7hvhmqgue0v2sdxw","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600636675}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600636848}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600636968}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600650659}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600650780}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600650961}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600651657}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600678989}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600679135}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600679266}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600679439}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600680218}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600680270}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600680386}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600680434}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600704806}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600704861}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600705024}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600705291}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600722596}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600722668}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600722737}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600723322}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600723391}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600723440}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600723571}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600723621}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600735522}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600735689}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600736025}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600736069}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600748809}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600749347}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600749402}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600749499}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600768749}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600768796}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600768905}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600768958}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600784623}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600784760}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600784982}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600785060}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600785722}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600785949}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600786006}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600786174}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600871825}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600871910}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600871957}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600872037}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600872180}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600872456}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600872540}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600873069}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"142"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600888089}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600888262}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600888371}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"147"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600888559}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600888921}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600889158}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600889210}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600889315}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600896181}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600896239}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600896367}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600896454}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600896558}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600896913}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600897010}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600897097}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600930678}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600930734}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600930779}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" inst"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600930822}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" row"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600947278}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CSS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600947479}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" block"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600947535}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123600948397}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1888,"ts_us":1793123601016854}}

data: {"id":"bb13a9b03a8528ac2f5ae47892dfdb7e","object":"chat.completion.chunk","created":1793123600,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":167716,"completion_tokens":130,"total_tokens":167846,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":166016,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":15,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1888,"ts_us":1793123601017300}}

data: [DONE]

