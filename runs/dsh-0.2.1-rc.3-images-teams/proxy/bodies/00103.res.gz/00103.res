data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460180958}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_7igaav5muz8boktz7qyleb1g","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460231841}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460231910}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460231975}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460252354}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460252412}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460252458}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460252494}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460265652}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460265723}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460265774}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460265827}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460282204}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460282395}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460282447}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460282483}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460298762}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460298815}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460298862}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460298957}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460311148}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460311198}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460311231}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460311282}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460329605}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460329701}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460330226}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460330355}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460330532}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460330600}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460330663}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460330725}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460342197}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460342327}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460342420}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460342468}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460357775}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460357829}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460357881}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460358888}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460358937}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460358977}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460359023}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460359082}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460375830}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460375878}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460375918}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460375958}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460389861}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460389938}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460390001}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460390044}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460390375}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460390435}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460390477}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460390531}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460404479}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460404526}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460404578}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460404624}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2674,"ts_us":1793123460488150}}

data: {"id":"6522c4b4f6232988096dd395bf974927","object":"chat.completion.chunk","created":1793123460,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":137011,"completion_tokens":88,"total_tokens":137099,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":136448,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2674,"ts_us":1793123460488235}}

data: [DONE]

