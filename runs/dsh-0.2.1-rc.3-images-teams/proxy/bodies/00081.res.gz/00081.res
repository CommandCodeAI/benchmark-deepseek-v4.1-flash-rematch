data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123284970570}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123284970646}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead confirmed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123284970674}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Now I need to read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285007531}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" design.css before writing ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285007618}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"the tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285007753}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" requires read). Since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285008058}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I never read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285096117}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it, I'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285096235}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read it then write. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285096525}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285096566}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is the placeholder. Let me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285121571}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read then write the same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285121650}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285121777}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNote: I have"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285121857}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285186309}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content ready. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285186404}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me read first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285186690}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285186907}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_czdav9ewtt0mcoz90wmlu5w6","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285188019}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285188135}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285188359}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285188546}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285210503}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285210615}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285210710}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285210836}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285226425}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285226501}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285226618}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285226765}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285240103}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285240312}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285240408}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285240597}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285257262}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285257372}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285257421}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285257603}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285257669}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285257811}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285257856}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285258055}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285270190}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285270240}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285270283}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285270372}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285289602}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285289695}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285289780}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285289941}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285290718}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285290897}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285291822}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285291879}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285308290}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285308368}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285308437}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285308535}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285352890}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285352957}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353015}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353153}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353265}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353342}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353410}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353528}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353575}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353629}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353833}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285353903}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285425345}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285425496}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285425557}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1832,"ts_us":1793123285429608}}

data: {"id":"512ee50a9149dc7605e2f06022cfd8fa","object":"chat.completion.chunk","created":1793123284,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":100072,"completion_tokens":146,"total_tokens":100218,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":71552,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":63,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1832,"ts_us":1793123285429730}}

data: [DONE]

