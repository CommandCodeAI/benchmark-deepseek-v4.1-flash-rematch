data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282828555}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282871403}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mm, the `ls .."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282871466}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` didn't show."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282873573}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me rerun."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282926950}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_67jzcoiyh9xsxl5o3xxn9dp0","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282927003}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282927050}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282927094}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282941195}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282941279}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282941347}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282941936}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282957666}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282957839}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282957901}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" .."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122282958878}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ;"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283013568}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283013726}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283013955}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283014064}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283035481}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ;"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283035637}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283035828}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283035921}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283079316}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"list"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283079557}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ;"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283079717}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283079793}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283080062}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283080111}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283080158}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283080737}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283100210}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283100378}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283100443}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283100719}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283111614}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283111687}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283111847}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283112035}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283134111}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283134181}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283134230}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283134344}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283154309}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283154438}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283154518}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283154685}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283174591}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283174709}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283174750}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283174984}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283187609}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283187743}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283187795}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283188059}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283204009}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283204092}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283204137}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283204246}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283218873}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283219037}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283219194}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283219279}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283219697}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283219787}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283219857}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283220084}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283236513}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283236629}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283236911}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283236983}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283256677}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283256780}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283256966}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283257014}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283291820}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283292057}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283292138}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283292429}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283316716}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283316811}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283316930}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"List"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283316978}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" parent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283337045}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283337155}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283337213}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283338052}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" git"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283363902}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" config"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283363961}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283364066}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1149,"ts_us":1793122283364105}}

data: {"id":"55eaec3bedaa797d3930762f01d459c4","object":"chat.completion.chunk","created":1793122282,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":7254,"completion_tokens":139,"total_tokens":7393,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":7040,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":17,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1149,"ts_us":1793122283388517}}

data: [DONE]

