data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964574135}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964595037}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" change event occurred but no message? Check messages"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964595346}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/status/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964596099}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"times."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964625022}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ww7dgrjfr0i0dqrkmi2jsbn1","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964625379}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964626296}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964626353}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964626438}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964626555}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964626606}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964629450}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964629547}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964629596}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964629702}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964629748}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964655427}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964655478}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964655536}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964656230}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964660863}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964661272}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964661417}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964661477}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964674936}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964675341}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964675506}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964675593}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964697330}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964697655}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964697785}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964697846}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964732310}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964732708}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964732874}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964732936}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964745974}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964746098}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964746195}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964746318}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964748367}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964748475}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964748621}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964748674}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964764878}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964764979}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964765293}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964765380}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964782884}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964783587}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964783860}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964783950}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964954227}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964954386}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964954509}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964955391}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964955496}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964955653}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964972563}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964972618}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964972682}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964973776}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964973888}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964973959}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126964974076}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965145067}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965145183}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965145230}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965145300}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965145400}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965145484}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965145537}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965147423}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965147513}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965147622}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965149191}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965149259}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965149356}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965149463}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965149579}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965149668}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965153761}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965153917}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" */"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965153963}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965154049}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965154140}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965154298}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965158398}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965158492}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965158577}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965158764}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965158821}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965158897}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965158980}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965162975}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965163060}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965163162}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" module"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965163263}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" freeze"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965165147}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965165278}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965165400}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965165493}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_476687q2o93ojpp7cr4hrbr8","type":"function","function":{"name":"list_agents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965165596}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10053,"ts_us":1793126965165726}}

data: {"id":"3d3cfb6e2ef5f5f9222d698275de5736","object":"chat.completion.chunk","created":1793126964,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":341139,"completion_tokens":160,"total_tokens":341299,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":340864,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":15,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":10053,"ts_us":1793126965169924}}

data: [DONE]

