data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486587351}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486678955}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine suite now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486679049}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" takes >60s due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486679122}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486737277}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486737332}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486737390}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486737429}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486796589}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9, etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486796658}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".). That's too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486796727}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slow for iteration"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486796806}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486882123}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486882215}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" its"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486882288}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output while I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486883227}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" work on other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486943212}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" things. Meanwhile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486943290}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check progress"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486943344}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of Lead's modules"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123486943660}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487009151}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"engine landed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487009221}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; maybe boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487009398}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/render next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487009442}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Let me check job"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487097400}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" output in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487097451}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a bit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487097494}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and check files"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487097572}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nActually the "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487167780}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"200-gen run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487167837}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487167924}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9×120"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487168002}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-gen runs + benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487227508}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487227554}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".5s... engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487227603}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487227646}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"25"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487404457}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens/sec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487404527}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487404571}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier 100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487404661}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens = 2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487457501}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5s → 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487457602}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens/s. 120 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487457653}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≈"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487457695}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487554451}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ×9 = "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487554495}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"27s;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487554546}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 200 gens 5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487554591}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s; 100 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487629058}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487629169}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" many ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487629241}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487629348}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = ..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487696139}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" total maybe "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487696508}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"60-90s. Accept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487696555}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able once,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487696590}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but for frequent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487774197}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reruns maybe reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487774246}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487774283}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487774317}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for now;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487826688}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487826740}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487826778}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487826852}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWhile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487907436}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" waiting, let me write the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487907489}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487907532}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generator"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487907583}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and run static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487991039}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite again"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487991149}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Also message"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487991229}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123487991307}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" early findings ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488043962}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"engine contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488044042}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deviations + status"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488044236}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488044273}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me first check if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488093524}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488093593}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488093650}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able updated +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488093714}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" other"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488153912}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" modules."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488153996}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_wx1rwdp3y7hs1a7c73du0zdq","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488154045}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488154113}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488154171}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488154222}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488154269}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488154361}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488154426}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488154500}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155209}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155254}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155299}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155340}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155446}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155537}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155601}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155692}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155761}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155830}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155893}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488155950}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156088}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156191}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156256}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156315}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156371}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156455}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156529}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156594}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156654}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488156707}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488157330}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488157400}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488157447}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488157506}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488171303}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488171366}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488171423}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488171481}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488205518}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488205590}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488205651}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488205710}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488216114}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488216218}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488216311}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488216396}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488228386}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488228494}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488228588}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488228752}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488228934}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488229080}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488229155}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488229215}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488245296}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488245556}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488245624}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488247744}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488259884}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488259973}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488260052}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488260120}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488279948}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488280025}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488280105}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488280180}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488280679}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488280768}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488280853}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488280946}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488301560}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488301677}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488301762}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488301849}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488318699}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488318808}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488318925}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488319019}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488367295}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488367400}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488367485}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488367567}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488367646}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488367721}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488367796}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488367874}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488369898}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488370009}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" module"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488370090}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" progress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488370167}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488476494}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2415,"ts_us":1793123488476585}}

data: {"id":"fe16747b74841947d55709c7a0173a91","object":"chat.completion.chunk","created":1793123486,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":127360,"completion_tokens":347,"total_tokens":127707,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":127104,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":220,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2415,"ts_us":1793123488476715}}

data: [DONE]

