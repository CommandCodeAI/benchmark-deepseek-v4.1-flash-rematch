data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821531924}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821636962}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grep output yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821637008}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — suite still running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821637049}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821773767}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also check if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821773909}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead reassemb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774014}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"led."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774080}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yfh9nwbnww7jbccqj4c1bmjq","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774325}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774382}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774445}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774501}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774544}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774616}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774689}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774753}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774798}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774863}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821774921}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775003}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775115}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775157}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775206}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775247}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775292}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775358}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775428}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821775489}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821780136}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821780203}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821780260}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821780304}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821794792}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821794860}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821794906}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821794985}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821805443}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821805666}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821805717}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821805978}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821806348}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821806422}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821806468}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821806531}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821843030}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821843085}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821843143}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821843193}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821860186}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821860251}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821860322}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821860375}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821873855}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821873902}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821873943}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821873986}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821874280}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821874330}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821874468}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821874538}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821901703}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821901766}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821901811}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821901865}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821922369}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821922430}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821922487}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FAIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821922586}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821949703}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821949777}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821949838}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821949890}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821967080}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821967157}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821967219}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821967277}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821967384}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821967626}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821967696}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821967746}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821988309}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821988402}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821988456}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125821988512}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822022404}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822022485}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822022532}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822022584}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822023064}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822023175}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822023252}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822023336}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822029223}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" deliver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822029281}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"able"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822029355}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822029427}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822065204}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822065273}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822065333}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822065421}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822071089}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822071168}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822071271}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822071334}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822071668}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822071714}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822071758}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822071806}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822087829}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822087898}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822087943}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822087989}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144155}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144204}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144253}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144300}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144343}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144382}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144458}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144528}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144619}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144755}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144803}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822144844}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822197397}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822197475}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822197538}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822197578}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822197718}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822197796}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822197853}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822197913}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822218312}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assembly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822218364}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822218407}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822218466}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":23116,"ts_us":1793125822409572}}

data: {"id":"244d5ac3a17498bd227c3166e4a16c0f","object":"chat.completion.chunk","created":1793125821,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":318842,"completion_tokens":184,"total_tokens":319026,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":318080,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":20,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":23116,"ts_us":1793125822409667}}

data: [DONE]

