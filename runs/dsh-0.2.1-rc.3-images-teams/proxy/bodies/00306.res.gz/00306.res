data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879102706}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879189977}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" new suite run ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879190029}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879190451}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowser-official-2)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879278274}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879278321}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capturing shots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879278381}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (tim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879278429}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"estamps 23:14"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879335697}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879335768}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overwrote"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879335825}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879335914}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/mid/initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879421129}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879421218}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me view initial-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879421285}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1440 and event-144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879421787}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0-1 now (from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879514330}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" current run)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879514409}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_g70lucae6bleujm092a9nosr","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879514490}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879514559}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879514714}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879514774}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879514841}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879514913}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879526006}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879526078}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879526143}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879526191}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879526379}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879526434}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879526508}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879526611}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879530758}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879530803}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879530853}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879531131}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879533601}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879533649}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879533715}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879533791}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879533894}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879533947}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879534018}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879534087}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879537880}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879537931}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879537974}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879538400}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879540996}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879541049}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879541080}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879541124}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879547403}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879547451}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879547500}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879547560}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879549844}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879549925}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879549986}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879550050}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879560306}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879560352}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879560400}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879560446}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879561005}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879561073}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879561133}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879561256}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879562068}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879562123}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879562261}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879562372}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879562528}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"itial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879562715}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879562757}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879562830}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879576176}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879576222}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879576542}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16361,"ts_us":1793124879576603}}

data: {"id":"ed8fd5b886f41c8908f11229909a00f8","object":"chat.completion.chunk","created":1793124879,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":275669,"completion_tokens":143,"total_tokens":275812,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":274304,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":53,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":16361,"ts_us":1793124879632009}}

data: [DONE]

