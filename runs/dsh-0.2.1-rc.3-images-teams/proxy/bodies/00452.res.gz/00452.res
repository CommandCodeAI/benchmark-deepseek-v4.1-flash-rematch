data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560294052}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560391890}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560391939}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560392702}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"PR2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560451623}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": \n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560451697}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The \"GEN "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560451754}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"12\" cursor label at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560451812}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 92"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560517485}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"% correctly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560517580}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560517663}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"amps inward"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560517726}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (translate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560569447}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"X(-100%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560569523}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")) — the label's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560569581}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right edge aligns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560569639}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with cursor. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560649440}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560649485}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numerals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560649532}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0,5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560649580}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",10,13 (major"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560747786}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560747861}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560747924}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",5,10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560747974}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560819823}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560819885}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"13 marked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560819946}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" major by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560819999}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot). Numer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560880222}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"als leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560880287}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ible.\n- There's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560880343}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a green wax seal at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560880399}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560943100}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560943169}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ague,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560943227}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" olive-green)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560943285}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and cursor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560995508}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 12"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560995554}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The seal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560995599}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" letter"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126560995652}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561059255}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" visible."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561059337}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n- The rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561059420}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" readout"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561059486}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"GEN 12 / "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561135949}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"13\" / \"2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561136003}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0× · 60 ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561136040}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s · held\" leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561136065}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ible.\n- The rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561195938}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561196004}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rail:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561196061}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" progress line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561196197}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561287665}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to cursor ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561287735}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"brass), and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561287792}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" major ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561287847}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" below"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561353654}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Looks decent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561353704}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The \"RUN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561353758}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" vertical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561353804}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561432577}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The fol"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561432659}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"io legend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561432719}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561432773}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line visible at right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561490870}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; \"Every"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561490927}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" variable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561490966}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is a weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561491008}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561545284}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sig"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561545377}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". \n- Note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561545697}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561545770}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the ledger's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561620901}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second entry"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561620974}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"P"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561621025}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"est"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561621076}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ilentia\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561701773}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561701840}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561701888}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s cursor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561701933}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" label has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561757285}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561757363}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" border;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561757420}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561757461}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nPotential improvement:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561825790}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the rule end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561825846}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561825898}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561825980}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at GEN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561878414}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 12 sits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561878459}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561878598}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right edge at cursor"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561878664}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561946416}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extends left"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561946478}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlapping"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561946524}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126561946565}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562008231}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562008311}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" area"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562008365}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" above — fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562008424}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow check the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562106124}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" folio detail crop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562106211}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (11)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562106281}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_38g8u4k6gs6jbqyipd2qnyy2","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562106382}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562106826}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562106933}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107016}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107092}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107169}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107246}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107321}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107630}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107729}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107815}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107899}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562107976}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562112104}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562112189}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562112261}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562112473}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562126469}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562126567}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562126897}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562126980}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562144474}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562144571}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562144655}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562144735}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562145286}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562145417}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562145512}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562145611}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562193220}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562193322}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562193401}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562193481}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562195168}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562195269}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562195347}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562195428}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562197466}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562197583}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562197665}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562197781}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562197952}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562198045}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562198179}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562198274}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562215325}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562215419}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562215516}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562215596}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562229071}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562229159}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562229222}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562229261}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562251659}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562251749}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562251819}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"11"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562251885}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562262297}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ol"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562262356}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"io"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562262437}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562262547}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"etail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562280995}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562281092}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562281171}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":56610,"ts_us":1793126562281265}}

data: {"id":"5becfd682114d3928ec2081ea90007eb","object":"chat.completion.chunk","created":1793126560,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":361689,"completion_tokens":363,"total_tokens":362052,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":360704,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":270,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":56610,"ts_us":1793126562366653}}

data: [DONE]

