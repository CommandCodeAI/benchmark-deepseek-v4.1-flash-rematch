data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918588842}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_0xyv9ns3wiepy1pj4b2j389z","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918636008}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918636063}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918636121}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918656359}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918656433}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918656512}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918656580}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918675590}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918675652}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918675693}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918675854}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918692589}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918692651}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918692799}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918692857}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918715072}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918715131}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918715187}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918715253}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918715449}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918715529}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918715639}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918715717}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918792431}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918792486}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918792561}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918792629}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918812706}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918812871}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918812952}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918813015}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918814157}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918814240}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918814301}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918814361}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918814728}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918814793}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918814834}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918814894}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918818290}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918818343}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918818394}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918818458}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918836635}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918836683}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918836740}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918836879}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918841488}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918841550}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918841607}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918841723}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918850219}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918850299}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/mod"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918850354}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ule"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918850398}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918850998}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"qa"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918851059}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918851163}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918851212}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918862967}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918863019}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918863058}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918863105}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918866919}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918867006}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918867079}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918867134}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918890913}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918890976}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918891025}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918891093}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918938727}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918938792}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918938843}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918938895}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" module"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918975593}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" QA"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918975701}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" against"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918975787}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123918975929}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" modules"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123919003024}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123919003090}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9666,"ts_us":1793123919003149}}

data: {"id":"08768032633e99f462818627362fb9bc","object":"chat.completion.chunk","created":1793123918,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":197725,"completion_tokens":117,"total_tokens":197842,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":192768,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":9666,"ts_us":1793123919009566}}

data: [DONE]

