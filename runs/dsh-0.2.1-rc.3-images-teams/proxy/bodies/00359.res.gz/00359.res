data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365230033}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365281217}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier implemented"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365281283}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record-link"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365281526}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365336200}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ast, shortcut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365336249}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365336305}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", wash. Great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365336364}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365400474}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s check "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365400547}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280 scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365400591}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365400649}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier update;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365499327}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365499378}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" haven't yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365499421}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365500258}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_agents status"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365587613}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"es and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365587660}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe wait. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365588076}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check mtime"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365588895}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of design.css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365672602}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365672669}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_c905m2fxmzm4nu4dx7g635jo","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365672734}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365673024}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365673073}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365673135}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365673217}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365673289}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365678536}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365678587}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365678623}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365680363}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365694841}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365694891}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365695168}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365696204}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365714966}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365715078}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365715125}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365715625}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365737736}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365737807}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365737872}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365738141}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365746657}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365746711}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365746915}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365746960}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365747575}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365747631}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365747669}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365748504}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365764649}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365764743}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365764807}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365764841}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365788892}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365788941}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365788986}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365789066}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365824945}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365825031}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365825097}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365825947}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365826129}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365826185}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365826246}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365826299}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365850296}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365850366}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365850427}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365850480}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365863378}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365863460}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365863697}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365863748}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365900834}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365900931}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365900984}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365901784}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365901834}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365902135}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365902180}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365902828}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365917698}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365917898}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365917949}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365917993}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365937189}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365937529}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365937605}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365937683}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365938307}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365938384}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365938456}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365938522}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365956022}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365956071}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365956122}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125365957061}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366005004}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366005271}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366005328}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366005375}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366011493}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366011797}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366011866}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366011960}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366043613}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" module"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366043665}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" modification"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366043725}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" times"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366044159}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366104105}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366104291}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_3fyqmji2zfcv0m97gn2owwpl","type":"function","function":{"name":"list_agents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366104340}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":36180,"ts_us":1793125366104824}}

data: {"id":"a9245cb6eb17ad43dc97fb1cec5de826","object":"chat.completion.chunk","created":1793125365,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":303065,"completion_tokens":192,"total_tokens":303257,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":301952,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":52,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":36180,"ts_us":1793125366157522}}

data: [DONE]

