data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691520931}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691576598}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read stub"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691576678}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691577253}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_qtmvb5oewmxe4qantgo49j8p","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691612261}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691612387}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691612496}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691612802}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691635401}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691635553}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691635710}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691635760}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691652081}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691652135}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691652386}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691652444}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691653461}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691653888}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691654049}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691654135}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691666991}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691667051}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691667115}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691667179}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691689972}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691690087}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691690222}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691690340}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691690509}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691690619}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691690666}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691690803}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691702633}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691702721}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691702771}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691702868}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691724152}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691724235}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691724526}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691724577}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691729034}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691729265}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691729343}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691729505}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691752452}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691752613}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691752698}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691752827}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691771793}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691771993}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691772132}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691772317}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691772511}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691772597}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691772677}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691772751}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nder"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691801645}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691802351}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691802444}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3372,"ts_us":1793123691802528}}

data: {"id":"fdee39150b53f67b0fbade2b88fc3634","object":"chat.completion.chunk","created":1793123691,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":176438,"completion_tokens":88,"total_tokens":176526,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":161664,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":5,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3372,"ts_us":1793123691847621}}

data: [DONE]

