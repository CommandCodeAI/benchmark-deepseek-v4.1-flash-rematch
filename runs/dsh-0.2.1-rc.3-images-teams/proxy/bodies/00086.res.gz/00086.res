data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123328964170}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329007187}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 598 exact"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329007392}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `     "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329007486}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" age: 0, dir"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329066177}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": angle, cooldown"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329066278}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": K.reproCoold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329066508}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"own, dead: false`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329066554}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329144390}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6 spaces). My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329144584}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" replacement target"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329144719}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329144884}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 6 spaces too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329208320}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? I used `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329208470}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"      co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329208533}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown: K.repro"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329208624}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Cooldown, dead:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329279530}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" false\"` but actual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329279598}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has `age:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329279814}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0, dir: angle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329279859}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", co"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329343349}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oldown..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329343409}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`. Fix."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329343499}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also check baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329343532}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" block"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329431111}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329431198}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"do patch."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329431558}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_697l819fucvc7icrcohbbd6w","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329431616}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329434543}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329434658}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329434946}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329435138}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329449938}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329450034}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329450229}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329450278}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329452314}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329452359}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329452425}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329452475}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329467910}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329468003}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329468092}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329468172}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329486337}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329486508}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329486626}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329486671}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329502142}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329502191}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329502318}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329502466}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329502817}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329502924}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329502986}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329503020}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329521086}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329521148}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329521276}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329521324}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329538898}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329538950}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329539141}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329539381}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329557466}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329557525}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329557565}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329557678}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329557998}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329558068}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329558132}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329558225}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329574689}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329574746}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329574790}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329574961}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329593955}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329594036}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329594105}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329594173}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329594284}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329594353}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329594556}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329594638}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329612293}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329612345}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329612387}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329612429}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329624371}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329624426}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329624466}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329624555}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329624820}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329624899}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329625024}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329625088}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329643945}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329644111}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329644182}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329644239}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"def"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329731443}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329731516}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329731643}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329731708}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"):\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329732119}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329732272}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" global"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329732388}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329732513}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329733483}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329733565}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329733736}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329733801}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329736106}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329736192}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329736377}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329736449}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329737299}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329739116}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329739182}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329739230}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329739575}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329739650}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329739733}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329739829}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329739873}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753330}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753403}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753478}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753538}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753624}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753708}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Share"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753774}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753838}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329753943}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329754007}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329754093}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"47"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329777089}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329777175}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329777236}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329777448}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329784230}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329784306}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Share"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329784446}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329784532}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329784676}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329785077}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329785143}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"46"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329785731}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329803850}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329803944}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" repro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329804017}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329804136}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329825692}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329825775}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329825841}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329825907}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329839763}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329839873}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329839963}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329840076}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329840514}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329840597}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329840875}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329840947}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329861319}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Share"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329861399}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329862016}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329862110}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329877964}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329878053}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"47"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329878141}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329878288}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329879099}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329879175}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329879309}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329879377}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Share"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329895892}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329895969}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329896030}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329896105}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329912123}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"46"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329912235}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329912316}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329912405}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" repro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329912515}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329912590}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329912682}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123329912744}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330101048}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330101124}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330101196}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330101246}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330101317}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330101384}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330101464}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330102357}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330102418}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330102465}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330102507}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330102551}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330102592}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293214}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293272}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293327}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293378}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293454}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293496}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293552}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"75"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293676}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293749}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293811}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293868}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293925}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330293999}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330294049}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330294522}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"340"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330294572}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330294618}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330294666}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330294730}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295434}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295489}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295537}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295577}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"90"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295618}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295669}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295883}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295926}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330295971}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330296025}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330296315}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330296384}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330296435}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330296511}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330296613}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"06"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330296660}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330297254}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330297336}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330297414}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330297502}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330297659}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330297732}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330297789}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330297836}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330298118}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330298199}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"035"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330298262}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330298417}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330298463}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330298510}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330298562}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330298609}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330299318}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330299363}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330299443}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330299520}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330299626}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330299686}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330299738}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330299786}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330300311}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330300380}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330300437}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330300505}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330300718}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330300773}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330300848}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330300920}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330301000}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330301060}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330301107}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"orpor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330301199}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330301269}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330301331}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330301387}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302075}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"62"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302143}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302213}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302284}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302348}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elines"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302437}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302502}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302840}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302887}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" flora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302945}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330302994}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"    "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330303033}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330303139}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330303827}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330303899}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330303958}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330304021}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330304061}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330304120}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330304151}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330304827}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330304891}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330304934}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330305019}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330305076}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330309775}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330309833}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" metabolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330309947}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330310002}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330331497}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330331592}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330331666}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330331759}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330331883}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330331974}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330332050}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330332200}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330354000}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330354095}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"72"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330354164}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330354294}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330365511}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330365660}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330365789}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330365836}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330366147}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330366221}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330366300}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330366370}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330392200}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330392244}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330392466}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330392517}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330403629}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330403678}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330403800}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330403872}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330404907}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330405061}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330405134}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330405293}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" metabolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330420236}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330420289}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330420333}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330420444}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330440723}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330440809}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330440867}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330440900}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330441308}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330441376}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330441620}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330441678}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330478233}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330478279}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330478413}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330478452}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330486121}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330486163}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330486250}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330486292}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330487950}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330487997}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330488086}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330488128}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330491494}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"38"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330491565}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330491670}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330491734}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330504746}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330504810}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330504892}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330504936}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330507414}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330507469}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" metabolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330507581}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330507632}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330520529}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330520576}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330520620}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"06"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330520660}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330541504}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330541584}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330541644}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330541695}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330542760}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330542827}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330542954}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330543029}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330558392}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330558444}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330558550}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330558601}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330575196}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330575294}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330575343}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330575390}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330576453}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330576503}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" make"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330576627}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330576687}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330598139}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330598183}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330598345}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330598419}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330620752}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" species"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330620813}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330620956}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" spread"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330621002}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330634385}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330634432}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330634557}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330634621}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330634889}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elines"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330634983}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330635075}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330635123}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330652555}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" flora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330652601}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330652651}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330652702}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330671206}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330671258}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330671301}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330671446}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330673183}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330673224}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330673339}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330673411}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330689851}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330689903}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330690069}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330690112}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330709034}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330709082}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330709231}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" metabolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330709281}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330710822}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330711007}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330711173}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330711237}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330729034}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330729085}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330729241}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330729289}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330746049}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330746113}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330746253}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"72"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330746295}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330748049}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330748092}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330748212}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330748267}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330771347}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330771405}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330771573}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330771645}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330789802}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330789862}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330789916}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330789994}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330790329}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330790425}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330790530}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330790585}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330797595}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330797638}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330797778}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330797874}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330819459}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330819515}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" metabolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330819673}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330819771}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330819902}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330819954}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330820072}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"00"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330820109}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330847431}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330847657}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330847758}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330848271}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330878228}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330878313}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330878362}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" },\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330878643}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330878686}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330878749}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330878801}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330878859}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330907393}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330907485}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330907535}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330907728}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330907794}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330908844}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330908955}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909097}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"38"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909160}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909280}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909336}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909400}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909451}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909518}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909575}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330909622}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330913489}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" metabolism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330913574}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330913659}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330913704}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330914109}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330914166}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"06"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330914262}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330914304}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" threshold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330933420}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330933502}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330933611}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123330933705}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331008807}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331008863}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331008986}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331009056}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" };\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331009172}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331009239}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331009812}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" base"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331009881}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331042248}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" bas"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331042302}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elines"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331042427}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331042491}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"species"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331059929}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331060020}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331060191}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331060269}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331060412}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331060603}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331060683}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" make"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331060751}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331081451}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331081513}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331081605}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pr"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331081654}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ng"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331081800}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331081848}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" species"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331081890}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331082193}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" spread"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331083563}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331083681}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331083778}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331083830}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331085057}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" base"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331085118}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331085269}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331085323}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331085483}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331085536}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"elines"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331085597}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331085790}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"species"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331088979}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331089025}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331089115}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331089199}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331095783}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331095857}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331095944}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331096034}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331096208}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331096330}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331096461}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331096551}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331118860}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331118932}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331119059}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331119109}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331129836}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331129889}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331129972}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331130116}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331130222}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331130277}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"90"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331130370}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331130439}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331152373}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"340"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331152432}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331152479}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331152578}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331169576}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" crowd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331169622}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331169699}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clamp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331169792}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331188163}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331188252}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331188322}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" alive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331188425}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331188522}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331188617}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331188674}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331188886}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331215569}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331215819}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331215873}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331215921}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"05"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331230898}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331230947}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331230987}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331231046}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331231332}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331231383}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331231588}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331231640}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331254229}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331254283}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331254389}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331254443}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331273897}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331273977}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331274042}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331274146}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331274244}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331274289}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331274406}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331274463}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331290345}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331290394}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"035"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331290434}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331290530}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331306952}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331307024}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331307166}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"06"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331307212}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331307502}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331307553}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" crowd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331307611}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331307724}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331319728}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331319803}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331319860}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331319908}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331340471}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331340523}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331340649}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331340715}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331341665}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331341711}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331341795}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331341868}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331351014}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331351066}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331351130}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331351278}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331369618}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331369690}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331369798}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331369850}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331370796}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331370848}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331370966}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331371013}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331382619}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331382671}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331382756}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331382833}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331400556}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331400630}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331400663}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331400765}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" crowd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331401566}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331401640}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" clamp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331401730}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331401776}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331419147}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331419196}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" alive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331419264}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331419373}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331440074}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" soft"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331440148}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331440271}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331440341}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331440603}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331440672}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331440721}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"05"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331440814}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331448331}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331448383}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331448488}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331448533}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331465465}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331465516}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" chance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331465597}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331465744}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331466435}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331466518}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331466631}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331466685}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331486140}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331486191}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331486239}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331486347}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331505284}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331505332}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331505385}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331505486}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331506193}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331506242}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331506299}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331506356}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331512998}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331513035}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331513133}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331513184}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331532341}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Birth"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331532405}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331532599}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331532647}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331534239}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331534284}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" crowd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331534529}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331534614}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331557200}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331557253}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331557304}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331557410}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331564538}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" agent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331564579}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331564750}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331564810}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331565415}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331565568}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331565746}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331565826}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331584772}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331584841}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331584899}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331584933}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331604848}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331604894}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331604943}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331605012}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"75"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331605249}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331605359}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331605535}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331605583}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331616026}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331616105}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331616148}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331616341}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331630465}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331630511}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331630740}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331630813}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331630960}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" agent"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331631105}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331631171}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331631224}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331646558}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331646609}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331646648}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331646741}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331740336}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331740437}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331740517}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331740597}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331742543}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331742644}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331742899}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331742978}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331744036}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331744121}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331744377}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331744459}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331745503}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331745591}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331745868}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331745966}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331748685}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331748800}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331748889}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331749044}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331752199}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331752356}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331752484}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331752690}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331752785}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331752915}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331753047}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331753132}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331753210}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331753290}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331753554}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331753648}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331754599}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" angle"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331754692}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331754918}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331754991}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331759295}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331759399}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331759672}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331759753}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331759880}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pro"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331760031}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331760120}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331760230}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331784067}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331784161}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331784243}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331784433}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" false"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331801129}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331801227}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331801472}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331801573}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"     "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331801831}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" age"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331801909}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331802130}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331802203}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331818346}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331818441}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331818523}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331818693}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" angle"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331941035}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331941092}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331941129}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331941181}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331941642}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331941703}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331941751}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123331941846}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332015395}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332015449}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332015492}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332015596}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332015639}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332015689}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332015746}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332016142}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332016199}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332016242}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332016283}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332016321}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332019182}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332019241}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332019292}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332019377}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332099883}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332099973}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Co"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332100053}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"old"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332100185}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"own"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332100812}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332100858}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332100905}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332100950}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" false"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332103633}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332103684}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332103833}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332103889}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332105205}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332105342}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332105392}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332105518}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332105969}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332106105}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332106200}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332107097}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332128184}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332128231}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332128273}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332128341}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332147371}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332147419}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332147460}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gain"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332147512}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332147947}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332147995}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332148091}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332148139}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332154658}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332154708}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332154762}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332154893}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332156678}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332156728}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332156776}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332156822}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332157187}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332157308}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332157438}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332157480}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332168666}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332168718}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332168853}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gain"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332168900}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332185636}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332185691}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332185778}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332185824}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332185866}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332185908}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332185948}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332185993}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332186496}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332186559}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332186642}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332186723}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332192667}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332192736}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332192788}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332192899}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332193416}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332193578}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332193639}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" meal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332193759}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332214685}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332214767}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332214846}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332214950}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332232859}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332232918}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332233013}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332233062}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332233608}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332233653}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332233693}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332233732}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cap"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332244831}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332244906}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332244984}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332245038}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332261762}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" +"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332261827}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" meal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332261890}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332261994}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332262636}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332262698}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332262794}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332262828}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332281765}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332281814}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332281939}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fauna"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332281996}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332296656}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332296708}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332296764}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332296848}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332312452}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332312498}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332312606}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332312651}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332313540}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" moved"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332313627}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332313782}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332313853}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332333064}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332333110}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332333151}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332333189}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332346099}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332346148}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332346188}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332346342}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332347294}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332347352}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"62"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332347476}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332347525}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332363393}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332363460}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332363518}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"energy"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332363579}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332384804}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fauna"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332384850}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cost"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332384890}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332384977}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332385543}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332385597}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332385642}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332385705}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332404571}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332404615}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332404660}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" moved"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332404701}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332417655}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" *"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332417704}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332418048}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332418097}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"y"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332419134}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332419182}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332419299}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332419357}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" :"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332439691}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" K"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332439744}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332439772}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332439823}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332470983}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"orpor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332471038}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332471080}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332471125}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332471522}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332471575}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332471621}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332471701}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332493144}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332493197}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332493239}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332493357}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332506735}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332506792}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"parameter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332506851}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ized"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332506938}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" OK"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332507531}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332507565}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332507654}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332507703}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332525415}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332525488}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332525593}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332525655}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332547401}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332547454}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332547492}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332547538}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332565605}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332565732}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332565773}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332565962}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332566540}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332566598}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332566636}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332566685}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332600193}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332600254}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332600306}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332600360}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332616542}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332616592}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332616639}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332616705}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Apply"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332652026}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" parameter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332652108}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ization"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332652224}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" patch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332652314}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332667037}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" smoke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332667084}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332667210}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332667262}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3152,"ts_us":1793123332734126}}

data: {"id":"4f46e60fb504bae12b10a5884765ce12","object":"chat.completion.chunk","created":1793123328,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":144544,"completion_tokens":1143,"total_tokens":145687,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":143872,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":98,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3152,"ts_us":1793123332734231}}

data: [DONE]

