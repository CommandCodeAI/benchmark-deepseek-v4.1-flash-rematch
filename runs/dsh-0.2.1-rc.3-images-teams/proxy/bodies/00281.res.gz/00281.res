data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676331848}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676452105}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" confirms seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676452159}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676452197}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intentional?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676502464}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676502516}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" say \"Default seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676502555}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901\" as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676502614}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fact."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676563834}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Brief requires"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676563883}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676563928}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676564034}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed 1977. This"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676677204}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is a deviation I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676677255}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" must report — but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676677297}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676677344}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aware"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676828187}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (they"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676828240}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mention default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676828301}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 1901). Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676828391}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they deliberately changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676890975}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676891034}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aesthetics."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676891088}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676891132}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" job: flag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676954714}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it as contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676954761}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deviation (major"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676954799}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/major"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676954937}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?) — acceptance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676998766}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checklist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676998836}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676998979}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Seeder"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124676999035}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677058930}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677058978}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677059019}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brackets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677059062}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677123550}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1977\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677123597}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is part of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677123632}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contract table."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677123666}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I'll report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677173222}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as MIN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677173265}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"OR/MED"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677173335}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IUM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677173401}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deviation (not functional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677225086}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" blocker) noting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677225135}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677225199}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s choice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677225248}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but persist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677288555}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677288606}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report because brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677288639}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is explicit. Actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677288707}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677342938}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" message earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677342982}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" said fixes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677343092}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" landing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677343136}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677420892}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677420982}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wasn't justified"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677421181}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". I'll keep flag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677421257}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ging but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677477849}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" severity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677477973}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" minor/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677478046}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ajor?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677478108}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" It's a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677525944}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contract detail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677526037}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" affecting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677526109}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677526266}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism expectations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677584478}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677584530}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"creenshots;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677584571}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also mast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677584614}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"head \"Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677635453}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1977\" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677635506}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in shell gets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677635549}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677635601}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677691404}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot. I'll mark MIN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677691483}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"OR deviation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677691530}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and note Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677691575}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chose"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677731949}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677732020}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677732116}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" intentional,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677732160}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677797995}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brief isn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677798046}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t allowed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677798097}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677798142}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able judged"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677878096}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" against brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677878164}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — so flag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677878230}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n\nAlso Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677878281}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677966876}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"↔b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677966938}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rowser hash mismatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677966996}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" NOT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124677967040}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" product"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678038789}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failure due to cross"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678038850}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-engine FP differences."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678038907}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" My B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678039003}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"19"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678105125}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parity test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678105192}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" compared"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678105258}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" full "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678105351}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40-gen hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678160155}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678160230}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" saw mismatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678160285}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; with `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678160329}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678225517}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=0` and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678225568}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" explicit seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678225635}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678225723}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1977 the *first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678280083}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678280131}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens* matched."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678280168}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Cross-engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678280214}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" FP divergence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678339944}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is plausible ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678340004}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Gaussian"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678340046}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678340091}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Math.exp/log"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678399154}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc.)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678399205}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They ask"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678399247}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678399311}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page reload same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678520954}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed → same hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678521005}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678521057}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678521136}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678608906}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" across processes. Adjust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678608971}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B19 to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678609079}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": \n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678609127}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678661115}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"19a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678661188}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678661249}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-browser determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678661319}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism: same seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678712725}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" twice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678712777}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in page →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678712836}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identical hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678712893}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- B19b: in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678764496}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-browser full run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678764543}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678764616}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reload"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678764696}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678839816}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" identical"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678839904}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash.\n- B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678839972}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"19c: node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678840014}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"↔browser parity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678910408}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678910514}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678910596}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (e.g.,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678910664}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678986130}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens) OR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678986191}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678986306}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124678986355}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679052477}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" equality; if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679052527}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679052564}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run mismatch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679052610}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679123503}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" NOTE not FAIL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679123564}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679123601}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead instructed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679123640}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679206360}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll implement: compare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679206444}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hash after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679206503}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679206546}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 gens; if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679260959}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679261013}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → PASS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679261072}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679261222}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679315697}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"lined verb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679315790}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"atim +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679315992}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" early parity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679316048}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"); full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679374678}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40-gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679374747}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mismatch → note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679374817}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with explanation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679374896}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679433956}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reload determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679434008}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism.\n- Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679434053}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679434114}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679506094}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679506163}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679506220}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679506292}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed? deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679571759}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able DEFA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679571834}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ULTS may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679571895}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be 1901; B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679571935}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679635074}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679635124}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will fail."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679635164}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm — engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679636354}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite loads"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679685975}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" src/engine.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679686058}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679686140}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" currently seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679686209}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901 → B"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679793540}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 fail. Lead intends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679793646}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679793704}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679793774}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" said \"Default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679846713}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 1901\" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679846763}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" brief says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679846803}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1977. I'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124679846880}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report as deviation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680004517}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with severity MIN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680004587}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"OR, and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680004652}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keep test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680004690}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" failing but flag"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680051807}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680051932}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-conf"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680051984}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"irmed intentional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680052054}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680105426}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680105485}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I should not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680105612}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" water"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680105655}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" down contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680211536}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" checks silently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680211600}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Report FAIL with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680211661}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note \"Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680211698}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" states 1901 is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680275049}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliberate; brief says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680275116}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1977 — needs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680275162}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sign"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680275215}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-off or revert"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680358314}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\".\n\nWait: maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680358360}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680358419}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680358469}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed-search and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680414798}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" will revert"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680414856}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680414899}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me ask"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680414958}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" directly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680506339}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in next"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680506403}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" message (short"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680506487}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"):"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680506579}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Confirm "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680557976}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 is intentional vs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680558021}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680558249}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1977 contract"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680558315}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; if intentional"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680610484}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I'll report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680610543}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as deviation.\" \n\nMeanwhile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680610629}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check browser official"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680610759}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run output"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677460}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677512}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yi85fr51271r4d1eq6pfdcfh","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677564}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677619}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677756}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677806}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677865}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677911}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680677963}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678025}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678081}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678142}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678199}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678260}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678319}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"35"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678420}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678529}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678601}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678658}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680678718}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680681205}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fficial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680681275}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680681347}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680681415}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680681749}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680681822}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680681883}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680681934}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680694400}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680694464}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680694660}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680694736}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680708967}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680709050}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680709105}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680709151}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680730516}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680730610}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" official"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680730673}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680730724}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680740975}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" progress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680741067}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680741148}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15179,"ts_us":1793124680741207}}

data: {"id":"1db6245195e2d5a1b602e6edd1e44342","object":"chat.completion.chunk","created":1793124676,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":258455,"completion_tokens":688,"total_tokens":259143,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":256896,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":611,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":15179,"ts_us":1793124680798045}}

data: [DONE]

