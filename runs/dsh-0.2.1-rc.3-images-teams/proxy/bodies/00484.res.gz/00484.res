data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959716814}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rsibhbt8qwwa1ijzo3dmqekc","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959760507}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959760589}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959760646}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959778274}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959778412}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959778581}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959778712}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959795708}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959795786}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959795868}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959795985}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959814387}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959814512}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959814627}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959814675}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959826109}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959826158}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959826227}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959826280}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959853852}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959853970}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959854115}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959854212}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959859549}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959859612}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959860363}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959860430}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959872878}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959872923}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959872990}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959873053}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959894783}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959894836}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959894893}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959895031}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959895546}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959895647}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959895744}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959895798}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959918875}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959918924}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959918971}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126959919034}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960021036}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960021092}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960021206}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960021281}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960081308}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960081365}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960081415}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960081473}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960081730}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960081798}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960081837}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960081939}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960085918}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960085969}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960086017}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960086077}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960087773}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960087819}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960087856}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960088371}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960088855}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960088909}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960089001}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" stat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960089105}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960094918}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960094962}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"%"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960095018}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960095063}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" %"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960095617}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"z"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960095667}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960095800}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960095862}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960097001}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960097121}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960097163}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960097206}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960108613}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960108662}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960108709}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960108805}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960123058}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960123145}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960123233}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960123298}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960123955}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960124158}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960124227}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960124343}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960140011}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960140061}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960140109}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960140156}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960157863}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960157912}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960157954}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960157998}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960198723}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960198786}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960198941}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960199000}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960209910}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960209959}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960210054}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960210137}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960224060}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assembly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960224106}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" after"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960224152}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" wait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960224249}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960312713}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6676,"ts_us":1793126960312771}}

data: {"id":"cc51cf492799b0d7f76cc3d931bd98bb","object":"chat.completion.chunk","created":1793126959,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":350059,"completion_tokens":148,"total_tokens":350207,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":349568,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6676,"ts_us":1793126960312847}}

data: [DONE]

