data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048285221}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048421588}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0×800 looks good and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048421634}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fits without"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048421684}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll. Issues at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048486542}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" this size:\n\n1. **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048486587}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Summary card"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048486631}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** clipped at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048486685}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom: \"STAND"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048553413}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ING / All three"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048553467}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kingdoms persisted to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048553502}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G40.\" appears"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048553984}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but the card"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048613918}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom edge is at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048613965}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y≈352"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048614004}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and standing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048614040}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048666575}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048666646}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y≈336"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048666701}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-343"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048666756}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fits?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048743351}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The card bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048743406}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" border"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048743457}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seems at 352"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048743512}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; standing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048798187}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048798263}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good. But check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048798323}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048798381}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048868161}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048868235}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clipped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048868291}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" slightly ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048868336}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"the standing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048940457}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048940535}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048940605}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124048940675}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049007615}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to measure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049007758}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049007835}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Fairly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049007911}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049068065}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but readable."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049068148}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" However"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049068214}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **chart figure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049068278}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" captions**"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049144814}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 1280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049144889}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": \"FIG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049144945}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 2 Census"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049144995}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of the three"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049197562}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" kingdoms ..."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049197622}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049197730}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049197830}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with weather marks\" fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049275842}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Dr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049275927}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ift caption \"FIG"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049275980}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 3–14"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049276036}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Dr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049341503}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ift at the four"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049341562}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loci\" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049341605}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sub right —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049341664}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049393311}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n3. **Trait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049393368}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" matrix"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049393417}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 1280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049393452}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**: rows ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049455378}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"86px tall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049455436}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049455481}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049455526}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels small but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049522195}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" legible. Row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049522251}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049522520}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049522594}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Expression notes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049573904}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" readable. Column"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049573962}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headers now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049574049}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049574093}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"if roman"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049649878}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" numerals — \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049650053}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"I ·"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049650097}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" SPEED\" looks elegant."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049650136}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓\n\n4. **C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049700606}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ensus**: end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049700657}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels now not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049700693}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clipped: \"141"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049700731}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HERBIV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049835590}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ORA\", \"133 FL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049835640}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ORA\", \"6 CARN"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049835675}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVORA\" ✓. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049835717}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels are"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049890760}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" close to the weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049890804}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels column"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049890856}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049890901}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049948104}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049948162}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n   - The end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049948191}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124049948270}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlay the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050012568}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050012605}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" margin; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050012646}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280, the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050012681}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050091711}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" margin "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050091770}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100 → labels fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050091817}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050091895}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050149187}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count text \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050149255}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"141\" + name"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050149306}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050149359}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ✓"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050211719}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\n   - The \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050211792}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050211862}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" WE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050211940}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATHERS\" at top right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050281887}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sits above"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050281972}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels nicely.\n\n5."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050282033}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **Summary**: weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050282078}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chips "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050334895}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2 lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050334956}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", stats,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050334992}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. Still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050335032}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050386655}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay.\n\n6."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050386731}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **Notes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050386783}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" strip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050386814}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**: 3 columns"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050447411}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fit; weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050447462}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" roster line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050447590}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" readable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050447634}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050532951}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px mono;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050533018}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" margin note italic;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050533116}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drawn from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050533184}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed.\n\n7. **Footer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050586291}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050586364}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\n8. The bottom of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050586452}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sheet at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050586490}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y≈777"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050653751}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", top"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050653798}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 13; good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050653888}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBut it looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050653934}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like the record sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050722399}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050722442}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom padding too"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050722490}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small (footer at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050722527}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 772, sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050772901}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050772950}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 777) fine.\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050773014}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check extinct &"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050773075}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dense."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050840785}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_tiu4qx9cjkirz8vzr2b9gzmr","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050840848}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050840911}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841056}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841128}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841195}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841261}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841330}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841412}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841477}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841551}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841648}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841717}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841757}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050841912}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842027}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842103}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842179}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842256}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842328}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842379}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842452}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842511}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842578}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842616}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842666}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842713}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050842751}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050855126}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050855192}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050855267}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050855329}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050856450}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050856507}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050856682}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050856755}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050857218}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050857283}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050857340}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050857389}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050859947}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050860026}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050860080}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050860145}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050878614}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050878668}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050878756}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050878845}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050879233}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050879278}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050879324}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050879364}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050894951}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050895006}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050895055}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050895096}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inct"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050953223}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050953305}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050953368}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22786,"ts_us":1793124050953429}}

data: {"id":"0ccbbf0673d91a4b66ce13218a808dcc","object":"chat.completion.chunk","created":1793124048,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":191453,"completion_tokens":503,"total_tokens":191956,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":190336,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":416,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":22786,"ts_us":1793124050988788}}

data: [DONE]

