data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859580418}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_bg4fw2zybedp19k03cjue49s","type":"function","function":{"name":"job_output"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859631461}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859631534}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859631621}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"job"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859643300}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859643376}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859643446}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859643549}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859666078}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859666178}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859666255}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859666331}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859684401}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859684461}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859684541}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859684629}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859699602}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"063"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859699676}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"747"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859699737}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859699795}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859757877}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859757965}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9900,"ts_us":1793123859758037}}

data: {"id":"81e712264b98bc299c23b610dcbdaad4","object":"chat.completion.chunk","created":1793123859,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":191024,"completion_tokens":50,"total_tokens":191074,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":190080,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":9900,"ts_us":1793123859765724}}

data: [DONE]

