data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352052832}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352231169}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352231215}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able confirmed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352231287}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sha f820f20a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352278912}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 321"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352279034}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352279152}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"258 bytes (313.7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352279199}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"KB), mtime "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352322399}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"23:54:08."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352322558}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Matrix started"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352322599}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWhile final runs (~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352322694}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3min), monitor."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352384833}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Step 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352384883}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine ~72"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352384925}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s. Let me wait and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352386162}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check engine log"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352431389}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352431528}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_jmclv64kr9ffv18imm09ddkh","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352431598}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352431753}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352431886}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352431945}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432060}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432136}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432215}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432276}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432317}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"80"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432361}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432417}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432468}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432609}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432694}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432849}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432901}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352432973}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352433086}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352450688}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352450869}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352450917}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352451017}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352474438}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352474614}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352474687}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352474827}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352482461}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352482663}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352482742}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352482808}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352541522}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352541773}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352541863}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352542043}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352542212}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352542297}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352542482}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352542649}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352542836}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352543033}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352543220}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352543422}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352543555}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352543747}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352543979}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352544197}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352548883}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352548975}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352549231}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352549445}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352566519}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352566617}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352566713}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352566797}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352582660}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352582756}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352582966}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352583154}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352606922}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352607011}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352607256}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352607336}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352612953}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352613190}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352613419}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352613508}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352613796}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352613980}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352614157}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352614351}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352631138}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352631324}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352631589}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352631668}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352644228}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352644325}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352644510}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352644689}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352659027}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352659119}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352659298}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352659497}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352678533}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352678611}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352678670}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352678735}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352679410}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352679477}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352679640}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352679703}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352691854}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352691926}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352692055}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352692131}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352709552}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352709704}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ==="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352709821}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352709898}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352710329}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352710483}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352710618}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352710686}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352725063}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352725122}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352725237}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352725350}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352745535}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352745591}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352745631}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352745716}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352755902}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352755986}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352756103}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352756221}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352777814}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352777955}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352778033}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352778171}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352804409}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352804567}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352804695}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352804786}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352836879}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352836929}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352836975}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" progress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352837092}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352931145}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6394,"ts_us":1793127352931208}}

data: {"id":"452c286ced9f38cd4712e894f0286f24","object":"chat.completion.chunk","created":1793127351,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":363353,"completion_tokens":222,"total_tokens":363575,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":362368,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":59,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6394,"ts_us":1793127352931372}}

data: [DONE]

