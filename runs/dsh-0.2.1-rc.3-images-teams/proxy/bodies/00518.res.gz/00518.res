data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127538935534}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539089942}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" log still empty because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539090086}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539090174}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite prints at end only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539150007}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539150091}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"and writes progress"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539150159}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nowhere"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539150228}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). It started"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539199975}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539200321}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539200376}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"static (~85"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539200430}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s), so ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539252164}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539252209}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s into browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539252256}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539252686}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ne"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539361101}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"eds ~95"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539361473}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-110"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539361567}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s). Wait more."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539361625}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_wrmhfo7ivx8qttq6ztpcyaii","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539361671}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539361733}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539361822}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539361888}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362079}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362130}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362190}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sleep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362263}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362329}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"55"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362392}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362453}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362520}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362586}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362654}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362705}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362765}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362872}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362913}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539362980}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539363033}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539363095}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539363144}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539363199}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539363247}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539386345}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539386412}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539386522}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539386587}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539409134}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539409181}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539409253}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539409326}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539409383}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539409494}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539409552}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539409652}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539441928}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539441994}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539442220}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539442264}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539479183}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539479283}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539479480}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539479563}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539479635}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539479703}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539479896}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539480039}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539514323}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539514399}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539514739}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539514843}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539514914}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539514975}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539515038}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539515098}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539526394}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539526464}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539526499}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"FAIL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539543787}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539561112}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"note"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539561197}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539561336}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539561388}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539606895}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539606945}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539607050}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"F"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539607116}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INAL"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539607585}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539607647}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ONE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539607704}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539607760}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539613232}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539613340}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539613407}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539613495}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539626141}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539626212}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539626272}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539626330}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539636546}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539636626}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539636703}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539636771}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539637143}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539637202}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539637374}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"14"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539637432}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539676196}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539676279}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539676348}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539676409}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539677856}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539677900}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539678117}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539678188}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539725739}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539725814}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539725879}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539725946}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539726009}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539726074}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539726135}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539726196}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539745912}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539745961}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539746019}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539746089}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539755959}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539756034}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539756098}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539756145}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539783795}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539784047}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539784095}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26155,"ts_us":1793127539784135}}

data: {"id":"c96f58da6f888518263c286019d8e2af","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":364531,"completion_tokens":197,"total_tokens":364728,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":364032,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":46,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":26155,"ts_us":1793127539869379}}

data: [DONE]

