data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888102798}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_x1p9pkkq1lj0v5h88k25e8g2","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888113007}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888113063}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888113314}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888114204}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888114281}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888114338}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888114386}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888115554}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888115713}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888115791}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888117029}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888117997}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888118074}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888118121}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888118162}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888128854}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888128916}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888128999}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888129072}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888129828}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888129876}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888129918}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888129982}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888149852}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888149898}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888149948}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888149987}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888184490}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888184560}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888184650}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888184702}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888186384}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888186447}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888186499}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888186540}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888188989}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888189032}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888189073}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888189128}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888214682}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888214755}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888215475}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888215554}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888227345}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888227415}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888227487}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888227569}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888228214}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888228276}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888228385}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888228488}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888249586}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888249636}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888249676}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888249717}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888265741}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"09"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888265819}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888265885}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888265947}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888344316}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888344375}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":49420,"ts_us":1793125888344438}}

data: {"id":"e5e980125d5fbeacaaa851d6dfe5feaf","object":"chat.completion.chunk","created":1793125888,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":352536,"completion_tokens":90,"total_tokens":352626,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":347648,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":49420,"ts_us":1793125888351580}}

data: [DONE]

