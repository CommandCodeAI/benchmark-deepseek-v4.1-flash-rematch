data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551250982}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551293401}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no longer has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551293517}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859 because I replaced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551293661}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"seed:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551377979}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 185"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551378049}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9\" earlier maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551379721}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551379882}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" present. Engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551454085}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line 79"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551455125}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551455239}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Update to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551455285}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551504919}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1. Boot doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551505929}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t hardcode seed;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551506044}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551506122}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551543778}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ENGINE default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551544722}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" used. Good. Update engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551544862}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551544994}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_mpl95eyylhn4ncky4i6y1xos","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551585677}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551586701}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551586796}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551586887}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551603971}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551605000}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551605086}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551605136}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551618125}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551619192}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551619306}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551619431}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551642076}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551643090}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551643193}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551643245}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551658737}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551659864}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551659966}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551660094}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551682300}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551683275}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551683364}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551683467}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551701359}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551702334}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551702447}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551702527}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551702623}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551702721}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551711794}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551711892}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551718920}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551719912}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551720037}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551720216}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551740473}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551741532}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551741652}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551741707}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551747419}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551747499}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551747662}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551747715}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551760459}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551776439}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551776529}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551776575}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551779913}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551781411}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551781544}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551781577}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551803444}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551803523}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"i"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551805188}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ''"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551805247}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551805335}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551805406}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551805556}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551805601}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551822262}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551822322}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551824073}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551824195}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551845386}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551846338}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551846444}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551846573}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551846650}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551846717}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551846781}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551846841}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551865522}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551866327}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551866418}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551866511}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551880489}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551880624}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551881947}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551882053}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551882253}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551882391}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551882536}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551882639}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551899981}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551900719}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551900877}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551901041}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551916985}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551917665}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551917872}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551917949}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551920921}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551921034}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551921161}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assemble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551921268}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551937514}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551937594}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551938379}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551938469}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551954589}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551954990}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551955072}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551955163}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551957926}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551958001}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551958129}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"quiet"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551958175}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551968557}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551969003}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551969127}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551969232}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551986374}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551986755}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551986869}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124551986988}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552003467}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552003563}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552004251}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552004328}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552004411}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552004505}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552007759}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552007838}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552025390}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552025593}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552025727}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552025874}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552042631}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552042683}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552042734}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552042788}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552044242}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552044349}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552044443}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552044492}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552065192}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552065591}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552065757}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552065832}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552082642}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552082722}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552083313}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552083419}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552083536}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552083630}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552083764}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552083810}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552100584}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552101054}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552101208}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552101297}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552121053}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552121108}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552121566}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552121730}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552138965}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552139295}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552139380}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552139470}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552141909}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552141970}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552142056}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552142181}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552158253}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552158350}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552158447}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552159253}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552179820}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552179879}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552180398}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552180489}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552181911}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552182016}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552182127}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552182231}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552201037}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552201398}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552201515}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552201636}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552220830}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552220931}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552221585}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552221635}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552241279}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552241334}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552241862}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552241964}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552262669}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552262989}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552263177}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552263327}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552265284}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552265443}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552265741}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552265825}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552314992}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552315321}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552315500}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552315662}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552346274}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552346673}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552346872}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552347014}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552348814}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552348925}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552349121}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552349205}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"22"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552349387}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552353285}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552353373}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552353457}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552353532}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552353614}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552353691}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552353788}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552355943}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552356145}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552356334}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552356434}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552370056}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552370255}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552370581}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552370766}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552391791}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552392070}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552392243}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552392372}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552427358}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" capture"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552427775}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552427868}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" correctly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552427952}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552520273}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6278,"ts_us":1793124552520353}}

data: {"id":"2d15ab6fd2185052ea609fd9e7581322","object":"chat.completion.chunk","created":1793124551,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":263593,"completion_tokens":322,"total_tokens":263915,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":263296,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":53,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6278,"ts_us":1793124552520811}}

data: [DONE]

