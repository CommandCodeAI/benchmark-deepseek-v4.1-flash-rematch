data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295666461}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"atel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295783046}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ier task"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295783117}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" completed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295783203}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", chartwright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295844076}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" completed; Lead running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295844125}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295844169}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295844228}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preparing final assembly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295911263}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295911314}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295911383}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295911455}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMeanwhile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295979969}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", let me run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295980014}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the latest preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295980065}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127295980143}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (final src"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296027957}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296028003}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite to confirm design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296028038}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296028099}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 23:47 doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120381}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t break anything. Start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120447}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120494}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_3pq2y8yov2ns2g2zqlkx7sfv","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120577}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120647}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120709}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120763}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120808}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120865}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296120914}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121362}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121416}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121452}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121501}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121545}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121591}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121683}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121740}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121786}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121834}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121898}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296121938}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296122046}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296122083}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296132209}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296132270}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296132308}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296132350}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296150262}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296150310}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296150373}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296150430}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296152394}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296152441}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296152499}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296152566}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296167922}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296167987}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296168037}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296168090}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296180330}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296180380}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296180434}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296180477}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296196682}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296196742}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296196796}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296196868}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296197066}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296197128}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296197264}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296197348}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296210407}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296210506}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296210597}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assemble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296210676}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296229399}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296229475}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296229524}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296229596}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296246622}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296246670}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296246711}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-integ"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296246801}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296270071}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296270120}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296270251}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296270312}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"quiet"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296270749}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296270837}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296270907}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"VER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296271878}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IFY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296275149}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_P"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296275220}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"AGE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296275276}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296275304}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296289589}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296289640}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296289682}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-integ"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296289779}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296290265}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296290332}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296290379}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296290408}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296304577}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296304624}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296304670}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296304714}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296324374}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296324418}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296324462}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296324503}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296324962}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296325005}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296325060}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296325110}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296343639}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296343684}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296343729}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296343775}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296358711}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296358783}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296358843}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296358899}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296359711}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296359764}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EX"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296359796}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296359846}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" $"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296379819}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296379902}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296379965}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296380111}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296393113}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296393188}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296393238}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296393282}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296393696}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296393754}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296393802}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296393848}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296423109}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296423171}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" started"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296423221}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296423274}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"review"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296440160}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296440212}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296440284}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296440359}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296452217}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296452265}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296452390}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296452472}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296469071}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Validate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296469135}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296469249}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296469299}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" preview"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296586002}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296586074}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":26834,"ts_us":1793127296586138}}

data: {"id":"fb2ba34c6ddc4835559689b398ff7a96","object":"chat.completion.chunk","created":1793127295,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":361806,"completion_tokens":225,"total_tokens":362031,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":360064,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":54,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":26834,"ts_us":1793127296587868}}

data: [DONE]

