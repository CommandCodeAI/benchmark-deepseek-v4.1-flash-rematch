data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712588087}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"I'll start by reading the","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712588135}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" design brief and the source","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712588338}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" files I need","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712680913}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" to work with","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712681002}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712681048}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_14qefrrm46b8og3t2h95ke77","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712681582}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712681712}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712681779}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712681969}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712682034}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712682089}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712682129}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712683253}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712683380}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712686066}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712686175}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712686396}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712686576}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712686967}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712687028}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712687158}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712687655}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712707909}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712707975}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712708024}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712708137}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712730179}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712730241}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712730328}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712730505}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712736081}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712736196}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712736273}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712736409}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712752812}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712752909}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712753022}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712753226}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712753850}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712753909}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712754097}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712754156}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712772322}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712772433}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712772512}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712772696}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712785508}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712785704}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712785782}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712785938}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712786460}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712786508}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712786547}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712786660}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712805726}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/D"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712805871}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ES"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712805943}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IGN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712806038}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712823150}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712823217}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712823274}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712823364}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712883223}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712883289}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"id":"call_01_utgi1oewmxhavvz1b08lhvf5","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712883354}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712883417}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712895612}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712895768}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712895844}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712895972}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712913622}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712913820}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712913868}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712913954}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712914214}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712914413}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712914644}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712914802}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712933989}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712934114}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712934209}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712934272}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712951460}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712951541}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712951857}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712951922}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712981081}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712981735}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712981895}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712981954}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712982056}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712982303}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712982420}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122712982564}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122713017346}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122713017413}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"List"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122713017462}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122713017517}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"dir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122713078069}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":" contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122713078186}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122713078246}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":1,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1042,"ts_us":1793122713080803}}

data: {"id":"53afef848e32b222af76eba6ce7b1f73","object":"chat.completion.chunk","created":1793122712,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":7908,"completion_tokens":166,"total_tokens":8074,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":6144,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1042,"ts_us":1793122713082225}}

data: [DONE]

