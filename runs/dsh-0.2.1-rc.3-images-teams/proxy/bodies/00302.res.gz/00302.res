data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888675353}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_s0fu17du55c06yzdgyl5jsv1","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888718315}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888718413}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888718473}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888734996}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888735061}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888735110}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888735206}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888751500}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888751592}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888751645}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888751752}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888771321}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888771415}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888771500}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888771589}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888786947}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888787029}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888787091}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888787167}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888805804}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888805908}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888805999}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888806061}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888806158}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888806236}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888806282}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888806352}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888821224}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888821299}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888821359}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888821444}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888837599}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888837678}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888837791}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888837888}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888838063}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888838146}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888838214}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888838293}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888855273}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888855327}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888855369}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888855439}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888869447}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888869505}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888869690}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888869746}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888870389}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888870436}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888870487}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888870538}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888885973}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888886054}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888886107}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888886192}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888900522}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888900584}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888900627}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888900667}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888965507}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":41521,"ts_us":1793124888965622}}

data: {"id":"2ad1106152a778a8b8bc831bc3fa643e","object":"chat.completion.chunk","created":1793124888,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":222912,"completion_tokens":89,"total_tokens":223001,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":222592,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":41521,"ts_us":1793124888965775}}

data: [DONE]

