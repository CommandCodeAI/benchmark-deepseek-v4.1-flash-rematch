data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123452909401}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_c3xnr1w13pwp2vb9xs36o7p2","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123452966412}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123452966480}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123452966527}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123452979937}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123452980005}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123452980050}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123452980164}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453013285}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453013378}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453013445}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453013510}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"wd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453013810}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453013855}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453016127}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453016172}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453034176}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ME"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453034224}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453034383}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Applications"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453034452}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453057572}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453057651}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453057687}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".app"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453057743}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453057879}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Contents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453057985}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/M"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453058089}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ac"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453058172}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453068554}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453068606}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Google"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453068643}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Chrome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453068687}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453079226}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453079281}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"$"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453079317}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"CH"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453079480}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453093163}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ME"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453093245}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453093307}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453093366}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453093887}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453093958}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453095437}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453095520}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"disable"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453111327}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453111383}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"pu"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453111432}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453111497}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453123477}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453123545}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453123617}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"box"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453123681}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453141696}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"user"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453141751}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-data"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453141821}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453141870}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ir"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453142272}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453142323}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453142431}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453142475}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rome"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453156274}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453156416}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453156495}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453156589}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453169848}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453169928}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hide"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453169996}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453170100}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"roll"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453204396}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bars"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453204474}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453204563}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"window"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453204610}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-size"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453204736}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453204780}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453204914}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453204991}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453205966}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453206041}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453206134}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"force"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453206273}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453221768}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ice"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453221821}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-scale"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453221870}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-factor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453221975}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453273841}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453273896}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453273939}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453274011}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"creenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453351721}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453351776}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453351819}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453351863}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453352727}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453352786}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453352920}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453352968}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453375729}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453375803}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"virtual"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453375855}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-time"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453375919}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453380043}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"udget"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453380101}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453380226}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"400"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453380416}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453387762}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453387883}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453387968}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453388088}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453400459}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453400616}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453401453}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453401501}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453401550}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453401649}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453401772}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453401828}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453416000}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453416049}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453416084}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453416198}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453434436}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453434481}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453434529}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453434616}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453440017}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453440072}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453440123}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453440185}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453441178}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453441236}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453441360}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453441429}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453445226}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453445279}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453445393}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453445490}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453453210}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453453323}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453453426}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453453499}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453453593}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453453644}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453453686}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453453733}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453458656}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453458734}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453458892}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453458951}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453475554}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453475614}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453475647}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453475769}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453488505}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453488577}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453488660}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453488733}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453489670}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453489722}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453489765}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453489817}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453538884}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453538955}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453539021}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453539129}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453539247}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453539414}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453539542}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453539672}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453545953}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453546001}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453546170}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453546286}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453562774}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453562861}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453562926}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453563126}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453563266}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453563389}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453563492}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453563563}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453601542}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453601608}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453601650}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453601740}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453618967}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453619019}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453619087}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453619159}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453654086}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"First"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453654193}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453654280}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453654367}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" screenshot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453655242}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" of"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453655424}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453655598}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" harness"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453655770}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453724819}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1886,"ts_us":1793123453724919}}

data: {"id":"64a6f8a3d03d9dd1e2f903f8fdc381d0","object":"chat.completion.chunk","created":1793123452,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":136547,"completion_tokens":232,"total_tokens":136779,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":136192,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1886,"ts_us":1793123453725074}}

data: [DONE]

