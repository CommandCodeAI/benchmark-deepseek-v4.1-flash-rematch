data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506021860}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_1akcxzbgtudbmvhppu9hl0pn","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506078275}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506078332}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506080112}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506123436}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506123489}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506123541}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506123614}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506147896}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506147942}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506147995}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506148040}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506168303}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506168365}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506168422}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506168798}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506191169}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506191215}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506191265}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506191313}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506207848}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506207897}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506207944}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506207988}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506209039}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506209095}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506209242}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506210149}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506297075}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506297164}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506297240}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506297324}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506297420}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506297494}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506297568}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506297648}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298030}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298121}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298217}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298290}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298360}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298428}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298497}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298567}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298664}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298753}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298827}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506298898}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506299221}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506299310}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506299385}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506299457}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506301415}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506301799}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506301859}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506301940}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506319556}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506319637}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506319721}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"el"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506319797}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"abels"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506319955}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506320030}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506320137}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506320202}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506398653}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506398743}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":55376,"ts_us":1793125506398810}}

data: {"id":"b78eeef0adcdc5a076471ed635ba9ec2","object":"chat.completion.chunk","created":1793125505,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":241644,"completion_tokens":94,"total_tokens":241738,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":240896,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":55376,"ts_us":1793125506405082}}

data: [DONE]

