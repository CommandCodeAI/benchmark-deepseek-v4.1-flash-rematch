data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654287086}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_uazrtdsql2popjzupsmn6vaw","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654326033}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654326094}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654326362}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654334504}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654334569}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654334619}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654334680}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654363728}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654363790}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654363838}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654363878}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654402065}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654402121}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654402168}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654402260}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654403217}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654403461}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654403536}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654403597}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654410894}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654410939}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654410978}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654411268}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654411349}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654411453}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654411570}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654411659}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654418628}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654418673}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654418717}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654418758}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654463959}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654464052}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654464106}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654464194}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654464384}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654464426}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654464473}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654464560}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654478444}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654478516}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654478669}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654478728}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654502513}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654502563}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654502614}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654502663}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654513974}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654514034}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654514080}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654514158}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654533208}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654533254}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654533316}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654533368}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"700"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654544808}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654544860}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"760"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654544901}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654544966}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654562025}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"153"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654562080}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654562198}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654562255}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"164"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654576218}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654576286}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654576383}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654576432}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654602417}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654602468}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654602509}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654602549}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654651774}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654651847}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654652001}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654652056}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654653501}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654653571}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654653680}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654653729}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" dashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654663610}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sizing"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654663702}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654663755}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" render"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654663796}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entry"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654718421}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654718485}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3355,"ts_us":1793123654718521}}

data: {"id":"f0e74a6af0d62df5bee95c84fd2f0e88","object":"chat.completion.chunk","created":1793123654,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":177646,"completion_tokens":121,"total_tokens":177767,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":176256,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3355,"ts_us":1793123654723639}}

data: [DONE]

