data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924089116}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_j88irvwrn5715odwhaz7041t","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924119645}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924119702}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924119744}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924137621}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924137673}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924137911}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924137965}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924150463}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924150518}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924150727}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924150773}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924163927}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924164478}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rule"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924164521}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924164616}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924238140}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16043,"ts_us":1793124924238193}}

data: {"id":"be96432bcf7ef82e3277df97d837acc5","object":"chat.completion.chunk","created":1793124923,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":278127,"completion_tokens":45,"total_tokens":278172,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":276864,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":16043,"ts_us":1793124924238309}}

data: [DONE]

