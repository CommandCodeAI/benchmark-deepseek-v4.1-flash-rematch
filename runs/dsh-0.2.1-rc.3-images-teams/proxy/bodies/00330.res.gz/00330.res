data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121345315}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yz4x6qa8qgkutzb86iwlzk3u","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121393484}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121393537}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121393598}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121408144}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121408205}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121408272}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121408343}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121420183}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121420234}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121420329}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121420411}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121435088}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121435138}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121435747}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121435789}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121451250}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121451317}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121451395}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121451444}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121452090}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121452137}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121452223}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121452318}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121477408}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121477462}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121477531}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121477667}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121497667}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121497736}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121497803}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121497891}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121497997}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121498049}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121498126}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121498196}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121511218}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121511261}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121511301}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121511340}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121529746}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121529799}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121529854}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121529939}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121545480}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121545535}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121545594}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121545644}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121545827}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121545884}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121545937}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121545968}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121561137}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121561216}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121561284}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121561345}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121574860}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"128"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121574939}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121575009}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121575056}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121641956}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43724,"ts_us":1793125121642029}}

data: {"id":"7a23ca0c78e88b74ca7ffd13a3591e6e","object":"chat.completion.chunk","created":1793125121,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":233235,"completion_tokens":89,"total_tokens":233324,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":231680,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":43724,"ts_us":1793125121642125}}

data: [DONE]

