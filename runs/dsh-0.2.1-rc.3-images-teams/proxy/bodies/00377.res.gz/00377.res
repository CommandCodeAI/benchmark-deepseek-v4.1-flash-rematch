data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564020295}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564118056}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end labels are actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564118148}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" well-sp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564118218}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aced: HER"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564257295}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"BIVORA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564257357}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 154, FLORA /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564257406}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" EXTINCT G99"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564257443}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", CARNIV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564306831}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ORA / EXTINCT G70"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564306884}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". No overlap"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564307127}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good. The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564307186}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564352055}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564352119}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564352993}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564353034}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564421441}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564421484}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"x just looked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564421523}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crowded.\n\nOne"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564421557}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue: the labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564480183}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564480229}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" partly *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564480268}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inside* the plot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564480331}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564538239}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they're in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564538284}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the right margin beyond plot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564538331}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edge (the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564538374}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564588633}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" right frame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564588704}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at ~x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564588765}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564588822}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4; labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564647539}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" start ~x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564647590}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=1014"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564647635}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). The flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564647679}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/c"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564732064}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"arnivora labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564732120}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564732170}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564732214}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are at the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564808180}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" very"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564808229}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom, close"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564808274}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564808547}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-axis labels but outside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564856925}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plot. Fine.\n\nBut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564856968}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": the labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564857007}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stack"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564857097}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564941638}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-up"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564941694}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564941741}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125564941782}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HER"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565029740}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"BIVORA 154 is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565029815}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" above;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565029898}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" vertical spacing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565029984}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~28"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565145958}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px; fine.\n\nNow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565146006}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the trait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565146054}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" crop."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565146102}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8r0vs9fmqztyl86r86uin8we","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565156390}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565156441}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565156482}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565156543}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565172515}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565172565}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565172610}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565172658}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565173114}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565173165}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565173206}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565173248}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565184296}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565184351}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565184400}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565184465}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565202070}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565202123}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565202164}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565202241}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565221675}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565221750}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565221799}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565221861}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565225309}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565225415}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565225491}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565225561}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565232931}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565232981}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565233018}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565233093}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565260809}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565260879}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565260925}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565260977}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565278124}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565278171}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565278275}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565278315}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565284665}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565284794}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565284898}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565284953}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565376239}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565376342}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565376432}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565376518}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565376587}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565376682}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565376757}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565376835}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377043}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377153}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377246}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377330}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377462}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377574}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"et"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377672}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rait"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377775}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377859}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565377948}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565378066}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565378191}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565459770}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":52440,"ts_us":1793125565459870}}

data: {"id":"b68b12ea03830940fc95a7c8a4fcac5b","object":"chat.completion.chunk","created":1793125563,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":242285,"completion_tokens":251,"total_tokens":242536,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":241536,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":157,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":52440,"ts_us":1793125565460035}}

data: [DONE]

