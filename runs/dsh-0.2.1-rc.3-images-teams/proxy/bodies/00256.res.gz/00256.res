data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491008474}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491065085}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rome-ac"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491065133}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"curate best showcase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491065283}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": seed 81 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491125409}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"final 669"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491125456}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/140/30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491125561}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491125810}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" range 131"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491221021}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–900, herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491221097}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 66"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491221382}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–195, carn 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491221422}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–52, all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491261872}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3 events with wildfire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491261910}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491262039}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plague 16,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491262090}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drought 24, plague"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491320955}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 32) —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491321013}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" excellent. Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491321111}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 143 also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491321310}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good (772/185"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491387140}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/53, flora min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491387231}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 186 max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491387364}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 983, events drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491387548}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/wildfire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491496023}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/plague/w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491496065}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ildfire, div"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491496301}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .49). Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491496421}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491531470}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 (534"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491531582}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491531790}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/41, flora min "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491531828}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"417 stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491601444}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", events all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491601490}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" three),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491601586}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 188"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491601733}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (848"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491669214}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/149/45"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491669308}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491669553}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491669613}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora 495, all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491738385}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" types),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491738500}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 172,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491738618}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491738762}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 96,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491812867}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2025,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491813024}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1912 also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491813670}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good.\n\nA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491813711}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"est"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491871853}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hetically thematic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491871894}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491872170}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 188"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491872213}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 (not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491958957}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tested in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491959059}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome; node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491959226}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gave 131"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124491959413}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"9/127"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492043068}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/48). Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492043154}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 81 is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492043222}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not memorable but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492043288}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Spec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492104350}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"imen No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492104667}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 0081"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492104739}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492104837}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492176913}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Seed 143"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492177198}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492177250}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The mast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492177292}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"head observation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492246310}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492246715}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". 0047 static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492246824}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; seed 81 displays"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492247003}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"81"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492315441}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"; smaller than "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492315484}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4-digit. Could format"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492315667}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed display"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492315900}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 4-digit \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492381824}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0081\". At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492381918}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier's seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492381981}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" input value"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492382275}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 81; maybe we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492449254}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492449332}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492449572}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed to "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492449619}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492532164}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492532232}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 188"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492532370}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492532423}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-digit,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492634130}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks archival"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492634255}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492634349}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901: final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492634581}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 534"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492663613}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/144/41,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492663735}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora range"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492663840}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 417–128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492663975}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5, herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492735323}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 79"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492735438}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–215, carn 20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492735646}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–59, events plague"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492735824}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/wild"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492803999}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fire/drought/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492804050}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"plague ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492804130}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"all 3), diversity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492804429}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" .43"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492890981}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". This is a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492891072}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" polished, stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492891280}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run with "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492891458}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4-digit seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492929822}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", and \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492929944}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901\" is period"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492930123}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-appropriate. Flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124492930461}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" never"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493002210}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" collapses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493002254}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (min 417"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493002294}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493002339}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more gentle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493076855}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but still cycles"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493076977}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Pred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493077086}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ator goes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493077127}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 59 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493150181}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493150460}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 41. Great. Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493150528}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 188: final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493150611}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 848/149"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493224544}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/45, flora 495"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493224675}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–1059, herb "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493224862}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"84–164, carn "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493224903}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20–51, events wildfire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493282199}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",pl"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493282445}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ague,drought,plague"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493282489}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; stable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493282843}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; three-digit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493350706}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493350805}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493350985}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901 seems"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493351013}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ideal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493413552}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": lush"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493413642}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493413838}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493413908}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"534"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493528458}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", all alive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493528565}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", low"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493528779}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493528859}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" risk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493560345}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 4-digit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493560519}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed.\n\nBut do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493560654}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we want more"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493560945}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dramatic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493635632}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493636587}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493636624}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 has flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493636662}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 417–1285,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493702012}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" herb"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493702273}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 79"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493702332}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–215, car"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493702374}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 20–59 — quite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493827315}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dynamic."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493827442}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good. Seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493827562}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"81 has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493827655}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" more dramatic plants"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493885973}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 131"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493886129}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–900. Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493886219}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 143 final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493886565}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 772, flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493947994}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 186"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493948075}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"–983. For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493948372}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124493948685}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494024115}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494024285}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494024468}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494024511}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 show"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494094306}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a wide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494094406}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494094549}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" swing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494094631}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Good.\n\nCould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494171468}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use seed 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494171562}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 as default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494171708}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", matching"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494171749}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"natural"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494229927}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ist"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494230243}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" field ledger"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494230280}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" vintage."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494230366}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494310865}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494310957}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494311370}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494311451}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494370877}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot fallback ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494371017}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494371227}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rely on engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494371268}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default). Boot passes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494438119}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" config seed only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494438225}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" if query; ENGINE"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494438361}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".createWorld"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494438408}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494515688}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494515920}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494515969}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494516019}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901. But seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494576680}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" choice based"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494576795}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494577024}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; final page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494577115}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494647775}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome. Good.\n\nYet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494647961}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cross"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494648301}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-engine ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494648339}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"S"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494714169}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"afari/Firefox"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494714330}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494714483}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" differ and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494714606}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494799627}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 may not be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494799761}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494800101}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stable. Requirement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494800143}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494873349}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t demand cross-engine determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494873403}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism necessarily; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494873516}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494873556}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494939925}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494939990}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome. Most"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494940423}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" judge"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124494940565}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely Chrome."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495013856}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495013952}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed reproducibility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495014904}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is per"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495014985}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-engine due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495124856}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495124946}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" floating point; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495125095}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mention"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495125232}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWould prefer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495157541}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495157683}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495157825}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s robust in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495158035}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both node and Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495229644}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495229690}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 45"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495229809}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495229855}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 708"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495289858}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/119"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495289938}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/32 and Chrome 486"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495290083}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/109/31; both"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495290272}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good. Seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495351827}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"188 node 690"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495351878}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/88/32"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495351991}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495352062}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome 848/149"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495424827}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/45; both good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495424961}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Seed 81 node 565"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495425069}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/97"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495425188}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/32 and Chrome 669"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495480927}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/140/30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495481066}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; both good. Seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495481189}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495481356}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 node 516"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495549693}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/168"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495549739}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/47 and Chrome 534"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495549891}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495550158}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/41; both good."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495622376}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Seed 143"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495622517}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node 616"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495622680}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/193"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495622729}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/28 and Chrome 772"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495686992}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/185/53; both"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495687090}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495687254}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" carn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495687297}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495767417}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Seed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495767476}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 is robust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495767628}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" across both and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495767677}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495822585}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4-digit, with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495822710}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495822877}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 events. Use "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495822922}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901. Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495905762}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 194"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495905890}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495906114}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" diverges badly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495906160}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (node good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495956872}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", Chrome bad"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495957136}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"), showing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495957195}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" why Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124495957239}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test matters. "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496023839}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901 robust"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496023981}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nGreat. Set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496024057}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496024356}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"EFAULTS.seed="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496086708}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1901. Also update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496086808}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot references"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496086940}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496087023}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1859"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496161981}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 1901"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496162062}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496162208}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496162269}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496233059}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496233158}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496233333}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496233413}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901 in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496299516}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome. Need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496299612}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496299802}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso improve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496299834}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496433646}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" readability perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496433709}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496433862}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496433922}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496448852}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" iterating; their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496448974}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dashboard looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496449071}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good. But there"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496449173}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" are some issues to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496491941}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report:\n- In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496491991}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record summary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496492081}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496492164}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"MUT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496580093}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ATION & D"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496580265}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVERSITY 50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496580364}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".0 per gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496580500}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" · 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496635730}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",848 in all\" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496635796}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" huge number"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496635923}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496635969}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens ×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496700769}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496700885}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mutation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496700979}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" count ~50"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496701318}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/gen; okay.\n- \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496765875}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Largest single"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496766016}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-generation fall\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496766193}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" entries"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496766352}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496873090}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": \"F"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496873181}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -186 ·"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496873321}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" G17 /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496873464}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" H"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496902559}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -29 · G08"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496902638}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" / C"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496902778}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496902830}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" · G40\" (F"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496980197}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" negative fall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496980301}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496980371}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Tra"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124496980446}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"it axes tick labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497045828}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": y"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497045914}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-axis top/b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497046073}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ottom only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497046534}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; perhaps insufficient"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497109135}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497109231}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Chart axis"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497109382}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" x"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497109585}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497172860}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0,5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497172933}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":",10,...40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497173061}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fine.\n- Cat"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497173191}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"astrophe marker"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497246218}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels rotated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497246300}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497246393}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ible at 144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497246459}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497301739}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- The charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497301859}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use a lot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497302054}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of white space"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497302103}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497426789}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" elegant.\n- The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497426957}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497427036}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart column headers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497427074}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" repeated;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497450493}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine.\n- The chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497450570}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canvas is "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497450842}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"129"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497450899}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0x?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497565840}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and not blur"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497565924}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ry.\n- It fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497566027}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497566112}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll.\n\nPotential issue: record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497582843}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497583114}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497583170}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0x900 uses full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497583305}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 900 height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497647982}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497648162}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497648302}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~860."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497648443}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n\nNeed check "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497720150}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1280x800 record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497720238}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497720853}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497720924}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test at lower"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497787264}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" DPR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497787356}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497787426}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497787496}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNext,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497854232}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497854342}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497854459}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497854636}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"20"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497921898}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497922005}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497922165}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124497922311}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" moment; current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498007032}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498007191}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498007339}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498007483}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks good but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498115162}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" field"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498115221}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" empty-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498115333}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (703"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498115419}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flora at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498177383}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9 in Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498177499}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498177596}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yes). At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498177679}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498247418}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1, early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498247461}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498247597}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be similar."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498247798}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We can rely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498300362}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow, set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498300450}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498300563}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 1901,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498300605}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498371303}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498371358}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back, then check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498371464}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498371612}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and record."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498450372}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498450460}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `#"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498450544}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"meta"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498450651}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-observation` maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498521709}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"No."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498521780}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498521905}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\"? Keep static"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498522017}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0047?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498600090}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The seed now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498600146}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901; observation number"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498600350}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498600390}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0047 is arbitrary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498730009}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but archival."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498730085}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could compute observation no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498730178}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from seed+?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498730240}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" e.g., pad"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498743458}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498743562}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(seed)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498743639}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498743827}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498822207}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; no."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498822254}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Keep "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498822375}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0047 as plate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498822691}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" number. Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498913868}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nSend"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498913913}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498914095}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" messages"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498914146}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498981298}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier: visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498981361}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" feedback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498983072}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from screens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124498983133}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hots;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499057458}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ask for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499057676}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499057965}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"a) increase sparkline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499058004}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ink/contr"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499118305}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ast slightly, ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499118460}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"b) tiny"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499118729}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auxiliary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499118823}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text size"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499181946}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499182026}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"outs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499182203}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499182268}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"6-7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499263468}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499263545}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" raise"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499263623}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" leg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499263694}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ibility), (c) ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499322884}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499322978}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-visible and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499323075}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria-label keywords"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499323125}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for QA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499385847}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", (d) seed control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499385900}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" display maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499386117}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pad 4"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499386194}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Not if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499443318}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901 four"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499443482}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-digit. (e)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499443625}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499443761}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499519653}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 layout; report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499519725}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" status.\n- chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499519851}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright: record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499519910}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks strong"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499577826}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ask ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499577881}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"a) with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499577963}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499578145}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499655603}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" y-axis/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499655719}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499655822}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels don"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499655994}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t collide; ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499725870}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"b) maybe increase"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499725952}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curve"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499726098}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" contrast slightly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499726145}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; (c) ensure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499783637}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499783693}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499783777}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499783921}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499867395}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clipped at last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499867453}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen; (d)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499867591}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ensure charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499867634}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499925826}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499925925}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499926106}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124499926349}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" during"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500047025}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hidden; ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500047135}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"e) fit at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500047264}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500047320}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800; report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500064139}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" status +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500064247}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" missing features"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500064426}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500064607}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"population"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500153318}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" curves"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500153397}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" + trait drift"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500153456}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500153620}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"); ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500220184}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"f) their `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500220358}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"#record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500220561}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-summary` currently includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500220633}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500334341}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"UTATION"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500334458}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" & DIVERSITY\" etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500334581}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500334715}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good.\n- verifier:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500354575}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500354702}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page now real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500354816}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500354924}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shots"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500406543}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/pre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500406658}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"view-lead.html; tell"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500406778}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" them run browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500407018}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500464497}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500464562}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500464684}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500464757}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500548207}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also our final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500548277}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" round "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500548425}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1/index.html will be updated"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500548498}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soon."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500595922}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Mention"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500596016}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500596183}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500596413}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500656479}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" requirement. Ask"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500656594}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500656777}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and issues"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500656860}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nBefore messages"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500738061}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500738143}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default seed and re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500738245}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500738353}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshots maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500800079}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also check page live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500800356}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500800416}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s do default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500800460}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500870335}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and screenshots in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500870397}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parallel with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500870479}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" other checks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500870659}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500934630}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fix my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500934743}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500934851}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-shot`/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124500934928}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"check script eval"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501107136}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501107214}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" necessary for final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501107279}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me update defaults"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501107340}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501170039}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_r939euizx3y82vcyuq0hg048","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501170092}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501170199}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501170252}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501210002}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501210136}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501210265}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501210325}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501220064}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501220155}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501220295}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501220502}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501221656}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501221765}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501221974}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501222037}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501224560}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501224689}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501224849}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501224904}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501225288}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501225434}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501228818}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501228881}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501235285}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501235364}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501235622}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501235674}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501249698}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501249776}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501249977}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501250054}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501297330}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501297448}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501297516}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501297803}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501298166}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501298239}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501298424}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501298512}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501314440}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501314510}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501314664}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501314764}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501321064}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501321108}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501321273}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501321313}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501321692}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501321773}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501321841}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501321910}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501322291}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501322371}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501322443}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501322512}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501366825}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501366882}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501367029}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501367101}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501367396}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501367447}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501367494}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" olds"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501367537}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501378774}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501378849}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501378980}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501379041}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501390575}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501390635}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501390804}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501390878}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501429022}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501429069}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501429168}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501429292}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501440145}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501440205}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501440254}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501440322}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501440678}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501440737}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501440866}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501440937}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501451953}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501452023}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501452120}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501452173}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501469572}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501469644}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501469807}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501469883}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501470098}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501470374}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501470468}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501470549}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501495709}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501495761}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501496170}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501496220}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501507635}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501507706}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501507852}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501507928}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501508208}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501508312}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501508475}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501508541}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501519586}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501519739}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501519824}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501519868}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501536030}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501536173}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501536359}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501536408}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501536766}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"185"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501537010}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"9"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501537100}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501537184}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501555822}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501555869}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501555911}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501555953}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501572676}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501572762}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501572893}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]:\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501572971}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501573265}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501573391}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501573576}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501573626}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501587022}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501587143}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501587349}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501587394}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501600336}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501600425}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501600572}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501600678}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501618610}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" olds"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501618774}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501618880}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501619089}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assert"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501619447}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501619624}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501619805}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501619880}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501640464}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501640583}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501640913}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501641021}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501662051}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"       "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501662137}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501662317}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501662409}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501662714}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501662966}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501663056}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501663137}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"   "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501675198}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501675289}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501675423}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501675515}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501686995}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501687078}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501687268}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501687336}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501687780}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501687880}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501688150}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501688235}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501732376}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501732447}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501732587}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501732626}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501752953}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501753038}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501753267}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501753353}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" assemble"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501755098}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501755244}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501755412}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501755461}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"out"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501775913}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501775968}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501776167}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501776256}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501787973}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501788032}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501788115}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" --"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501788166}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"quiet"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501806074}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501806145}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501806196}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501806298}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501827331}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501827411}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501827557}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501827645}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501828025}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501828141}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501828299}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501828385}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501847065}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501847127}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501847212}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501847258}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501870496}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501870545}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501871706}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501871763}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501887824}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501887871}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501887956}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501888025}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501898680}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501898793}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501898893}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501898950}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501900470}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501900608}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501900797}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501900871}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501922858}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501922938}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501923069}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501923136}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501932078}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501932214}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501932371}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501932426}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501933902}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501933974}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501934023}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501934074}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501950777}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501950849}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501951037}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501951091}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501969161}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501969208}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501969345}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501969418}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501987357}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501987440}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501987613}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124501987686}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502004165}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/pre"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502004222}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"view"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502004450}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-le"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502004503}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502052302}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502052414}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502052556}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502052658}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502060072}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502060223}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502060278}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"speed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502060330}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502060790}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502060858}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502061021}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502061131}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"800"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502095975}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502096032}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502096210}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502096294}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502103196}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502103249}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502103677}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"02"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502103746}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502143328}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502143398}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502143582}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502143682}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502145541}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"900"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502145612}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502145713}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502145776}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502158627}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502158665}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502158785}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502158842}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502168986}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502169051}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502169199}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502169266}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502189212}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502189276}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502189378}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502189461}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502190770}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"50"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502190846}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502190974}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502191043}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502208528}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502208678}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502208796}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502208969}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".txt"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502240208}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502240281}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502240487}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502240543}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502255859}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502255907}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502256098}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502256172}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502257005}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" default"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502257067}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502257188}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502257264}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"190"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502281362}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502281439}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502281562}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" capture"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502281637}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" record"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502362903}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502362953}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":22958,"ts_us":1793124502363051}}

data: {"id":"a476e3b30806294bfcc5b198a8ddd2c3","object":"chat.completion.chunk","created":1793124490,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":261066,"completion_tokens":1951,"total_tokens":263017,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":258944,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1598,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":22958,"ts_us":1793124502370564}}

data: [DONE]

