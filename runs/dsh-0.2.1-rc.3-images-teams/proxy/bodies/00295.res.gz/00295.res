data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124795987821}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796056339}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" official browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796056416}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run log now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796056656}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (it's been"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796109561}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796109622}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796109662}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" OLD suite version"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796109729}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; its"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796177883}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" results still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796177951}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" useful for baseline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796178009}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Let me check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796178121}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247405}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_8y90q0nfi9jwrosrmdjxq8t4","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247476}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247540}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247596}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247665}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247708}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247782}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247835}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247904}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796247968}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"45"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248505}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248562}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248615}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248670}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rowser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248722}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-o"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248772}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fficial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248810}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248850}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248903}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248945}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796248996}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796249038}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796249286}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796249372}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796249444}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796249513}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796249579}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796249627}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796312814}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796312866}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796312925}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796312981}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796314288}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796314330}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796314373}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796314413}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796334581}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796334669}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796334751}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796334813}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796338987}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796339060}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796339156}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796339214}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796347816}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796347870}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796347941}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796348018}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796352751}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796352808}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796352853}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796352900}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796353492}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796353535}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796353577}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796353634}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796371420}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796371471}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796371519}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796371582}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796387452}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796387510}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796387564}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796387609}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796388111}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796388158}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796388209}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796388254}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796409357}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796409436}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796409508}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796409572}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796428740}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796428790}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796428847}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796428900}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796433299}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796433366}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796433409}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796433442}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796434106}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796434154}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796434216}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796434267}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796449377}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796449454}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796449502}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796449548}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796461868}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796461957}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796462031}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796462097}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796507002}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796507055}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796507120}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796507181}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796510273}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796510356}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796510439}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796510515}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" official"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796528972}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" browser"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796529049}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796529123}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" results"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796529186}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796619385}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":10757,"ts_us":1793124796619490}}

data: {"id":"6738f6edda436ceeff8cfc8153baa2d6","object":"chat.completion.chunk","created":1793124795,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":266323,"completion_tokens":169,"total_tokens":266492,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":264320,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":29,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":10757,"ts_us":1793124796619594}}

data: [DONE]

