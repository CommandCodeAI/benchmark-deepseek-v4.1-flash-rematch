data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738875715}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_d31gqxidyyjkj8t5srsltmxz","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738875815}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738875845}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738889855}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738889987}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738890226}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738890465}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738906809}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738906913}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738907203}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738907255}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738923394}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738923618}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738923720}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738924215}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738943597}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738943894}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738943980}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738944123}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738944224}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738944421}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738944693}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738944802}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738961378}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738961637}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738961735}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124738961989}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739001199}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739001313}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739001412}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739001589}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739004911}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739005106}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739005456}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739005545}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739005736}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739005970}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739006157}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739006908}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739033776}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739033879}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739033951}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739034607}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739034654}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739034737}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739034947}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739035002}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739035105}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739035152}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739035264}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739035317}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739047251}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739047412}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739047456}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739047823}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739064661}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739064707}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"04"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739064813}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739064913}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739149476}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":7103,"ts_us":1793124739149528}}

data: {"id":"565ad15bfba5207a06160e427f24d1c0","object":"chat.completion.chunk","created":1793124738,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":285330,"completion_tokens":88,"total_tokens":285418,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":283136,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":7103,"ts_us":1793124739150028}}

data: [DONE]

