data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231923051}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ilgke4qimr0ztqkjk8yhyo3p","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231948509}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231948564}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231948608}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231951847}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231952122}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231952170}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231952285}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231959805}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231959906}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231960001}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127231960246}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232005982}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232006032}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232006141}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232006227}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232038116}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232038203}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232038364}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232038474}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232038768}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232038892}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232038934}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232039036}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232039082}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232039144}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232039239}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232039289}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232071874}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232072160}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232072230}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232072346}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232093943}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232094073}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232094147}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232094342}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232095153}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232095221}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232095312}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232095460}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232109010}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232109149}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232109280}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232109350}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232145421}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232145548}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232145598}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232146242}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232156303}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232156399}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232156444}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232156539}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232158366}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232158444}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232158512}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232158595}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232171867}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232171950}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232172000}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232172128}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232190353}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232190483}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232190563}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232190732}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232191140}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232191202}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" stat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232191371}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232191426}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232204896}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\"%"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232204948}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232205051}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" %"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232205234}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"z"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232219385}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232219452}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232219518}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232219948}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232221552}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232221638}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232221694}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232221799}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232240722}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232240812}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232240863}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232241254}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232248788}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232248935}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232248995}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232249106}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232249586}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232249691}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232249856}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232249912}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232284402}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232284545}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232284642}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232284767}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232305007}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232305081}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232305124}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232305246}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232331049}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" reass"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232331138}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"embly"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232331232}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232331285}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":6596,"ts_us":1793127232405818}}

data: {"id":"7ca60c5b107131b96ffae9a7fe8561b2","object":"chat.completion.chunk","created":1793127231,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":359746,"completion_tokens":139,"total_tokens":359885,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":359552,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":6596,"ts_us":1793127232406078}}

data: [DONE]

