data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125872661}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_aqflattg0w7pfmqr4yx8qjuh","type":"function","function":{"name":"team_task_get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125931923}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125931955}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125931974}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125932410}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125932434}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125932452}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125932469}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125945965}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125945991}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125946009}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127125946028}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127126037874}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":57859,"ts_us":1793127126037908}}

data: {"id":"54233f2893325dc7437c4f223981f9b8","object":"chat.completion.chunk","created":1793127125,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":373695,"completion_tokens":42,"total_tokens":373737,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":373120,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":57859,"ts_us":1793127126038136}}

data: [DONE]

