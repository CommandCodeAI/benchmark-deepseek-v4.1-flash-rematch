data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123072856110}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123072935053}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3 fix:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123072935092}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" first pattern"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123072935160}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073167942}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/\\bfetch\\"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073167983}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s*\\(/` isn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073168011}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t global. Add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073168051}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" g flags"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073239619}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also A7"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073239657}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is INFO"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073239681}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but currently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073239705}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PASS with note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073311226}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; better make"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073311261}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it fail"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073311291}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-ish"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073311309}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073350430}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" INFO"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073350484}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073350516}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; I'll change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073350548}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" status handling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073420487}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073420524}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" INFO severity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073420692}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073420728}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" status"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073518817}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" W"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073518872}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARN."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073518902}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073518930}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" as is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581025}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; report will"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581063}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note.\n\nFix A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581089}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"3."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581126}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_rgvigb5m1tixc5rikrhm6gb8","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581177}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581209}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581238}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581265}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581317}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581357}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581791}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581854}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581889}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581917}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581954}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073581985}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582014}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582049}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582086}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582118}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582145}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582170}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582272}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582307}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582344}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582377}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582405}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582431}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582458}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582484}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582518}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582558}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582587}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582613}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582734}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073582768}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073597928}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073597994}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073598047}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073598116}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073617188}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073617289}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073617340}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073617397}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073618944}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073618979}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073619016}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073619080}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073620179}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073620206}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073620315}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073620382}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073625642}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073625704}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073625805}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073625834}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073626336}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073626369}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073626398}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073626426}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073641551}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073641604}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073641641}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"='"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073641672}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073655011}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073655076}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073655117}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073655254}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073655782}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073655815}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073655845}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073655909}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073692417}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073692474}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073692615}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073692666}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073698297}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073698346}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073698381}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073698416}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".replace"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073699152}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073699198}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073699233}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073699484}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073701892}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"etch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073702227}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073702311}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073702353}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073756111}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073756187}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/,"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073756301}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073756348}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fetch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073756392}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073756470}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073756944}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\",\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073756983}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073757029}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073757058}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073757090}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"etch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073757121}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073767463}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073767518}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"*\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073767547}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073767582}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073776885}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073776924}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073776953}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073776982}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fetch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073778163}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073778199}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"],"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073778265}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073778334}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073789949}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073789999}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073790067}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073790110}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073805600}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"write"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073805634}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073805662}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073805687}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073805912}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073806141}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073806171}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073806244}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073826982}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073827016}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073827117}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073827153}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073856314}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073856350}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073856381}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073856452}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073860106}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073860166}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073860208}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073860242}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073873838}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073873880}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073873933}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073873971}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073903412}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073903468}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073903506}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073903534}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fix"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073910645}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" A"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073910717}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073910772}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" regex"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073910806}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" global"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073944084}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" flag"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073944134}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073944168}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1563,"ts_us":1793123073944196}}

data: {"id":"0c04f0a329e65fc691f3ceb2b2f000d2","object":"chat.completion.chunk","created":1793123072,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":61548,"completion_tokens":255,"total_tokens":61803,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":60800,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":72,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1563,"ts_us":1793123074010740}}

data: [DONE]

