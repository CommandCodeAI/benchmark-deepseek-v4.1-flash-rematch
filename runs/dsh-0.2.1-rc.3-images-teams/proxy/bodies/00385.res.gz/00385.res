data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661547840}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Rel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661589374}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oad determinism passes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661589630}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Keyboard shortcuts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661589987}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- G advanced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661651321}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 10→"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661651579}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"11 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661652093}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661652137}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n- R recast same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661727992}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed reset gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661728253}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661728734}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note visible ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661728819}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pass).\n- `?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661814600}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` opened shortcut note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661814655}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661814948}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Q false"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661815045}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661895963}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" false → open"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661896346}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (pass).\n- Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661896635}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661896685}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?` togg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661960843}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"led close? Then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661960977}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Space:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661961556}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" afterSpace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125661961601}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662034976}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", gen 0."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662035165}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Wait, after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662035650}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" R rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662035693}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ast starts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662109216}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running; we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662109367}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pressed ? twice"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662109874}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then Space"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662109950}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662181143}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pause. It"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662181208}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shows paused true and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662181258}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 0; possible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662181309}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662241105}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662241331}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t run because pressing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662241867}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662241907}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?'?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662319899}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662320154}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at least"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662320671}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Space"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662320710}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toggled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662384437}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused (or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662384712}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662385150}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" already running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662385200}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662481586}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" R running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662481678}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662481773}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; Space should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662481849}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pause). It's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662524733}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused true; pass"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662524993}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" though"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662525454}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662525496}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t advance in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662609950}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0.9"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662610152}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s maybe because page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662610662}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visibility hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662610701}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by '"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662668966}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?'?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662669157}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662669665}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" '?' shouldn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662669703}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662736468}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662736841}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" recast +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662736894}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" keyboard?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662736923}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could be tim"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662802939}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ers/r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662803227}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF slow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662803983}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662804025}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" important. Short"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662877012}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cut works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662877204}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNote `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662877884}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"short"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662877931}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cutNoteHidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662973260}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AfterOpen` false"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662973503}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" means visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662973997}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; correct"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125662974039}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663017336}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663017622}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"E"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663018172}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"scape` closes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663018211}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shortcut note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663081765}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in real browser;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663082040}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663082510}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visibility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663082557}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" qu"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663145036}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"irk aside.\n\nRed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663145241}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"uced motion and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663145763}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663145812}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4/1280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663205022}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pending. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663205187}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663205678}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663205737}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663285764}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll.\n\nLet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663285963}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s inspect atelier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663286563}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" progress;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663286654}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe message"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663368279}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" soon. Check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663368464}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file mtimes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663369047}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663369098}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_cexpzyylupxztffubmbrmyrj","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663387625}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663387876}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663388351}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663388419}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663404147}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663404611}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663405057}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663405112}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663417173}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663417508}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663417572}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663417626}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663418934}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663418980}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663419039}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663419113}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663438793}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663439168}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663439224}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663440103}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663457405}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663457723}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663457824}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663458710}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663478139}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663478423}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663478481}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663478540}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663495586}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663495642}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663496045}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663496131}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663508502}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663508629}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663508982}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663509120}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663531485}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663531741}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663531817}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663531866}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663542269}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663542541}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663542590}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663542649}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663544288}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663544337}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663544384}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663544455}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663581169}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663581418}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663581471}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663581513}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663582989}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663583065}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663583121}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663583189}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663607189}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663607486}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663607539}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663607590}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663613894}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663614185}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663614746}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663614833}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663615761}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663615813}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663615854}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663615901}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663688085}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663688139}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ashboard"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663688526}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663689028}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663762325}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663762591}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663762651}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663762700}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663764135}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"200"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663764220}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663764291}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663764345}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663764394}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663764450}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PORT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663767509}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663767589}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663767649}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663767706}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663767789}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dev"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663767848}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/null"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663770856}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663770917}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663770971}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663771042}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663771095}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663771171}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ifier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663771241}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" files"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663771305}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663771366}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663774357}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663774455}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663774558}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"la"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663842308}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663842357}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663842863}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663842945}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663857904}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663858202}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"10"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663858250}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663858298}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663868371}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663868702}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663868798}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663868883}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663871242}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663871538}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663871583}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" teammate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663871643}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" progress"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663877305}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663877353}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663877794}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ifier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663877862}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663929725}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663929775}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":37074,"ts_us":1793125663929821}}

data: {"id":"535eab4f32ee665e1da0ef83a8f6baa8","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":310906,"completion_tokens":424,"total_tokens":311330,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":309632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":266,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":37074,"ts_us":1793125663936786}}

data: [DONE]

