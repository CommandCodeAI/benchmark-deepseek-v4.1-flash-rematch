data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728581602}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_enst1gnvvilez61no9607lwi","type":"function","function":{"name":"team_task_update"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728617921}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728617979}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728618047}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728618688}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728618761}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728620588}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728620631}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728642041}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728642142}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728642210}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728642286}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728682806}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728682873}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728682930}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"expected"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728682979}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728683749}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728683844}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728683969}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728684050}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728742204}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728742262}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728742309}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"action"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728742377}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728745248}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728745308}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728745363}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"claim"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728745444}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728837866}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1457,"ts_us":1793122728837915}}

data: {"id":"075dbf8d518f2d7cadd35db6774fa467","object":"chat.completion.chunk","created":1793122728,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":25289,"completion_tokens":76,"total_tokens":25365,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":24576,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1457,"ts_us":1793122728838052}}

data: [DONE]

