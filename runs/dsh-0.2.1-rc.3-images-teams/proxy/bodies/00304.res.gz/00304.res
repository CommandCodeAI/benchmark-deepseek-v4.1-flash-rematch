data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886786765}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886824636}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pause."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886824974}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Why no r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886825104}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF? Maybe the page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886891518}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886891810}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" becomes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886891862}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886891972}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hidden\" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886990531}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless after CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886990581}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P interactions? Headless"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886990687}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rAF should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124886990956}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" continue. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887032822}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887032900}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887032982}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887033055}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887083407}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" any"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887083493}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887083629}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P evaluate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887083677}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887166070}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome headless thrott"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887166161}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"les rAF when no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887166384}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887166423}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Hmm,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887241169}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but auto-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887241293}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" entire "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887241490}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 gens occurred in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887241561}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887322477}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s with no interaction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887322553}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887322763}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our interaction"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887322807}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" click on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887389406}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fol"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887389740}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"io toggle cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887389821}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" focus"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887389870}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887459437}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Perhaps `__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887459649}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887459719}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVARIUM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887459791}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"__.actions.resume()` isn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887529533}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t the boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887529720}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887530015}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? It is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887530070}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887594417}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `state.p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887594487}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aused` stuck true due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887594616}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887594758}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887653791}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" second click/f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887653859}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"old"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887653938}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Hmm.\n\nWait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887653987}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887717221}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887717272}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses `?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887717417}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"auto=0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887717597}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887789612}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887789819}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `boot`, `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887790060}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"state.paused = query.p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887790200}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"aused === true`. Then at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887843876}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end, `sync"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887843965}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Playback()` is called"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887844046}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". `actions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887844282}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".resume()` sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887910827}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `state.paused=false"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887911080}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; syncPlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887911317}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back()`. But in `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887911388}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"sync"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887971096}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Playback`, `running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887971167}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887971330}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`; then calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124887971376}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `CONTROLS.set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888047316}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Running(true)`. At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888047428}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888047602}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `setRunning` sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888047665}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888126868}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" attrs only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888126931}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine.\n\nFrame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888127083}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop:\n```\nif"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888127205}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (!state.f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888183517}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"inished && !state.paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888183555}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" && world) {"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888184013}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ... }\n"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888184073}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"...\nroot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888260910}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".requestAnimationFrame(frame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888261212}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":");\n```\nShould tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888261420}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nUnless **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888261494}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"requestAnimationFrame is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888317106}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" throttled to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888317202}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 F"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888317434}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"PS when the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888317508}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page is not painted"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888371343}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888371435}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888371508}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888371696}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888453831}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'re not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888454070}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" requesting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888454139}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshots? But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888454237}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888527677}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" worked at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888527908}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" startup"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888528217}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"—maybe Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888528263}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ran"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888592070}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888592331}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888592509}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" thrott"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888592576}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ling? Headless \"new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888697255}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" should still animate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888697316}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Yet our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888697741}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888697782}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888768474}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888768653}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had an"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888768759}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888769341}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; after interactions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888825161}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888825271}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tab"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888825456}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is considered background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888825543}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888882318}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888882561}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" There"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888882619}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may be an"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888882676}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issue: the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888956276}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888956356}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" been paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888956452}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124888956783}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `actions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889039227}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".pause`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889039454}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Wait sequence"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889039692}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889039759}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": after fold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889101035}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/un"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889101144}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"fold, we called"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889101450}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889101540}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ume`,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889177167}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sleep 1200, then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889177227}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `pause`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889177434}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; then playback"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889177479}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889231742}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0. Maybe **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889231824}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"the page never"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889231953}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" got a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889232122}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889322889}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF because the CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889323033}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P session is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889323158}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" synchronous evaluate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889323202}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889363758}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889363823}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs while the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889363958}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889364169}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er is actively"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889461773}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doing frames"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889461869}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; headless may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889461926}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not schedule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889462026}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889502766}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF continuously without a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889502820}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" BeginFrame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889503033}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**. But auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889503069}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889564552}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" did complete"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889564863}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889564936}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in 8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889564994}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889647267}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889647432}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only slept"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889647631}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"—"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889647885}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"so it did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889716309}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" schedule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889716399}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe because we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889716543}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had `Em"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889717114}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ulation.setDeviceMetricsOverride`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889769246}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889769333}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" both."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889769394}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889769615}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nDifference"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889846789}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": auto-run test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889846865}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" URL without auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889847561}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=0; initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889847644}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused=false"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889919400}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889919483}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" this"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889919551}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889919615}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused=true; maybe Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889976727}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s virtual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889976797}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" time /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889977012}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lifecycle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124889977085}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stops r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890049743}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890049822}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"until"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890049944}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890049997}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" user gesture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890147686}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**? But `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890147736}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actions.resume`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890147917}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890148384}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a user gesture;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890169327}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" however r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890169377}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF shouldn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890169498}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t care"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890169920}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Hmm,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890232659}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe Chrome head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890232962}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less thrott"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890233082}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"les rAF when there"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890233124}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is no *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890298847}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"active* request"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890298933}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890299139}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890299211}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe there's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890460977}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a bug:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890461032}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in the initial state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890461173}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890461437}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused=true, `last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890475502}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Animation` is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890475770}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set when r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890476032}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890476073}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame; the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890571514}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop still calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890571591}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" itself"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890571749}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But if `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890571804}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"state.paused`, the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890597549}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop still schedules"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890597633}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frames and calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890597692}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" draw/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890597751}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"updateUI. So r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890660969}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890661027}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" alive"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890661338}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". After resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890661392}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", should tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890730484}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould something"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890730558}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890730640}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `state.paused`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890730686}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" back to true each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890814856}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame? `process"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890814956}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"New"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890815164}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Events`? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890815224}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". `con"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890875619}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"clude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890875830}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Study"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890875876}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`? no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890875929}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWait: `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890956225}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"syncPlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890956273}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back` calls `CONT"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890956329}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ROLS.setRunning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124890956387}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891017654}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")`; but then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891017707}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891017875}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loop,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891017925}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `updateUI` calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891091892}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `CONTROLS.update(w"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891091952}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"orld,16"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891092029}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")`. Atelier's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891092202}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" update reads cfg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891172707}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" values. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891172789}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891172843}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891172904}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ctx."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891230720}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actions.pause()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891230787}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891230838}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" values changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891230889}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Search for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891314530}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `ctx."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891314605}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actions`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891314758}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_mmj1plgtrrebwst2884ea07e","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891315138}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891315204}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891315269}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891315318}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891315346}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891328630}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891328692}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891328762}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891328829}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891346295}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891346338}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891346522}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891346575}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891362817}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891362904}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891363056}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891363109}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891381141}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891381432}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891381505}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891381567}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891397597}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891397668}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891397779}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891397853}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891413348}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891413501}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891413660}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891413731}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891414243}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891414348}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891414438}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891414491}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891442513}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891442735}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891442823}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891442934}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891456151}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891456205}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891456306}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891456416}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891458178}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891458244}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891458395}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891458475}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891470956}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891471141}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891471191}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891471309}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891487104}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891487166}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891487372}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891487452}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891507199}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891507298}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891507531}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891507611}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891507991}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"actions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891508062}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891508104}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"actions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891508167}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891540384}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891540505}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891540595}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891540672}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891556064}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891556147}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891556210}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891556257}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891577594}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891577648}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891577838}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891577912}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891578060}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891578126}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891578293}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891578394}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aused"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891585865}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891585948}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891586035}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891586088}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891599192}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891599241}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891599349}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891599437}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891621124}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891621237}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891621739}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891621787}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891639903}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891639959}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891640075}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891640163}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891680466}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" calling"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891680680}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" pause"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891680739}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" actions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891680792}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891814317}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34351,"ts_us":1793124891814558}}

data: {"id":"788ee78ac6669434989831d20b034302","object":"chat.completion.chunk","created":1793124886,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":280952,"completion_tokens":840,"total_tokens":281792,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":278784,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":706,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":34351,"ts_us":1793124891814665}}

data: [DONE]

