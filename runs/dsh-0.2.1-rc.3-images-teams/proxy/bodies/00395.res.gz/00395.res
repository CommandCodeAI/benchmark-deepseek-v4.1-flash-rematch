data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729872835}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ebqz4oasp3o8joi7ymgsytac","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729872908}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729872944}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729874353}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729874471}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729874574}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729874932}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729877994}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729878169}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729878415}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729891657}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729891802}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729891847}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729891908}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729891955}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729905166}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729905242}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729905409}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729905500}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729924979}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729925141}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729925188}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729926153}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729926296}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729926339}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729926456}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729926507}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729956669}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729956757}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729956992}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729957251}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729978376}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729978802}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729978962}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729979195}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729979247}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729979298}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729979551}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729979596}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729989499}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729989658}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729989725}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125729989887}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730010940}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730011057}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730011132}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730011342}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730011480}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730011676}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730011806}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730011848}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730024900}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730025042}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730025079}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730025614}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730042208}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730042312}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730042500}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730043114}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730124840}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730124902}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730125003}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":16015,"ts_us":1793125730132931}}

data: {"id":"c63384edbf55a56143a7f98a45f3c818","object":"chat.completion.chunk","created":1793125729,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":346572,"completion_tokens":90,"total_tokens":346662,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":345728,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":16015,"ts_us":1793125730133491}}

data: [DONE]

