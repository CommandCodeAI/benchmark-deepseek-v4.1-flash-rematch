data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946792770}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_vtimyixmi8m06sjn5pqsh3cc","type":"function","function":{"name":"team_task_update"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946858093}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946858146}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946858199}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"action"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946872127}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946872176}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946872220}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946872282}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"complete"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946892184}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946892243}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946892289}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946892386}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"expected"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946905375}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946905437}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vision"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946905511}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946905565}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946959997}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946960059}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946960108}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946960185}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946971813}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946971860}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946971902}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946971943}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946975868}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946975929}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946975981}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126946976031}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126947049132}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67788,"ts_us":1793126947049183}}

data: {"id":"4b9b7780ac016528b6e8f87204bebe0e","object":"chat.completion.chunk","created":1793126946,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":282187,"completion_tokens":76,"total_tokens":282263,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":281472,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":67788,"ts_us":1793126947049286}}

data: [DONE]

