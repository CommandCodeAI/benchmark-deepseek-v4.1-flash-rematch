data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661673457}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_49kfxut2815yg6kj2ey79fey","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661673556}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661673596}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661706413}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661706501}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661706651}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661706992}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661725673}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661726084}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661726154}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661726291}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661733348}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661733766}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661733843}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661733982}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661751744}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661751938}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661752063}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661752114}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661761782}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661761926}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661762027}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661762080}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661762430}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661762602}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661762684}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661764316}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661787438}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661787588}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661787658}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661787757}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661803015}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661803068}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661803197}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661803294}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661803602}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661803834}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661803873}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661804745}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661816329}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661816373}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661816476}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661816624}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661840098}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661840185}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661840286}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661840522}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661840825}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661840928}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661841021}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661841129}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661854002}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661854060}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661854109}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661854210}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661869671}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661869743}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661869864}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661870154}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661937456}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661937546}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661937638}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":15846,"ts_us":1793125661943695}}

data: {"id":"f082a510800a9905f38ef5150506ab44","object":"chat.completion.chunk","created":1793125661,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":344617,"completion_tokens":90,"total_tokens":344707,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":342528,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":15846,"ts_us":1793125661944018}}

data: [DONE]

