data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069295673}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"A"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069410014}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069410062}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" regex for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069410483}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" url()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069479475}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has weird negative"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069479541}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lookahead; let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069481721}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me test."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069481779}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also A3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069544575}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" might detect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069544652}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `fetch(`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069544707}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in prose comments"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069544750}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" like"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069612249}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069612296}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" own"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069612335}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The deliver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069613552}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"able only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069675830}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let's run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069675898}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" static now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069675944}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on current stub assembly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069675992}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069723232}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_kc8mv3esruld2bbbwv1aji9m","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069723310}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069723522}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069723576}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069723622}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069723678}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069723748}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069723987}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724045}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724100}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724154}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724214}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724253}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724311}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724355}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724415}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724463}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724515}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724556}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724739}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724832}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724898}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069724972}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069725009}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069725059}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069725115}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069725179}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069725238}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069742849}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069742896}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069742935}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069742973}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069756570}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069756661}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069756708}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069756748}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069756896}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069756959}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069757009}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069757058}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069770755}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069770828}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069770909}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069770956}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069790674}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069790733}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069790781}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069790826}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069808755}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069808808}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069808967}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069809032}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069809339}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069809390}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069809452}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069809538}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069879460}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069879510}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069879549}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069879626}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069888727}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069888784}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069888828}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069888871}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" tail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069889727}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069889780}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"25"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069889917}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069889978}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069897144}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069897191}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069897231}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069897280}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069905170}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069905218}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069905280}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" static"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069905334}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" suite"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069915967}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" against"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069916047}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" current"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069916108}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" deliver"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069916169}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"able"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069998255}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069998343}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1685,"ts_us":1793123069998396}}

data: {"id":"94dd16247e2db2f5746e43f03f2761ff","object":"chat.completion.chunk","created":1793123069,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":60915,"completion_tokens":164,"total_tokens":61079,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":54400,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":47,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1685,"ts_us":1793123070002151}}

data: [DONE]

