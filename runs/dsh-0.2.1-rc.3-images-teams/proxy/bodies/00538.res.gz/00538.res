data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100368651}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100402689}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier final done"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100402788}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", all agents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100402897}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inactive/com"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100458927}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pleted."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100459725}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100459813}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" §"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100459857}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100534810}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier says still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100535652}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says 1977—"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100535757}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"but our grep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100535820}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" showed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100595259}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100595937}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe their"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100595994}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100596107}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100642704}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" they mean"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100643487}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" another"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100643535}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100643622}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100706942}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"1977\""},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100707940}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" occurrences"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100708012}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in brief; we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100708115}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" saw default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100771592}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" specimen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100772513}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", table"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100772605}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", engine all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100772658}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1901. Maybe elsewhere"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100835537}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100836611}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s grep all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100836692}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1977"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100836764}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100908376}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_ek4gateptmay3tt2wcdgorba","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100909219}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100909331}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100909410}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100915082}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100915159}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100915231}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100915297}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100915358}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100915444}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100915626}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100927169}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100927259}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100927340}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100927426}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100927472}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100935734}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100935891}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100936048}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100936143}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100957659}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100957728}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100957780}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100957821}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100961021}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100961155}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100961234}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100961338}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100967903}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100968072}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100968161}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128100972715}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101002419}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101002472}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101004167}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101004272}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101020350}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101020479}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101021422}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101021617}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101029605}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101030763}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101030959}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101031145}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101043446}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101044200}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101044505}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101044613}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101049286}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101049465}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101049640}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101049816}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101060506}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101060606}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101082604}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101082807}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101082953}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101083082}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101083176}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101083355}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" DESIGN"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101088488}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-B"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101088776}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101088865}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101089055}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101094800}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101095851}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101095956}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101096200}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101106787}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101107651}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101107749}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101107940}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101138269}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101139018}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" check"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101139330}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" no"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101139426}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" writes"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101190996}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101191685}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101191748}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101191880}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101207266}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101207413}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"T"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101207477}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101208628}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101221953}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101222512}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101222591}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101222721}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101236611}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101236732}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101236802}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"as"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101237918}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"um"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101238798}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101238957}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"a"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101239055}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101239227}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"256"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101251520}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101252002}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"round"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101252063}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101252181}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101266015}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/index"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101266420}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101266504}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101266556}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101268612}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101268757}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101268824}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101268960}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" report"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101301035}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101301145}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101301220}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101301331}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101320202}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101320677}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"35"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101320761}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101321954}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101322741}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101323305}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PORT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101323453}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".md"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101323533}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101346476}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101346899}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101346946}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101347037}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101363588}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101363966}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101364037}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Confirm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101365275}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" brief"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101411329}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" consistency"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101411411}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101411995}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101412124}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101444961}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101445076}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12473,"ts_us":1793128101445697}}

data: {"id":"1203b9fa534bd4e0cbccb6d027fe7d3d","object":"chat.completion.chunk","created":1793128100,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":365099,"completion_tokens":245,"total_tokens":365344,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":363136,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":76,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":12473,"ts_us":1793128101454393}}

data: [DONE]

