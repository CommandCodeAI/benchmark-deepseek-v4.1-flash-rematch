data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901082989}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_bfnoeprx6mau3v9rii4lofod","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901083086}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901083143}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901083198}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901083250}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901083304}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901083355}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901083388}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901084415}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901084503}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901084570}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901084632}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901104928}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901105010}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901105068}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901106644}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901124870}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901124935}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901125062}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901125117}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901143580}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901143662}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901143738}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901143800}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901143879}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901143928}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901144317}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901144395}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901165157}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901165236}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901165289}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901165356}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901179643}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901179707}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901179789}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901179866}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901183284}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901183334}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901183380}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901183419}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901195306}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901195366}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901195394}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901195475}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901208165}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901208230}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901208352}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901208413}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901227165}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901227210}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901227263}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901227410}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901246968}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901247027}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901247084}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901247119}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901259683}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-sum"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901259760}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mary"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901259813}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901259853}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901281449}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901281504}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901281592}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901281684}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":19210,"ts_us":1793123901351329}}

data: {"id":"24f559f9c22687bcc2a1847f5bd1e998","object":"chat.completion.chunk","created":1793123900,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":184571,"completion_tokens":92,"total_tokens":184663,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":183552,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":19210,"ts_us":1793123901351417}}

data: [DONE]

