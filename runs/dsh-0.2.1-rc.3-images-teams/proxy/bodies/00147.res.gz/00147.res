data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680207511}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680385583}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_5ufxslpr1hrsu298sj5gohcg","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680385682}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680385733}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680385819}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680385963}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680386021}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680386196}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680386289}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680386447}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680386586}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680388803}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680388849}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680388933}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389011}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389061}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389149}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389221}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389279}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389346}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389382}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389471}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389625}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389703}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389789}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389869}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680389946}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680390022}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680395746}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680395798}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680395847}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680395945}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680396107}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680396204}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680396407}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680396505}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680417694}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680417781}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680417849}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680417914}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680439926}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680440004}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680440077}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680440127}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680449066}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680449115}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680449172}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680449241}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680449470}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680449578}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680449639}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680449686}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680479554}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680479622}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680479832}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680479901}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680480066}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rop"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680480125}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680480234}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ensus"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680480291}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680506317}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680506388}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"x"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680506451}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680506512}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680585188}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":3746,"ts_us":1793123680585267}}

data: {"id":"094651b64af0664b043c0c42ad90afc8","object":"chat.completion.chunk","created":1793123680,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":161332,"completion_tokens":93,"total_tokens":161425,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":159488,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":3746,"ts_us":1793123680585333}}

data: [DONE]

