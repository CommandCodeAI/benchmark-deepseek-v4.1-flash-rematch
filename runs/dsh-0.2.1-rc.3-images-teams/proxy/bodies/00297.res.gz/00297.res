data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844036732}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Important"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844127944}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issues:\n1. Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844128042}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back didn't run when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844128534}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844163566}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actions.resume()`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844163613}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" called? After"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844163967}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fol"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844164052}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"io fold"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844212061}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/unfold, we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844212152}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" call resume, wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844212315}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.2s,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844212583}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pause; gen still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844322852}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0. Why? Because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844322976}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `actions.res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844323054}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ume()` from `__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844323419}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844357012}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARIUM__` sets paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844357109}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=false and sync"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844357398}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Playback,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844357439}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but the frame loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844410023}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844410143}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844410184}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844410973}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page is not visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844567339}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844567537}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rAF throttled in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844567588}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless? Earlier auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844568023}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run did work (record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844581957}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844582050}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But here maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844582100}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `actions.p"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844582912}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ause()` immediately"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844615090}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after sleep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844615187}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844615244}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rAF frame didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844615669}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t run because the CDP"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844686223}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" evaluate thread? Hmm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844686323}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; rAF should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844686381}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run. Wait initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844687876}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844781426}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"auto=0` sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844781590}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" paused; after cv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844781724}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844781766}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844839062}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844839100}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844839382}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0 tick "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844839420}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 suggests no ticks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844916920}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could be because the browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844916972}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tab is throttled? But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844917146}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" previous `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844917194}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844987269}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=8` auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844987369}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run worked. Maybe `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844987487}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"__V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124844987739}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVARIUM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845067152}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"__.actions.resume()` sets"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845067230}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `state.paused=false`,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845067481}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845067562}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845129530}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s closure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845129820}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `state.paused`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845129905}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works; should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845130501}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Perhaps pausing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845192197}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" occurred"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845192428}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because `document"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845192500}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".getElementById"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845193140}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"('btn-step"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845252714}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"').click()`? No,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845252870}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" order: resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845253039}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", sleep 1200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845253104}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", pause."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845321890}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845321964}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845322015}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 means resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845322520}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" did nothing. Check actions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845392853}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".resume implementation: `res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845392953}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ume: () => { state"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845393041}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".paused = false; sync"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845393115}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Playback(); }` —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845453099}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yes. Maybe the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845453176}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845453248}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stopped"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845453295}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because `lastAnimation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845508678}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845508997}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dt? No.\n\nOh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845509110}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"! Look at event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845509173}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"M"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845580739}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oment after step"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845580890}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845580990}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1, then set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845581047}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845661216}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 8, resume, sleep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845661293}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2s -> gen still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845661351}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1. So resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845661408}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't run."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845761380}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Why? Maybe because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845761784}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845761841}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page is **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845761921}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"not focused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845780167}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"**? r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845780247}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF still runs head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845780446}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less. Earlier auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845780594}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run with auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845840156}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845840226}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ran. Difference"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845840298}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845840917}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"auto=0` at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845891822}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845891869}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; our boot's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845891915}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845893728}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"state.paused` initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845954582}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" true. `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845954860}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"actions.res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845954929}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ume` should unp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124845955344}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ause.\n\nCould be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846021103}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846021271}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846021366}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIV"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846021550}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ARIUM__.actions.resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846129805}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` shadow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846129910}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed? The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846129954}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" object exposes actions resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846130202}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846152719}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846152800}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `syncPlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846152936}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back()`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846153015}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846210211}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".setRunning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846210381}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(true),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846210441}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and controls'"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846210552}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" internal `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846280173}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"setRunning` implementation pauses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846280260}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846280508}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Unlikely.\n\nWait,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846280573}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846385206}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P script inv"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846385369}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"okes `__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846385462}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIVARIUM__.actions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846385504}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".resume()` inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846435031}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Runtime.evaluate; then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846435199}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later `__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846435298}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"VIVARIUM__.actions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846435362}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".pause()`. If"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846487993}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the frame loop"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846488039}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs but each"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846488140}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" frame `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846488181}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world.config"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846558146}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846558248}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"peed` is 2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846558316}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846559257}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".2s should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846669896}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" advance"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846670025}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~2."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846670053}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 gens. Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846670314}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nMaybe the **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846705930}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"frame loop crashed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846706013}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"** after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846706258}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846706304}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" interactions? `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846774469}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"errs` empty."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846774570}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could be request"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846774641}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AnimationFrame stops"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846774921}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846836882}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" headless when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846836982}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page not actively"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846837109}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rendering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846837364}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? But auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846890907}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run worked"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846891237}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846891301}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846891356}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-time and produced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846971337}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846971422}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846971580}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" that case"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124846972685}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page had auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847089628}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847089742}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847089825}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let me recall"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847090611}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `lead-record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847101727}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-02"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847101881}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` URL"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847101929}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `?gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847102081}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=40&speed=8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847209188}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` default running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847209269}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". It completed. For event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847209428}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test, initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847209576}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847240681}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 then actions.res"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847240782}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ume; maybe there"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847240936}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s a bug where `last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847240993}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Animation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847291560}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` timestamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847291673}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is huge and next r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847291792}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF dt computed weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847291898}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No.\n\nLook"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847349788}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at step"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847349833}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `btn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847349885}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-step`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847350701}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" advanced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847402776}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen 0"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847402881}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"→1, so manual works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847402942}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Event"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847405253}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847476107}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847476303}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+2"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847476346}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s still gen1. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847476386}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be because the `pause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847538066}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` called"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847538209}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after resume"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847538245}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not yet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847538601}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? We call"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847602415}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" resume,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847602733}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sleep 1200, pause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847602833}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then step"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847603012}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847657013}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847657107}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says gen 0 tick"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847657246}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847657382}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847722130}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847722272}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847722395}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pause happened"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847722436}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" before any"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847812202}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rAF because the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847812244}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser's r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847812292}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF was severely throttled?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847812351}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" But the page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847849885}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" had rendered"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847849985}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initially"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847850028}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847850890}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847914797}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less with CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847914948}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P may throttle background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847915239}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tabs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847915356}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The page is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847996981}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847997102}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" active tab; r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847997171}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"AF should run at ~60"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124847997669}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"f"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848051518}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ps when there's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848051668}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a compositor. In"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848051794}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848051921}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848111240}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test, it did"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848111364}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because no preceding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848111573}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848111819}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" CDP operations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848202022}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Hmm."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848202066}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Maybe CDP operations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848202104}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" block"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848202323}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rendering"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848238536}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848238831}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" commands"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848238873}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" execute; but we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848239040}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sleep 1200ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848318868}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848319065}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" commands,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848319133}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848319240}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nCould"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848382345}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be that after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848382391}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" opening"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848382531}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the drawer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848382598}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/un"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848447688}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"folding, something"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848447740}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets paused"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848447875}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? No.\n\nMaybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848447923}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `state.paused`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848564320}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" isn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848564440}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t the only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848564534}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848564746}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `frame"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848590480}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"()`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848590600}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848590651}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848591413}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"world`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848670415}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848670489}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" finished?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848670531}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no.\n\nPerhaps `__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848671216}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848723751}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVARIUM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848723854}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"__.actions.resume` is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848723926}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overridden? No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848724719}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nWait: boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848785505}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s `sync"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848785765}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Play"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848785875}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"back` calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848785918}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `CONTROLS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848850928}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".setRunning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848851017}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(running)`;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848851117}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier's `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848851172}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"setRunning` maybe **"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848920611}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pauses controls or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848920656}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" calls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848920706}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ctx"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848921709}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".actions.pause()"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848981058}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?** Let's inspect controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848981189}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848981315}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Running. It may toggle"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124848981372}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" state; probably"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849055704}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not. Let me"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849055841}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grep."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849055908}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_00x6dkn0aruhwfm6g9qt5dnj","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849056074}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849056157}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849056207}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849056249}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849056297}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849075663}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849075788}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849075866}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849076164}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849094340}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849094441}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849094521}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849094720}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849120493}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849120825}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849120929}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849121098}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849121223}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849121624}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849121727}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849121824}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849134382}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849134727}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849134862}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849135156}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849155778}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849156113}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849156216}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849156435}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849157310}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849157491}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849157770}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849157875}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849179619}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849179789}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849179888}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849180118}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849204411}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849204589}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849204676}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849205175}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849247377}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849247455}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849247502}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849247630}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849247815}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849248007}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849248070}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849248180}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849257501}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849257652}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849257720}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849258139}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849264722}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849264789}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849264851}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849265051}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Running"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849266140}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849266223}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849266275}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Finished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849268958}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849301739}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849301821}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" resume"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849301965}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849302040}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"actions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849315433}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849315559}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ause"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849315608}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849316427}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"actions"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849321710}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".res"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849321825}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ume"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849321873}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849321976}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849322897}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849322959}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849323143}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849323196}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849355058}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849355115}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849355221}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849355262}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849385742}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849385803}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849385932}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849385979}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849386262}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"112"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849386379}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849386540}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849386616}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"121"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849408490}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849408556}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849408609}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849410068}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849410105}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849410326}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849410372}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849411553}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849417105}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849417180}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849417257}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849417337}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849443278}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849443373}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849443429}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849443997}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849454663}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849454844}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" set"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849454903}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Running"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849454957}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" behavior"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849522561}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849522785}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":33172,"ts_us":1793124849523229}}

data: {"id":"c18b2b421c70d4b04fd66710b8ec5c56","object":"chat.completion.chunk","created":1793124843,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":278837,"completion_tokens":1068,"total_tokens":279905,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":273664,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":921,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":33172,"ts_us":1793124849530724}}

data: [DONE]

