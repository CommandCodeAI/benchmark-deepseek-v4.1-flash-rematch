data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123099922739}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100026480}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me check runTick and how"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100026518}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100026552}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/finished/h"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161090}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"istory interplay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161122}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161153}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_2c4tv1csuzvmpu6yjwcflrza","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161319}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161355}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161418}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161469}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161510}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161540}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100161569}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162193}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162224}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162251}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162283}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"940"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162315}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162349}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"990"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162377}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162404}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162432}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162469}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162534}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162559}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162639}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162673}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162701}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162721}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162749}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162777}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"300"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162796}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162825}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"345"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162900}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162932}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100162964}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100163016}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100163055}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100163084}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100195477}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100195614}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100195653}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100195707}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100211910}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100211939}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100211973}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100212029}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100213151}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100213183}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Tick"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100213220}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100213282}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" world"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100242595}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" creation"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100242643}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100242691}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100242726}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":1524,"ts_us":1793123100438628}}

data: {"id":"c7c7bdd85a1c38d415a5d97ff4d15e9f","object":"chat.completion.chunk","created":1793123099,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":66632,"completion_tokens":99,"total_tokens":66731,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":66048,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":14,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":1524,"ts_us":1793123100438690}}

data: [DONE]

