data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024170810}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Final verification","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024258638}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" is","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024258723}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" complete. Task-3","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024258802}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" marked completed","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024338487}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n\n## Final","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024338548}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" result —","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024338596}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" PASS","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024338654}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"\n\n**Deliverable","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024400337}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":** `round","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024400414}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 1/index.html` sha","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024400469}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"256 `f820","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024400540}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"f20a872901","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024468619}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"d92c5","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024468831}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"b7ac39ccc4","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024468912}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"e3ae88c2","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024470642}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ad121b","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024556633}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"6d82b0847","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024556683}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"b31147b4d","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024556778}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"7e0` (313","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024556854}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".7 KB /","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024628994}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 9,049 lines),","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024629086}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" confirmed byte-","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024629161}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"identical and stable","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024629218}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" before/after","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024711730}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" the run","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024711821}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n\n**Matrix:","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024711893}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 69/69 checks PASS","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024711976}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":",","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024790617}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 0 failures","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024790678}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"** — engine ","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024790712}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"20/20, static","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024790774}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 8/8, browser","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024922719}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 41/41.\n\n**","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024922807}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"Ar","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024922878}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"tefacts (","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024922932}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"all under my","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024994625}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" write scope):**\n- `","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024994716}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"verify/REPORT.md`","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024994771}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" — PASS/FAIL matrix","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128024994842}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" by","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025055370}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" area, §","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025055437}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"12","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025055492}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" acceptance mapping","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025055549}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", documented deviations","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025144069}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", screenshot list","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025144119}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", visual","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025144171}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" inspection, remaining","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025144213}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" risks\n- `verify/res","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025211549}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ults-{engine,","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025211615}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"static,browser}.json`","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025211657}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" — machine-readable evidence\n-","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025211728}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" `shots/","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025272972}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"verify-*.png` —","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025273022}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 17 screenshots:","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025273064}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" initial 1440","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025273147}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", mid-run","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025332524}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", 4 catastrophe","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025332572}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" moments, record","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025332616}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 1440, record ","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025332661}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"1280, initial 128","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025384466}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"0/1024, fast","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025384511}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" record, no-c","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025384564}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"atastrophe record","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025384606}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", reduced-motion","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025436566}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" record\n- `verify/","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025436618}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"verify harness`","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025436648}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" — dependency","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025436700}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-free CD","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025558133}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"P driver","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025558182}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", in","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025558259}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-page probe, node","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025558332}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":vm engine loader","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025699964}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", suites,","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025700040}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" module","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025700098}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" QA,","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025701058}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" report generator,","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025768831}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" README\n\n**Evidence","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025768908}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" highlights:**","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025768961}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" one","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025769003}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" file /","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025813794}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" zero external","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025813859}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" requests; auto","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025813917}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-start →","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025813964}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" natural 40","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025869426}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-gen auto-end →","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025869473}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" THE RECORD in ~","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025869517}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"20s","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025869584}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with zero","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025941989}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" console/page","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025942045}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" errors; ","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025942228}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"4 catastrophes","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128025942301}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" with aria","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026028110}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-live banner","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026028173}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", wax","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026028209}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" seals","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026028253}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", ledger entries","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026097958}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", wash,","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026098014}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" conditions","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026098065}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":", chart markers","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026098129}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"; full","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026156967}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" keyboard/","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026157067}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ARIA/focus/t","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026157117}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ooltip/fold behavior","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026157210}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":";","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026200141}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" all","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026200260}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 12","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026200512}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" drift","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026200617}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" cells","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026257638}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" + census","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026257725}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" chart","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026257804}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" at proper","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026257863}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" backing size; ","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026349831}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"1440/128","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026349896}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"0/1024 fit;","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026349953}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" reduced motion","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026350060}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"; live-world","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026429481}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" hash proven","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026429548}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" identical to a fresh","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026429601}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" headless reference world","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026429648}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" (render","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026489495}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"er/controls/","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026489576}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"playback purity); default","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026489662}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" seed 1901","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026489817}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" verified end","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026607333}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-to-end with `?seed","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026607388}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"=1977` still deterministic","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026607470}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":".\n\n**Non-block","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026607527}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"ing risks recorded","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026692135}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":":** head","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026692201}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"less engine ~","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026692270}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"14× real","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026692335}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"time (","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026746613}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"not sub","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026746693}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-second),","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026746793}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" expected","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026746878}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" node","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026833354}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"↔Ch","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026833408}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"rome float divergence","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026833464}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" over","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026833513}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" full runs","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026901248}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" (within","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026901323}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-engine determinism exact","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026901373}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"), ","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026901469}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"25 low","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026994367}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-contrast nodes","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026994433}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" dominated by decorative","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026994487}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" 6.","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128026994531}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"5px seal","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027054294}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" initials, dial","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027054372}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" pointer","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027054437}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"-drag not automated,","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027054488}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" and the","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027101571}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" brief","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027101677}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"'s §","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027101731}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"5 table","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027101780}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" still says","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027171226}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" default seed ","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027171295}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"1977 while §","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027171332}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"7/§9","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027171371}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" say ","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027254093}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":"1901 (docs-only","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027254136}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" inconsistency). Lead needs","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027254176}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"content":" no reass","role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":35093,"ts_us":1793128027254210}}

data: {"id":"417c58f9ab2b23be341a0a5e7f08a4b6","object":"chat.completion.chunk","created":1793128024,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"content":"embly.","role":"assistant"},"finish_reason":"stop"}],"system_fingerprint":"","usage":{"prompt_tokens":380028,"completion_tokens":531,"total_tokens":380559,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":379520,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":35093,"ts_us":1793128027315266}}

data: [DONE]

