data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413288424}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413328484}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4: vertical scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413328569}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1314,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413329143}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrollWidth "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413397961}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1024 (no horizontal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413398831}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":")"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413398924}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — acceptable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413398962}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" degrade"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413484612}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413484672}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"vertical stacking"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413485977}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413486119}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow wait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413574180}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413574271}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier final. Meanwhile inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413574340}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final live"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413577347}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440 image"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413660876}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to ensure official"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413660945}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413664046}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413664115}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" looks good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413664247}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413664371}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1280"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413664524}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":","},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413750462}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024 maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413750611}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413750690}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_0jawjn2877fn11f59zygvl7l","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413750788}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413750954}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413751040}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413751108}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413756632}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413756707}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413761552}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413762406}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413762497}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413762617}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413772382}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413773284}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413773395}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413773502}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413789599}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413790643}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413790775}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413790948}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413809209}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413810125}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413810221}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413810271}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413823478}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413824502}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413824633}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413824730}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413835023}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413835875}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413835950}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413835995}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413841070}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413841167}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413841292}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413841386}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413853498}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413854499}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413854626}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413854711}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413869731}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413870690}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413870817}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413870912}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413926671}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413926778}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413926879}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413926976}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413927098}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413927205}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413932805}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413932902}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413932996}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413933152}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413933290}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413933401}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-l"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413933494}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ive"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413945188}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413945307}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413945399}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413945485}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413945586}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413945670}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9285,"ts_us":1793127413957494}}

data: {"id":"a8dbe30a990357dc0b2aecc9adc99760","object":"chat.completion.chunk","created":1793127413,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":355413,"completion_tokens":152,"total_tokens":355565,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":353920,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":62,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":9285,"ts_us":1793127413989935}}

data: [DONE]

