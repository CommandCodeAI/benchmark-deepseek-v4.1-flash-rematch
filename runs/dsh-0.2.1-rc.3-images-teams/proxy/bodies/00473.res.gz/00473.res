data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871318189}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871419327}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871419396}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" task-2 complete. Get"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871419443}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest revision first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522218}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522285}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yv51zbddr4zuc2wklc86tdt9","type":"function","function":{"name":"team_task_get"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522353}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522484}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522552}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522615}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_id"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522672}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522735}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522829}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871522889}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"task"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871523014}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871523071}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871548293}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871548347}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":67903,"ts_us":1793126871548452}}

data: {"id":"ba1379d89944bf945f2901727a1fb509","object":"chat.completion.chunk","created":1793126871,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":281566,"completion_tokens":54,"total_tokens":281620,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":280192,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":12,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":67903,"ts_us":1793126871555183}}

data: [DONE]

