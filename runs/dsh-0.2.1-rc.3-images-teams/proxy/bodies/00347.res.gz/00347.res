data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278574458}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Excellent"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278621035}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": all flows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278621095}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" pass. Note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278621966}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278685991}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"play` gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278686041}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278686077}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5 after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278686126}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1.1"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278758573}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278758629}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278758871}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278758948}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (expected"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278827795}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~3 gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278828109}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; got"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278828153}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5 because earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278828206}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" steps/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278887249}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"operations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278887295}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and maybe rec"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278887338}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ast note"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278887379}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278959459}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine).\n- Re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278959512}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cast"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278959724}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sets seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125278959781}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 42, gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279010492}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0, note visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279010620}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279010811}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" opens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279010863}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", back/re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279067820}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"open works, replay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279067915}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279068109}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed, new seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279068242}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279144805}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Folded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279144895}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tab order"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279145591}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sk"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279145650}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ips folio controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279204532}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279204628}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Folio 0) —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279204835}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good.\n- Slider"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279205210}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Home/End"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279361913}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and dial Home"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279362011}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/End work.\n- T"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279362138}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oggle works"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279362405}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Hover tooltip"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279384643}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works.\n- No errors"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279384785}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nOne minor thing:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279384935}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after replay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279385178}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279423196}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed, gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279423286}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 after "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279423458}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"600ms; auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279423500}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-r"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279485081}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"uns."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279485164}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n- `seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279485347}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Meta` changed to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279485476}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 42; but `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279652595}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"#meta"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279652651}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-observation` stays "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279652745}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0047. fine.\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279652886}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" After `new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279652935}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279653019}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279653375}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 7671 random"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279653429}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; okay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279715434}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279820130}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279820182}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", `page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279820245}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"H` 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279820299}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279820359}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll.\n\nNeed test default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279820442}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279820497}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279862353}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279862401}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"end at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279862436}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279862471}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 2 without interactions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279901594}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279901641}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279901851}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~20s; we"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279901896}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" know auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279979638}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" works with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279979736}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed 8. Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279980067}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125279980321}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 15s"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280049074}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280049236}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" speed 2 and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280049291}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280049478}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gen ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280119695}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"30"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280119764}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280119878}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" conclude"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280119986}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; not necessary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280182521}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But requirement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280183068}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto-start"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280183145}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280183213}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" initial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280259664}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280259792}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" when"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280259956}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280260020}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280299383}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0; earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280299565}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280299879}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280299925}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" showed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280371563}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" complete"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280371659}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed test in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280371734}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-page reload determinism."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280371817}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Also engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280429159}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runtime measure"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280429507}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280429575}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier.\n\nNeed test reduced"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280429645}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-motion:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280488993}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" emulate media"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280489077}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reduce"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280489204}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", check page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280489295}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" loads/no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280553894}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" visual break"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280554155}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", transitions"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280554221}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" off; can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280554282}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" capture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280620811}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280620948}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1024 width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280621208}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe. We'll do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280621399}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" later"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280696716}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNow, current"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280696805}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" biggest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280697799}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" open items"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280697901}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n- 1280×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280920193}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"800 no-sc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280920271}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"roll fix (atelier).\n- Spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280920336}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280920431}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/label refinement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280950618}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (atelier).\n- Chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280950710}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280950897}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" possible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280950974}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" refinements.\n- Final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280981412}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembly, QA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280981507}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" report"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280981924}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", docs.\n- Maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125280982032}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" add"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281018395}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a README/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281018508}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"round"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281018723}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281018780}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 notes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281113420}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? User"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281113541}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281113639}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" asks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281113945}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281160133}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; no READ"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281160230}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ME required. Could include"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281160450}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281160713}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" necessary;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281246431}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281246545}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" short `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281246630}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"round"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281246679}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1/N"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281320172}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"OTES.md` would"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281320278}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281320437}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extra, not requested"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281320489}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Single-file"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281369517}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" deliverable; keep"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281369620}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clean.\n\nNeed check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281369774}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281370037}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" external references"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281444298}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281444397}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HTML:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281444767}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assemble"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281444818}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; search"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281618271}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281618338}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281618448}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"http`, `src="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281618521}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`, `@import`, `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281686629}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"url(`. Also"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281686709}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281686784}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" etc. Ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281686843}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier will."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281760584}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We'll do"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281760691}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281760822}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" HTML"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281761060}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" accessibility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281835107}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" issues"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281835191}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": duplicate IDs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281835368}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281835742}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" python"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281909756}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" parse; `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281909853}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"id"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281910160}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281910218}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" list duplicates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281999388}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Also label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281999484}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281999571}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of controls."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125281999614}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's inspect controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282042744}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" row"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282043087}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria labels for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282043197}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282043250}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282113669}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" words"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282113757}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282113966}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282114018}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rows contain"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282214293}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282214375}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; accessible names"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282214439}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282214501}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" native"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282244614}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ranges via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282244701}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria-labelledby label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282244766}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; labels"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282244829}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"Mutation rate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282309262}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" etc. Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282309346}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282309408}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" dials,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282309468}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria-labelledby label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282372756}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". T"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282376193}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"oggles role="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282376285}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"switch with aria-labelled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282376365}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"by. Seed ste"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282441008}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"pper input"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282441089}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe. Fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282441158}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed check canvas"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282441203}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/ch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282514551}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"art accessibility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282514672}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" labels."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282514811}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good.\n\nNeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282514879}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verify keyboard Escape"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282581978}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" closes tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282582053}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tip *"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282582372}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"without hiding"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282582445}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page visibility"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282654207}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"* in real"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282654281}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browsers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282654335}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; yes."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282654388}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" In head"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282717995}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"less, Page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282718177}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".b"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282718347}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ringToFront rest"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282718413}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ores.\n\nNeed test `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282776181}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"prefers-reduced-motion"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282776249}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`: set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282776359}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" via CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282776679}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P Em"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282847236}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ulation.setEmulatedMedia features"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282847287}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282847528}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282847602}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; ensure no JS"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282902845}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" errors,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282903161}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe animations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282903219}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" instant."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282903396}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282992671}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed test page at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282992796}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024 width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282992991}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": layout perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125282993077}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stacks fol"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283046086}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"io below and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283046177}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283046418}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"s; requirement degrade"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283046479}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Check no broken"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283139791}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overlap. Later.\n\nNeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283139848}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check `#"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283140166}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"record` outcome if"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283140242}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" all species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283195507}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinct or"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283195791}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" only one"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283195876}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283195932}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handles; chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283262820}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"wright"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283263086}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283263142}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" handle nulls."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283263508}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could test with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283320307}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283320359}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" known"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283320447}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to cause"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283320729}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" extinction at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283389395}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283389511}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"40 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283389920}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"e.g., node"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283389987}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 114"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283451036}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" worst"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283451256}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" -215"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283451462}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283451500}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283519155}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" unknown); use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283519299}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" query"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283519563}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283519729}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283582408}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Not essential but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283582637}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nice."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283582689}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Could"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283582768}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283648215}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283648275}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seed=114&gens"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283648377}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"=40&speed=8"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283648472}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` to ensure dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283725692}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" doesn't crash."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283725962}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Later.\n\nNeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283726105}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check catastrophe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283726199}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" disabled"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283803144}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283803239}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?cat=0`):"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283803521}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283803670}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", seals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283851702}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" none; record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283851835}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" weather"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283852089}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" roster says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283852165}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283915096}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophes;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283915200}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" charts no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283915363}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" markers. Good likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283915414}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed check interval control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283992554}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283992857}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283992905}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" reschedules"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125283993174}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; yes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284062206}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nNeed check generations control"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284062276}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" live: change"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284062530}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 10"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284062591}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284129324}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at gen"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284129715}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 15 should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284129838}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" end; test via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284129892}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" control? We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284196217}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tested set"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284196383}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Param indirectly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284196589}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Not generation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284196809}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ending"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284267950}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Could test in final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284268075}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" QA.\n\nNeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284268309}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inspect stats/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284268356}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rait"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284319558}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" chart"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284319701}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 40"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284319914}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" gens; looks"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284319960}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" good.\n\nNeed check all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284404515}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284404591}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" catastrophes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284404646}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" types appear"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284404704}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284464306}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 190"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284464409}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284464548}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run: events"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284464802}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plague, wildfire"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284533360}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", drought"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284533905}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", plague. Yes all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284533994}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 3.\n\nNeed verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284534173}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284603100}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-l"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284603183}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ive` banner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284603447}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" text;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284603636}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" yes.\n\nNeed check"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284670931}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page title"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284671031}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/fav"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284671192}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"icon?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284671265}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no favicon,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284727834}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284727880}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (no external"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284727965}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" request;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284728163}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" browser may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284789738}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" request /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284789791}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"favicon.ico? For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284790007}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file:// no"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284790327}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284864521}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier says "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284864636}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1 network request.\n\nPotential requirement"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284864815}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": \"use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284865124}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284908909}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeded PR"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284909132}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"NG for all randomness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284909219}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" so same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284909570}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed always reproduces same"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284973731}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run\". Code engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284973862}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses seeded"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284974370}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PRNG for all"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125284974436}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sim randomness; render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285053724}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"er visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285053777}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" texture"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285053820}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses visual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285053871}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" PRNG seeded from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285111102}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world.se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285111282}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ed; controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285111355}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285111648}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"line"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285181322}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses l"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285181422}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cg seeded?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285181662}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" They use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285181830}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lcg perhaps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285251686}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with seed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285252025}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" from"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285252139}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" spark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285252190}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" data. No"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285307621}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Math.random in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285307676}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine. Boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285307773}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" uses Math.random only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285307826}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for newSeed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285496009}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (UI"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285496097}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" action"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285496283}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") — that's"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285496475}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not simulation"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285523397}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285523801}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" okay. Chartwright may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285523856}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" use Math.random for j"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285524145}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"itter? Need check; should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285562206}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be seeded for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285562305}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" charts. Search for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285562486}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Math.random in src."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285562675}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_yz4s9iqmw0nnimtx7pikkhl7","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285604935}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285605054}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285605260}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285605441}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285618770}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285618979}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285619085}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285619153}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285633693}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285633822}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285633940}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285634038}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285647079}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285647164}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285647212}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285647357}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285662799}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285662881}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285662937}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285663102}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285679420}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285679475}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285679579}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285679643}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285694534}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285694588}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285694705}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285695055}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285706375}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285706579}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285706654}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285706754}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285724682}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285724761}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285725054}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285725107}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285739822}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285740556}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285740601}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285740645}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285758038}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285758145}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285758203}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285758252}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285771533}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285771788}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285772362}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285772418}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285789601}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285789723}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285789850}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285789909}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285790244}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285790300}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285790469}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285790522}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".random"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285818004}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285818124}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285818221}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285818338}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285836246}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285836412}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285836461}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285836665}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285860597}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285860770}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285860818}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285860950}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285870184}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285870276}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"random"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285870400}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285870644}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"new"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285870948}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285871005}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285871164}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Date"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285871243}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285900797}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285900922}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285901012}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285901522}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285914229}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285914349}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285914486}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285914641}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285932234}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285932356}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285932411}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285932584}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285962047}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285962176}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285962255}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" external"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285962348}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ref"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285971229}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285971337}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285971390}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" shell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285973117}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285990103}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285990318}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285990365}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125285990490}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286006790}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286006902}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286007046}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286007101}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"https"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286019638}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"?"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286019843}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"://"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286019886}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286020123}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286020677}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286020820}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"href"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286020871}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286021110}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"@"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286036057}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286036112}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286036261}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"url"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286036323}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286073011}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286073080}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286073182}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286073241}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286084218}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286084298}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286084365}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/*"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286084424}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286110874}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286110938}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286111044}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286111171}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286111683}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"30"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286111909}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286111984}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286112074}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286140500}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286140548}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" duplicate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286140635}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ids"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286140903}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286140957}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286141005}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" python"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286141047}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286141092}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286141524}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286141567}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286141618}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286141668}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286160546}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286160610}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286160700}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",col"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286160999}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lections"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286174842}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286174889}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286174933}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286174973}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"open"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286192255}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286192380}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286192490}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286192769}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hell"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286192903}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".html"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286193004}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286193169}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286193236}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286213901}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286214077}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286214173}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286214296}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286228710}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"all"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286228863}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286228933}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\\\"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286229558}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bid"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286229603}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286229811}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286229864}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"^"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286229950}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\"]"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286249443}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"+"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286249593}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286249644}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286249825}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286261323}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286261371}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"du"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286261523}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286261591}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286284775}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286284875}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286284925}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286285170}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286303776}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" in"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286303888}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" collections"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286304030}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".C"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286304308}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ounter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286304415}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286304491}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286304719}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286304755}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"items"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286315505}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286315829}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" if"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286315886}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286315933}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286332428}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286332637}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286332688}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286333261}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286340993}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286341083}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286341288}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286341343}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286341695}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ids"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286341762}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286341851}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286342035}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"du"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286362347}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286362609}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286362645}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"du"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286362773}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ps"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286381183}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286381228}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"print"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286381287}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286381387}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"scripts"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286393227}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286393347}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286393403}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286393817}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286412084}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"all"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286412182}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286412567}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286412633}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286435900}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"script"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286436266}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286436330}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286436375}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286443442}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286443510}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"styles"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286443632}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286444059}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"len"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286445237}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286445547}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".find"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286445617}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"all"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286446074}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286466613}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286466662}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286466770}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"style"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286466814}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286478415}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286478669}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")))\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286478717}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"PY"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286478988}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286499447}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286499592}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286499705}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286499802}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286517875}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286518190}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286518252}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Aud"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286518289}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"it"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286535357}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" randomness"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286535448}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286535710}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" external"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286535751}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" references"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286683307}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286683369}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":34785,"ts_us":1793125286683504}}

data: {"id":"3bed67540a62cc0e58463af052963aa9","object":"chat.completion.chunk","created":1793125278,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":300604,"completion_tokens":1346,"total_tokens":301950,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":296448,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":1052,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":34785,"ts_us":1793125286689088}}

data: [DONE]

