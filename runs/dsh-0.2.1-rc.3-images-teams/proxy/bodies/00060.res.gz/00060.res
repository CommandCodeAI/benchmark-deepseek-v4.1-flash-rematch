data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123088920713}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Now"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123088961370}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test engine with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123088961488}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" node."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123088961996}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Write a quick tuning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089048929}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089049032}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089049083}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089049313}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Ver"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089098750}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifier owns verify/."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089098837}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I'll use /"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089098935}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tmp/engine-test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089098999}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".mjs or a scratch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089158517}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" script"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089158648}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089158717}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" put `tools"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089158999}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089234601}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"une.mjs`? My"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089234722}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scope as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089234843}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead; new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089234930}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" file fine. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089303411}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s create `/tmp/v"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089303526}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"iv-engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089303671}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-test.mjs` to avoid"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089303708}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" workspace"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089374159}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" writes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089374378}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Load"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089374431}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" engine.js via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089374640}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089451378}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089451487}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"vm ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089451687}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"globalThis"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089451830}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Run"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089511010}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" multiple seeds"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089511056}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", print history"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089511183}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" summaries"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089511587}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", benchmark"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089575278}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", determinism"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089575580}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nTest:\n-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089575690}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" create world"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089575759}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seed 197"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089644528}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"7 default"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089644621}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 40 gens,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089644689}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" runHeadless,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089644749}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" print final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089752701}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089752766}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" min/m"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089752837}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ax counts per species"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089752936}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", event list"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089792913}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", diversity"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089793091}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", benchmark ms"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089793148}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", hash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089793567}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Multiple"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089969864}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeds 1.."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089969935}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10: final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089969991}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" counts, extinction flags"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089970083}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", min prey"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123089970975}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", etc"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090139222}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n- Check determin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090139301}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ism hashes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090139425}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for two runs"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090145491}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet's run."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090176988}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_9a5iieikweol4rjhtzqr6mwr","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177060}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177491}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177543}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177587}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177646}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177689}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177733}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177773}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177813}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177853}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177901}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090177944}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090178399}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090178479}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090178548}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090178606}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090178664}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090178786}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090178870}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090179299}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090179380}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090179451}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090179521}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090179559}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090179757}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090179853}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180193}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180249}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180362}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180416}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180475}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180543}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180604}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180691}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090180734}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090181187}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090181254}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090181318}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090191801}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090191865}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090191991}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090192097}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090205194}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090205314}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090205449}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090205513}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090227281}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090227338}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090227542}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090227626}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090228018}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090228110}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090228246}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" >"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090228407}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090258228}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090258305}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090258447}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090258514}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090258606}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090258708}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090258795}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090259493}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <<"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090271653}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090271761}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090271927}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090271982}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090293461}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090293525}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090293595}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090293679}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sync"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090294735}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" }"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090294846}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090294917}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090295118}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090317775}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090317987}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090318072}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090318711}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"import"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090323876}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090323955}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" from"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090324056}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090324121}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090324235}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090324393}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090324459}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"';\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090324523}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090340670}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090340764}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090340805}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090341660}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"File"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090363878}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Sync"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090364032}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090364076}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090365008}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090377525}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090377651}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090377782}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090377832}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"utf"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090396253}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090396355}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"');\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090396436}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090396588}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090413928}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090414100}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090414219}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090414288}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090433660}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" performance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090433710}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" };\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090433792}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090433842}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".gl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090448162}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"obal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090448303}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"This"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090448393}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090448444}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090469860}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090469979}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090470043}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090470121}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"indow"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090491422}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090491487}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090491642}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090491747}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090514912}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090515022}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Context"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090515170}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090515251}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090536818}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" vm"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090536888}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090536988}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090537054}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Context"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090546576}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(code"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090546648}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090546692}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090546809}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090547612}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090547694}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090547761}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090547933}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ctx"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090562388}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090562635}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090562729}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090562820}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090581796}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090581904}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENG"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090581962}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"INE"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090582073}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090600167}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090600225}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090600318}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090600367}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090614166}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" performance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090614242}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090614345}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"();\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090614415}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090636392}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rows"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090636444}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090636493}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" [];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090636575}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"for"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090637461}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090637549}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"let"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090637664}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090637715}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090677121}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090677184}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090677233}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090677387}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090677636}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" <="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090677723}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090677767}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090678117}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090687541}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090687681}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"++)"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090687738}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090687851}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090704773}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090704889}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090704971}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090705016}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090706668}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090706714}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090706878}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090706956}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090726047}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090726148}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" generations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090726215}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090726300}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090737455}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090737539}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090737661}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090737738}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090756658}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090756735}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090756858}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090756905}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090757337}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090757426}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090757598}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090757654}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090773707}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090773780}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090773834}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090773945}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090790782}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090790837}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090790890}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090791018}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090791103}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090791232}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090791274}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090791474}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090895573}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090895651}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090895707}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090895835}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".filter"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090896589}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090896646}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090896705}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090896765}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090896809}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090896848}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090896886}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]=="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897021}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897338}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897427}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897509}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897575}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897642}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897710}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897773}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090897887}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090904703}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090904795}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" =>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090904886}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090906069}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090926190}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".min"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090926270}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(..."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090926355}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090926521}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090957262}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090957315}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090957356}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090957481}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090957923}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090958062}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090958135}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"])"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090958346}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090961726}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" Math"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090961841}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".max"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090962010}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(..."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090962059}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090974666}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090974730}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090974860}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090974908}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090975026}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090975123}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090975677}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[k"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090975732}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090995867}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"];\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090995925}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090996011}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" rows"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123090996086}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".push"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091014770}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091014898}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091014946}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091015082}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091047140}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091047221}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091047278}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".count"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091047394}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091069274}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091069371}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ranges"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091069414}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091069739}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091087900}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091088153}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091088227}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091089022}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091114513}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091114614}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091114697}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091114898}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091121224}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" herb"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091121309}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091121468}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091121519}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091121679}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091121820}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091122031}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091122092}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091158944}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091159047}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" carn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091159148}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091159321}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091159440}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091159639}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091159696}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091159850}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091177277}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091177457}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091177526}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091177597}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091229784}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091229891}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" {"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091229975}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091230050}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091230786}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091230841}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091231035}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091231105}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091240140}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091240227}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091240331}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091240515}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091240709}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091240782}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091240838}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091240966}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091264137}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091264221}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091264287}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091264367}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091279134}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091279202}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091279254}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091279297}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091280397}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091280578}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091280849}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"')"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091280895}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"},"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091289584}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091289637}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091289781}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091289833}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091311008}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091311085}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091311185}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091311283}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"=>"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091327862}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091327979}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091328042}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091328135}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091348206}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091348286}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}:"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091348370}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"${"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091348446}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091364596}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091364650}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}`"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091364805}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091364852}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091365258}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091365349}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"','"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091365408}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091365476}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" div"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091381352}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091381420}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091381514}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"[h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091381691}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091399212}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091399363}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091399421}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091399542}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091416379}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iversity"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091416630}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091416697}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091416762}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091433399}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091433465}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091433528}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" gens"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091433671}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091468028}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091468122}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".g"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091468290}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"eneration"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091468347}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091481357}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" fin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091481433}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091481632}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091481718}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091483455}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inished"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091483536}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" });\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091483606}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091483690}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091514714}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".table"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091514788}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091514837}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rows"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091514943}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091529714}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091529880}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091530070}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091530129}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091553475}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091553527}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091553694}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091553731}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".se"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091554292}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091554353}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091554715}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091554761}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091571254}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091571306}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091571383}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091571589}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091586837}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091587012}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091587063}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091587159}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091599705}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091599761}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091599811}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091599898}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091614975}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091615040}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091615145}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091615417}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091616022}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091616076}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091616136}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091616212}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091638955}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091639032}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"inal"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091639093}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091639135}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091649374}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091649438}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091649493}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091649647}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091665571}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091665680}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091665785}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091665857}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091686747}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"anges"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091686804}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091686847}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091687052}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091696012}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091696205}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091696343}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091696391}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091697279}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091697329}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091697371}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091697487}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"anges"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091715080}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091715138}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091715234}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091715337}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091730691}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091730760}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091730813}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091731211}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Range"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091731829}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091731878}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091731980}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091732097}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"anges"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091745522}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091746020}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"arn"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091746095}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".join"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091746279}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091770347}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091770424}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091770485}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091770597}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091779803}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091779890}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091780105}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".f"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091780180}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091800386}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091800460}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091800556}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091800637}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091812999}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091813121}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091813257}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091813309}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091813428}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091813486}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091813599}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091813666}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".ext"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091832319}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091832409}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091832470}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091832633}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091852467}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091852595}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091852761}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091852812}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091852973}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" div"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091853038}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091853144}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091853190}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".div"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091884230}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091884284}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091884352}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091884450}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091908622}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091908691}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091908753}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091908869}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091923799}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091923869}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091923968}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091924028}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091936474}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091936530}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091936715}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091936812}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091959067}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091959155}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091959297}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091959356}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091971144}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091971210}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091971295}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091971401}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091971823}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091971892}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091971953}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091972056}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091987429}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091987518}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091987591}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123091987669}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092007474}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092007579}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092007663}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092007748}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092008890}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092009172}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092009252}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092009461}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092026226}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092026359}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092026490}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092026585}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092035444}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092035587}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092035692}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092036097}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092036189}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092036267}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092036343}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092036416}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092060632}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092060740}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092060824}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092060963}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092070444}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"const"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092070586}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092070701}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092070941}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092071043}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092071238}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092071325}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092071472}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"({"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092085648}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092085750}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092085835}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092086013}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092108402}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092108533}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gener"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092108642}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ations"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092108855}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092109094}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092109199}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"});"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092109396}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092109490}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092128004}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092128124}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"less"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092128208}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092128393}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092146319}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092146419}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"40"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092146508}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":");\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092146626}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092146712}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092146787}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092147035}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092147117}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" determin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092176693}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092177007}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092177212}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092177346}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092206436}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092206517}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092206581}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092206735}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092206818}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092207023}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092207093}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092207154}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092354437}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092354553}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092354626}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092354742}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".hash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092421039}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"World"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092421163}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092421261}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092421347}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092434597}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092434655}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092434707}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092434770}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092441462}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092441558}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" E"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092441612}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092441719}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092456753}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mark"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092456843}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092456913}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"197"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092456988}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"7"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092470028}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092470500}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092470585}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"100"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092470647}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092471054}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092471104}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092471145}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092471187}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"el"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092523633}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"apsed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092523930}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092524020}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"12"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092524065}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" seeds"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092550288}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ms"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092550370}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092550449}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092550584}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"performance"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092552011}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".now"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092552140}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"()-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092552211}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092552309}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092556065}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092556145}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"to"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092556236}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Fixed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092556391}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092582692}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092582768}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092582850}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092582914}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092594750}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092594906}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"history"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092594959}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" entries"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092595057}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092598015}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092598150}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092598251}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092598358}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092599738}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".length"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092599784}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092599837}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092599949}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"first"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092601740}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092601787}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092601834}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092601963}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092602534}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092602588}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092602639}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092602729}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"["}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092603992}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092604130}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"]."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092604254}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tra"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092604379}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"its"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092610870}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092610920}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092610963}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092611123}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092613590}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092613838}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092613927}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092613988}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"),"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092615001}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092615150}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"last"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092615219}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092615329}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092615713}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092616710}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092616751}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092616819}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".h"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092617793}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"istory"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092619660}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".at"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092619747}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092619817}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092619877}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":")."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092619934}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tra"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092620054}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"its"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092620109}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092620163}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"her"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092620213}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092620278}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092620337}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ora"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092624827}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".s"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092624931}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"peed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092625048}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092625115}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"console"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092649315}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".log"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092649365}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"('"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092649439}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"events"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092649559}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" detail"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092663037}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"',"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092663124}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" JSON"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092663262}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".stringify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092663311}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(w"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092674346}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092674409}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092674468}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"vents"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092674622}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".map"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092674724}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"(e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092674857}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"="}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092674923}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":">("}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092675146}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092694296}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092694346}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092694453}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092694540}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"gen"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092713561}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092713627}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092713674}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092713783}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".type"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092725875}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092725957}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"aff"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092726019}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092726442}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092743690}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"affected"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092743757}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":",b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092743931}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"urned"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092744040}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":e"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092744785}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092744861}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"urned"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092744936}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Cells"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092745004}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}))"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092760813}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"));\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092760898}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"EOF"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092761086}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092761144}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"node"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092778902}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092778982}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"tmp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092779137}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092779199}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"iv"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092795280}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092795362}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092795420}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092795557}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092828355}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092828438}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092828503}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092829247}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092851665}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092851716}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092851772}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092851909}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Run"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092867135}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092867204}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" determin"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092867319}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ism"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092867379}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092882110}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ecology"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092882171}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" smoke"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092882213}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092882260}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092945333}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2478,"ts_us":1793123092945387}}

data: {"id":"1867050b67b85a27331f3d64fb6a5b11","object":"chat.completion.chunk","created":1793123088,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":104020,"completion_tokens":961,"total_tokens":104981,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":88704,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":166,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2478,"ts_us":1793123092945465}}

data: [DONE]

