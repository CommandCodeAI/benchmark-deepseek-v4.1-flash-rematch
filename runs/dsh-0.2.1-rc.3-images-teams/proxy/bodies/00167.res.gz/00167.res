data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781579649}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781579763}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" adds:\n1. `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781579806}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"#btn-record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781606744}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".record-link` in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781609541}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" colophon right"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781609637}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" —"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781609715}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" style it ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781622588}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781622751}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781622895}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781623107}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" [hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781713037}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"],"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781713110}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781713168}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/italic, ink"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781713224}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" underline hover"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781791091}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/focus, reset button styling"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781791164}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n2. Rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781791302}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" cursor label"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781791406}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clamp at end: `#"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781879354}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781879436}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-cursor.is-end ."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781879483}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rule__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781879521}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"cursor-label { transform: translate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781972089}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"X(-100%); }`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781972300}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and seals"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781972371}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clamp near "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123781972599}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100%: `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782012503}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"#rule-seals >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782012664}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" [data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782012706}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782012921}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"]`? Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782175859}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" says \"seals at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782175948}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100% should clamp inward"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782176079}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"\" — style"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782176271}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782215180}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rule__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782215758}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seal.is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782215848}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-end { margin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782215907}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-left: -"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782302449}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"11"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782302524}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782302580}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" }"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782302622}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`? Better: seals positioned"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782313758}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782313877}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" left; at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782313948}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 100% the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782314006}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" circle center is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782378260}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at edge, half"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782378326}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" outside. Use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782378399}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `#rule-se"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782378500}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"als > * {"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782449171}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782449271}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782449410}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" }` can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782449528}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t clamp"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782530349}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Provide"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782530486}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" class `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782530600}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"is-end` support"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782530703}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": `.rule__"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782610608}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"seal.is-end { margin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782610710}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-left: -11px;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782610825}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" }` (sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782610895}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ifts left so"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782718252}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" circle inside"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782718319}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). Also maybe `[data-at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782718470}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-end"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782718566}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"]`. Let me add support"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782790949}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for both `."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782791231}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782791271}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-end` and `[data"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782791715}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-end=\"true\"]`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782851602}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" on seals.\n\nAlso confirm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782851665}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782851968}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" received"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782852100}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then continue:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782928797}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782928865}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" now. Let me check at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782928994}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier-03.\n\nI'll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123782929051}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" batch"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783039323}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783039514}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot first"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783039881}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then CSS additions."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783039954}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_7o14675wii027pszwxb0tv6o","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783040085}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783040159}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783040202}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783040437}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783052069}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783052211}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783052290}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783052339}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783052687}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783052827}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783052970}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783053087}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783072930}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783073043}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783073112}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783073251}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783091953}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783092027}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783092073}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783092268}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783116874}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783116971}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783117037}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783117205}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783117355}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783117507}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783117689}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783117843}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783127009}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783127180}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783127271}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783127464}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783141341}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783141515}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783141745}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783141813}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783161498}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783161676}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783161760}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783161869}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783190093}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783190388}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783190469}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783190644}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783190825}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783190992}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783191144}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783191329}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783201554}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783201652}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783201732}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783201808}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783217176}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783217262}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783217341}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783217418}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"03"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783315215}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783315309}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783315477}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":5880,"ts_us":1793123783320245}}

data: {"id":"bab48d84898a6998706e3d69d6f7c2e5","object":"chat.completion.chunk","created":1793123781,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":194456,"completion_tokens":349,"total_tokens":194805,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":189184,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":261,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":5880,"ts_us":1793123783320423}}

data: [DONE]

