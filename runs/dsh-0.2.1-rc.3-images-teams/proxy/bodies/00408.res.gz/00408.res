data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931010186}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Good"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931062995}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". View final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931063108}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931063375}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot to confirm"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931116626}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" atelier update"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931116859}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" didn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931116898}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t reg"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931117233}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ress."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931197258}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_d1a9vzo3xyib1s8bhuee5ega","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931197659}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931198382}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931198443}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931198494}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931198540}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931198585}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931198655}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931220133}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931220380}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931220434}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931220660}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931235721}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931235829}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931236058}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931236103}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931237931}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931238264}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931238344}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931238411}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931425313}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931425368}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931427264}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931427347}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931427402}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931427451}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931427485}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931427532}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931427590}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931427639}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931472136}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931472221}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931472293}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931615132}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931615208}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931615240}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931616495}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931616546}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931616602}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931616664}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931616763}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931616851}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931616901}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931616934}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931708758}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931708823}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931708886}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931708968}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709023}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709087}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709141}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709318}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709364}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709416}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709459}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-final"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709502}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709573}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931709626}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931710183}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931710227}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931710266}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":42485,"ts_us":1793125931710309}}

data: {"id":"94eb9aa2b9dc697b637dad63ad4c46c4","object":"chat.completion.chunk","created":1793125930,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":320914,"completion_tokens":107,"total_tokens":321021,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":320000,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":18,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":42485,"ts_us":1793125931710418}}

data: [DONE]

