data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921052545}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Great"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921121992}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": gen "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921122086}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10, finished,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921122174}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921152199}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" false. Scre"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921153035}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"enshot from tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921153107}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921153199}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" was captured"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921247055}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921247827}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" load—"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921247946}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"maybe virtual"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921247996}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-time weird"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921292211}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". CDP screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921292996}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921293118}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" show record."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921293162}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Let's inspect lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921363402}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-cdp1.png.\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921364324}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" note scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921364476}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921364538}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" document"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921426038}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" height 809"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921427045}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" < innerHeight 700"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921427158}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? inner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921427237}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Height reported"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921501751}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 700 while window-size"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921502741}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440x900?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921502868}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Headless Chrome"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921502910}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" viewport maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921565743}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440x700"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921566796}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921566944}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" size includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921567000}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" toolbar? Actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921631796}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" innerHeight 700"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921631855}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). So screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921631899}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921631942}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1440x900 includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921695896}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" blank?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921696843}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The earlier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921696942}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921697019}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440x900 with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921776514}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921777495}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fitting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921777615}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921777658}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? The CD"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921832216}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"P inner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921833166}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Height 700 is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921833270}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" odd because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921833357}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I set window"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921898533}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-size 1440,900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921899601}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; headless new"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921899718}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" maybe"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921899785}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" window outer"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921969362}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921969496}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 200"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921970961}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"px? Not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123921971076}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sure. Scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922025294}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width 144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922026146}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 = inner"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922026274}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922026318}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":";"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922106680}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page fits"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922107568}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922107687}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" We need"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922107734}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" test at true"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922173879}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922174694}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"900 view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922174794}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"port using"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922174878}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922233415}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Emulation.setDeviceMetricsOverride"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922234319}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"` width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922234474}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1440 height 900"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922234556}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Then screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922301896}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922301975}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"spark:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922303564}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 0` — our"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922303602}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" selector may"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922363825}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not match atelier"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922364890}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'s sparkline"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922365018}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" class;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922365059}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" need inspect DOM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922449072}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922449991}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" children"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922451756}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 9. We"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922451804}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'ll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922501502}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922502459}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922502516}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922502613}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_7sftw6ys7x9j4axqrzeaksc7","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922543859}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922544872}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922544982}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922545079}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922567780}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922568607}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922568706}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922568756}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922568849}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922576057}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922576179}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922576234}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922581496}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922581595}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922581715}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922581786}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922612752}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922613654}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922613743}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922613866}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922624240}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922625291}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922625465}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922625510}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922630354}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922630445}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922630538}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922630575}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922630661}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922630768}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922642653}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922642761}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922642853}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922642973}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922643125}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922643208}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922652905}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922653002}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922655727}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922655798}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922655918}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922656038}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922656153}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922656217}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922672937}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922673820}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922673916}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922674015}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922693277}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922694073}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922694174}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922694287}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922705271}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922705373}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922707205}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"dp"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922707256}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922720440}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922720484}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922722314}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":4072,"ts_us":1793123922722399}}

data: {"id":"f831e54ae7dd5c58ba27cb07335b74b6","object":"chat.completion.chunk","created":1793123920,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":218121,"completion_tokens":326,"total_tokens":218447,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":215040,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":238,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":4072,"ts_us":1793123922771523}}

data: [DONE]

