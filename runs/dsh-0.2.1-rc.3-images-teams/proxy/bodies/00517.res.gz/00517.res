data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538319586}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538362589}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rule"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538362686}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"__cursor-label` CSS block"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538363011}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prior lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538432239}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not shown because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538432289}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sed pattern ended early"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538432464}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Let's view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538432534}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" lines"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538486118}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1118-114"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538486242}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538486552}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538486593}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_2alqo4256bhwhuj55e6qmuyk","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538519250}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538519430}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538519484}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538519837}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538532772}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538533007}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538533357}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538533418}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538534396}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538534557}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538535037}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538535086}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538552433}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538552599}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538552870}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538552919}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538571914}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538571993}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538572055}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538572207}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538583703}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538583799}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538583850}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538584280}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538601134}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538601253}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538601545}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538602014}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538602076}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538602149}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538602212}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538602720}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538628892}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538628988}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538629094}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538629172}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538645740}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538645952}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538646011}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538646435}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538646482}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538646933}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538646991}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538647038}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538659659}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538659854}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538659917}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538660239}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538675813}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538676032}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538676309}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538676404}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" sed"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538676787}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538676868}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538676927}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" '"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538677547}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"111"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538692790}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"8"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538693081}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":","}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538693188}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"114"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538693506}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"6"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538706238}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"p"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538706324}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"'"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538706479}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538706687}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538722023}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"design"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538722088}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".css"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538722371}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538722440}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538751676}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538751820}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538751876}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538752322}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538766204}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538766298}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538766344}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cursor"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538766987}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" label"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538784305}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" CSS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538784513}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538784754}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":54545,"ts_us":1793127538784837}}

data: {"id":"4675767931b0dbfea0ed4dd873c39f30","object":"chat.completion.chunk","created":1793127538,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":357571,"completion_tokens":144,"total_tokens":357715,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":356608,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":29,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":54545,"ts_us":1793127538840295}}

data: [DONE]

