data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667721399}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667828556}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4×768: scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667828614}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"H 1314 > "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667828659}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"768 → page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667910323}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll! But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667910375}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" wait:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667910724}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" does body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667910778}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667963480}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" hidden apply?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667963559}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The record overlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667963618}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is open and"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125667965617}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `body:has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668017670}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"(> .record:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668017766}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"not([hidden])){overflow"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668017833}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":hidden}` hides"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668017906}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" body scroll, but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668090408}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" document scrollHeight"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668090465}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" includes the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668090531}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page under"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668090678}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (`."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668155722}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"des"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668155782}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"k` sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668155841}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tall) — "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668155906}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1314."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668229553}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrollW "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668229603}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1029 >"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668229669}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668229732}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" horizontal overflow "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668316374}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"5px! That's concerning"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668316555}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": something"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668316627}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668316671}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the record extends"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668371168}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 5px beyond view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668371301}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"port width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668371421}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 1024. Since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668371594}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `.record`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668447274}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" padding "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668447375}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"10 and sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668447454}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668447519}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668521254}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" → should fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668521306}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Perhaps the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668521374}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" under-page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668521440}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668575096}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668575156}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Width 1029 due"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668575240}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668575336}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier styles;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668661931}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not necessarily record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668661995}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But page scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668662048}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668662156}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668721331}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1314 likely from the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668721383}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" underlying page (long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668721432}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") since"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668721488}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" body overflow hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668797504}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" prevents"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668797582}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrolling but scrollHeight"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668797643}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" metric"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668797727}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remains. For"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668882625}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668882673}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", we need to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668882745}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" check record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668882791}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668978580}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rect and whether"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668978726}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bottom of"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668978788}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sheet content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125668978950}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inside viewport."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669049719}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" At"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669049803}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ≤"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669049861}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"960 media"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669049932}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stacking doesn"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669129265}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t apply at 1024"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669129364}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", so record uses"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669129569}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" two-column layout at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669129622}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024×"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669180974}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"768. Sheet height"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669181068}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" = min(936"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669181141}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", 100%)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669181212}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of overlay content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669235697}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (768-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669235792}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"2*?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669235864}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"="},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669236018}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"~745"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669302215}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669302272}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 745; content compressed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669302372}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; summary"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669302453}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" may clip/"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669374544}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"overflow; charts"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669374606}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" rows"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669374676}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669374750}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669448097}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" content might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669448152}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow hidden"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669448193}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669448363}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow hidden) → content"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669551535}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" clipped inside sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669551610}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" but no page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669551665}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scroll. The page"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669551737}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrollHeight "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669608679}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"1314 is from the underlying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669608751}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" document, not the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669608798}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record; body"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669608849}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow hidden means"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669674677}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no visible"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669674780}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrollbar"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669674847}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". But the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669674898}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" acceptance says"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669723927}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" no page scroll"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669724005}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 144"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669725347}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0×900 ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669725402}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"and 128"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669804695}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"0 sanity) — 102"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669804751}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"4 full"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669804803}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-page is only"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669804893}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" \"degrade"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669949214}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to 1024px width\" per brief"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669949272}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; the record"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669949378}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" should"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125669949426}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670007315}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be readable. Let me screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670007392}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670007449}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" 1024.\n\nAlso"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670007508}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" scrollW 1029"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670076763}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" indicates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670076845}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" horizontal"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670076941}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" overflow from underlying"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670077018}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" page (atel"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670138753}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ier's design),"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670138804}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" not my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670138884}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" record. But record overlay"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670138963}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fixed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670218045}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" inset 0 →"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670218120}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width 1024;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670218174}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" sheet"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670218228}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width 100%"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670267750}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" of padding box"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670267798}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Fine.\n\nLet me view"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670267842}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the 1024 screenshot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670267886}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340078}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_91qdamuflwjnup5wcm3sj5gv","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340176}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340245}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340301}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340435}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340498}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340611}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340684}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340845}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670340905}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341009}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341057}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341105}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341158}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341194}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341376}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341435}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341496}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341560}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670341619}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670349679}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670349732}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670349779}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670349839}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670350873}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670350989}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670351036}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670351147}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670371474}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670371550}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670371611}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670371696}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670392441}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670392523}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670392580}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670392623}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670393898}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670393958}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670394047}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670394169}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670414367}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670414445}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670414527}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670414617}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670425088}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670425175}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670425221}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670425293}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670425723}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670425880}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670426054}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670426147}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670442273}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/ch"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670442367}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"art"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670442524}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-real"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670442617}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670460026}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"102"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670460102}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670460230}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670460280}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670537255}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12005,"ts_us":1793125670537333}}

data: {"id":"5d33d9d88c1974e2994cf49de268b93b","object":"chat.completion.chunk","created":1793125667,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":245600,"completion_tokens":509,"total_tokens":246109,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":243072,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":420,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":12005,"ts_us":1793125670537434}}

data: [DONE]

