data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388156330}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"The"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388244550}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" write failed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388244635}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because file changed since last"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388244699}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read? Odd — I created"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388325281}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it. Maybe the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388325351}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" FS guard triggered because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388325400}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388325440}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" edited via"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388425604}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" python ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388425652}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"bash) which changed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388425730}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" it outside the read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388425788}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/edit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388483567}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tracking. Need to read"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388483631}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the file first ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388483672}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"or use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388485224}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bash to"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388573017}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388573091}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"). I'll read then write"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388573164}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Actually simpler: use bash"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388573213}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" heredoc to write. But"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388687046}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" write tool with re"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388687131}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-read is fine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388687196}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388687355}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" read then write."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388762827}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_m149n4pl6jyeopc1lu6m33or","type":"function","function":{"name":"read"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388762886}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388763287}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388763380}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388763451}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388763513}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388763584}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388763654}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388763698}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388763810}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764307}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764383}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764428}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764500}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764587}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764657}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764728}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764791}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764852}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388764916}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765015}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765064}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765107}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765161}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765204}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765249}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765294}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765337}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765437}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765522}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765585}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765645}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388765969}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766042}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766113}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766175}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766238}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766300}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766354}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766432}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766490}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766583}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766629}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766703}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766764}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766814}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766868}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388766935}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388767003}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388767080}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388767159}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388767224}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"verify"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388771785}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388771838}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"engine"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388771883}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".test"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388771935}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".m"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388806789}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388806868}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388806956}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388806993}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388807514}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"limit"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388807562}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388807682}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388809803}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"5"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388909177}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":2532,"ts_us":1793123388909271}}

data: {"id":"9044b2fe5f64d9d21c53bfb6a4a52d3d","object":"chat.completion.chunk","created":1793123388,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":119170,"completion_tokens":182,"total_tokens":119352,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":111104,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":80,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":2532,"ts_us":1793123388909443}}

data: [DONE]

