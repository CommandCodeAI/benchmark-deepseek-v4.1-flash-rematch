data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036570846}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_xubxz7wlrvdj45w01oc8fqvk","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036616745}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036617071}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036617126}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036632260}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036632350}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036632570}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036632624}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036648938}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036648992}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036649170}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036650288}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036668476}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036668821}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036668861}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036668919}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036681291}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036681339}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036681936}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036681991}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036682662}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036683015}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036683067}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036683112}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036699382}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036699675}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036699721}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036699785}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036767350}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036767398}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036767531}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036767589}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036775821}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036775871}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036775973}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036776099}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036777846}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036778000}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036778043}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036778083}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036779314}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036779402}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036779502}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036779551}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036780813}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036781044}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036781089}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036781146}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036783285}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036783374}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036786748}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036786793}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036786847}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036786905}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"lead"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036786955}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-c"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036787005}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"andidate"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036803560}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036803614}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"144"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036803719}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036803765}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036868530}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036868602}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":43936,"ts_us":1793127036868708}}

data: {"id":"dad33e1748e0faad446d1fc46545f699","object":"chat.completion.chunk","created":1793127036,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":342351,"completion_tokens":90,"total_tokens":342441,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":341632,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":0,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":43936,"ts_us":1793127036875429}}

data: [DONE]

