data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475676479}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Plate"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475676601}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width 696 (not"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475676657}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475756793}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"901)"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475756901}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" because the plate is a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475757072}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" flex/g"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475757865}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rid item with max-width but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475779457}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475779570}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475779700}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a grid column: as"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475779973}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a grid item with `just"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475825774}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ify-self"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475825822}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": stretch`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475825863}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" default, width auto stretches"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475825902}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" to column"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475867453}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", then max-width caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475867582}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" at 901; but"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475867885}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" measured 696?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475868002}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Hmm because `margin"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475935723}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-inline:auto` on"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475935894}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475936044}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stretched"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125475936297}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" grid item makes it shrink"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476009008}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-to-fit? Yes:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476009129}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with auto margins"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476009338}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476009842}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" item's width becomes"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476107152}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" fit-content,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476107456}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" then max-width caps"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476107518}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"; fit"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476107725}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-content = its"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476145354}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476145846}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-content?"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476145885}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" The plate's max"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476146064}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"-content includes long"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476229898}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" nowrap text"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476230018}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? "},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476230366}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"696 seems small"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476230577}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476296324}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"census"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476296399}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" +"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476296460}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" title?). Anyway"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476296519}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" plate sh"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476374572}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rank too much because"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476374684}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" auto"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476374903}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" margins disable"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476375195}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" stretch. Better use"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476432113}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `justify-self:center"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476432214}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476432385}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and `width"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476432596}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":100%;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476500637}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" max-width:...`. Let"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476500793}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" me trial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476501005}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with width:"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476501151}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"100"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476570752}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"%.\n\nAlso,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476570827}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" the visual might"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476571319}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" be worth"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476571667}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" seeing"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476643010}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". Let me view trial"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476643096}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" screenshot before ret"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476643359}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"rying."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476643618}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_g2ig7nuc3glzok1vnsqkvcny","type":"function","function":{"name":"read_image"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476643694}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476643758}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476644789}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"file"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476644830}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_path"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476671745}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476671878}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476672099}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476672535}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476672694}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476672730}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476673385}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476673428}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476691852}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476691949}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476692077}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476692386}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476708053}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476708479}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476708573}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476708988}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476750881}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751004}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751095}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751177}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751263}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751340}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751428}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751516}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751602}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751693}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476751781}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476754679}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476771385}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476771476}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476771553}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476771627}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476785612}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476785709}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476785792}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476785875}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476785955}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476786033}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476786120}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476786203}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476795093}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476795191}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476795265}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476795469}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476814830}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476815072}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476815161}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ots"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476815235}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476827307}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"atel"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476827490}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ier"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476827789}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fold"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476827871}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-t"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476844443}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rial"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476844531}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".png"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476844765}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476844845}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":12349,"ts_us":1793125476906614}}

data: {"id":"2a157afd319c8f2d2c7c522857468bb7","object":"chat.completion.chunk","created":1793125475,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":338501,"completion_tokens":277,"total_tokens":338778,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":331136,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":188,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":12349,"ts_us":1793125476906791}}

data: [DONE]

