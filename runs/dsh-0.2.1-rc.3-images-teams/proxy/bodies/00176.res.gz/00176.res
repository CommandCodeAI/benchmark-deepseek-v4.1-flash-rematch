data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845084557}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"Big"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845161394}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" progress: controls.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845161440}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (48"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845161488}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"KB), render.js ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845226189}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"21KB), shell.html"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845226238}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updated,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845226308}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845226353}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" still placeholder, design"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845296828}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".css"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845296875}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" updated."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845296927}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Lead likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845297202}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" assembling after"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845408414}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845408462}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nEngine suite"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845408498}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is running in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845408540}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" background (t"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845469350}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"akes ~70s)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845469406}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Meanwhile,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845469436}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" let me assemble"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845469488}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" preview with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845527236}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" latest controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845527292}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"+render ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845527343}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"boot still"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845527385}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" placeholder) and test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845601516}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls mounting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845601561}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" manually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845601632}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"? Actually"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845601703}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845668512}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot placeholder"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845668557}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", controls won"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845668620}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"'t mount but I"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845668669}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" can call `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845739392}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845739462}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVARIUM"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845739515}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"_CONTROLS.mount(#"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845739571}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"instrument-body, ctx)`"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845852421}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" manually with a"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845852486}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" shim ctx"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845852539}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" backed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845852594}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" by real engine. That"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845910981}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" tests at"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845911054}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"elier's controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845911108}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" independently"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845911148}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" — valuable while"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845965520}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" waiting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845965577}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" for Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845965658}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nAlso render.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123845965697}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": can"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846009168}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" call V"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846009215}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"IVARIUM_RENDER.create"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846009257}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"()/draw"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846009296}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" with"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846065077}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" world? inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846065134}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" API"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846065178}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" quickly.\n\nBut"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846065218}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" remember my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846140223}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" priority"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846140300}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is the"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846140339}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" final deliverable QA"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846140377}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":". The Lead"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846232925}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" said"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846232976}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" boot"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846233023}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" is"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846233073}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" being"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846290512}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" written next;"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846290568}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" likely"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846290612}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" within"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846290669}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ~10 min."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846353889}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" Meanwhile"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846353969}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":":\n1. Verify engine"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846354034}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" ali"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846354104}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ases fixed"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846406448}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (background"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846406530}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" running"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846406587}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":").\n2. Build controls"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846406659}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mount"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846557286}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846557338}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" and test"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846557373}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls quickly"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846557412}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" (in"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846617761}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"ventory,"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846617900}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" aria"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846618010}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", keyboard, tool"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846618061}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"tips, fold)."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846699496}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" This validates"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846699572}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" my browser"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846699642}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" suite logic"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846699737}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" too (Tab"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846751749}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/key"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846751840}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"board helpers"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846751922}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") before final"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846752019}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" run — very"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846821418}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" useful"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846821510}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":": if my"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846821559}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" harness"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846821596}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" has"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846866433}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" bugs, early detection"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846866480}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n3. Prepare"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846866518}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" `"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846866595}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"verify"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846930756}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"/module-"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846930852}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"qa.mjs` for"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846930890}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" mounting"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123846930921}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls dashboard"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847004249}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" in preview"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847004307}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".\n\nLet me inspect"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847004347}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" controls.js"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847004393}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" API quickly ("},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847092224}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":"mount signature"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847092276}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":", ctx"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847092309}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":" expectations"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847092362}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":") and render"},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201318}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","reasoning_content":".js."},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201399}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"id":"call_00_riy0btkx8gopsx8m1e52tcw7","type":"function","function":{"name":"bash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201449}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"{"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201528}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201594}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"command"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201650}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201721}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201774}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201842}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"cd"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847201871}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" /"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202365}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"Users"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202412}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202483}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ah"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202559}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mad"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202628}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bil"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202693}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"al"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202740}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202793}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"bench"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202855}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/r"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202899}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"uns"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202946}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847202988}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"az"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847203111}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-d"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847203152}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"sh"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847205031}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847205075}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"0"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847205113}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847205154}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"2"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847218435}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847218477}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847218626}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847218705}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"rc"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847236701}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847236773}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"3"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847236843}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-de"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847236896}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847258771}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"seek"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847258913}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-v"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847258982}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"4"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847259020}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"."}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847267281}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"1"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847267341}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-fl"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847267389}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ash"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847267440}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847287527}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"202"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847287593}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"610"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847287646}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"27"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847287697}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"-"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847288137}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"223"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847288186}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"110"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847288231}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/work"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847288318}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" &&"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847300763}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847300806}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847300866}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847300929}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847329045}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847329102}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847329152}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847329192}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847334676}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_CONT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847334726}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"RO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847334823}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"LS"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847334903}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847352665}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847352721}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" mount"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847352773}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847352819}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"mount"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847374614}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847374667}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847374710}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847374942}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847375021}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847375099}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847375158}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847375446}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847412261}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847412329}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847412395}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847412678}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847472526}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847472580}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" grep"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847472747}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847473071}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"n"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847473118}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" \\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847473209}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"V"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847473261}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"IV"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847473314}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ARI"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847473364}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"UM"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847473404}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"_R"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847473454}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"ENDER"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491239}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491322}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"function"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491382}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491522}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\\\\|"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491582}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"create"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491657}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":":\\\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491709}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491823}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847491895}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nder"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847506451}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847506497}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" |"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847506562}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" head"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847506619}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" -"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847506993}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"20"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847507042}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847507106}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" echo"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847507158}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" ---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847519301}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"BO"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847519368}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"OT"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847519430}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"---"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847519496}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":";"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847532034}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" cat"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847532108}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" src"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847532172}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/b"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847532221}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"oot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847570401}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":".js"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847570458}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847570509}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":", "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847570554}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847570685}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"description"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847570855}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847570911}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":": "}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847570945}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847584498}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"In"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847584550}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"spect"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847584589}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" controls"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847584659}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"/re"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847624455}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"nder"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847624544}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" APIs"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847624621}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" and"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847624683}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" boot"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847637649}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":" state"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847637704}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"\""}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847637780}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash-1017","choices":[{"index":0,"delta":{"role":"assistant","tool_calls":[{"index":0,"function":{"arguments":"}"}}]},"finish_reason":null}],"system_fingerprint":"","sla_metrics":{"ttft_ms":9385,"ts_us":1793123847637851}}

data: {"id":"eeaf05b8e011e9d61c1bd321185c109d","object":"chat.completion.chunk","created":1793123844,"model":"deepseek/deepseek-v4.1-flash","choices":[{"index":0,"delta":{"role":"assistant"},"finish_reason":"tool_calls"}],"system_fingerprint":"","usage":{"prompt_tokens":190199,"completion_tokens":443,"total_tokens":190642,"prompt_tokens_details":{"audio_tokens":0,"cached_tokens":189312,"cache_write_tokens":0,"cache_creation_input_tokens":0,"cache_read_input_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0},"completion_tokens_details":{"audio_tokens":0,"reasoning_tokens":274,"accepted_prediction_tokens":0,"rejected_prediction_tokens":0,"text_tokens":0,"image_tokens":0,"video_tokens":0}},"sla_metrics":{"ttft_ms":9385,"ts_us":1793123847691164}}

data: [DONE]

